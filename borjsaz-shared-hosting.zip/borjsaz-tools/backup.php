<?php
// پشتیبان‌گیری خودکار از کل دیتابیس. روی cPanel در «Cron Jobs» روزانه اجرا شود:
//   php /home/USER/borjsaz-tools/backup.php /home/USER/public_html/api
// خروجی: api/data/backups/borjsaz-YYYYmmdd-HHMMSS.sql.gz — ۳۰ نسخه‌ی آخر نگه داشته می‌شود
// (همان فهرستی که در پنل سازنده دیده و دانلود می‌شود).
// بازگردانی MySQL: gunzip -c FILE.sql.gz | mysql -u USER -p DBNAME   (یا Import در phpMyAdmin)

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

// مسیر api: آرگومان اول، وگرنه پوشه‌ی api کنار tools (در مخزن کد).
$apiDir = rtrim($argv[1] ?? dirname(__DIR__) . '/api', '/\\');
if (!is_file("$apiDir/lib/config.php")) {
    fwrite(STDERR, "config not found: $apiDir/lib/config.php\n");
    exit(1);
}
require "$apiDir/lib/config.php";
date_default_timezone_set(defined('APP_TIMEZONE') ? APP_TIMEZONE : 'Asia/Tehran');
require "$apiDir/lib/db.php";
require "$apiDir/lib/backup.php";

try {
    $r = runBackup(db());
} catch (Throwable $e) {
    fwrite(STDERR, 'backup failed: ' . $e->getMessage() . "\n");
    exit(1);
}
echo "backup ok: {$r['name']} ({$r['tables']} tables, {$r['rows']} rows, " . round($r['size'] / 1024) . " KB)\n";
