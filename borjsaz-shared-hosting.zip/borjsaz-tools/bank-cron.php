<?php
// پیگیری کارهای جامانده‌ی تطبیق بانکی. روی cPanel در «Cron Jobs» هر ۱۰ دقیقه:
//   php /home/USER/borjsaz-tools/bank-cron.php /home/USER/public_html/api
// پیامک‌هایی که وسط پردازش ماندند خوانده می‌شوند و واریزهای باز (۳۰ روز اخیر) دوباره با اعلام‌های ساکنین
// تطبیق داده می‌شوند (مثلاً ساکنی که بعد از رسیدن پیامک، واریزش را اعلام کرده).

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}
$apiDir = rtrim($argv[1] ?? dirname(__DIR__) . '/api', '/\\');
if (!is_file("$apiDir/lib/config.php")) {
    fwrite(STDERR, "config not found: $apiDir/lib/config.php\n");
    exit(1);
}
require "$apiDir/lib/config.php";
date_default_timezone_set(defined('APP_TIMEZONE') ? APP_TIMEZONE : 'Asia/Tehran');
foreach (['db', 'jwt', 'http', 'validate', 'sms', 'jalali', 'audit'] as $f) require "$apiDir/lib/$f.php";
foreach (['auth', 'buildings', 'units', 'persons', 'finance', 'services', 'resident', 'comms', 'bank', 'platform'] as $f) require "$apiDir/routes/$f.php";

try {
    $r = bankCronRun();
} catch (Throwable $e) {
    fwrite(STDERR, 'bank-cron failed: ' . $e->getMessage() . "\n");
    exit(1);
}
echo "bank-cron ok: {$r['events']} events, {$r['rematched']} deposits re-checked\n";
