<?php
// عیب‌یابی نصب: https://دامنه/api/check.php — بعد از رفع مشکل این فایل را پاک کنید.
// هیچ رمز یا اطلاعات حساسی نشان نمی‌دهد.
header('Content-Type: text/plain; charset=utf-8');
header('Cache-Control: no-store');
$ok = fn($c, $t, $hint = '') => print(($c ? '[OK]   ' : '[FAIL] ') . $t . (!$c && $hint ? "\n       → $hint" : '') . "\n");

$ok(PHP_VERSION_ID >= 80000, 'PHP ' . PHP_VERSION, 'در cPanel ← Select PHP Version نسخه‌ی 8.0 یا بالاتر را انتخاب کنید');
foreach (['pdo_mysql', 'curl', 'mbstring', 'zlib', 'json'] as $x) $ok(extension_loaded($x), "افزونه‌ی $x", "در Select PHP Version افزونه‌ی $x را فعال کنید");

$cfg = __DIR__ . '/lib/config.php';
if (!is_file($cfg)) { $ok(false, 'فایل lib/config.php', 'config.example.php را به config.php کپی و پر کنید'); exit; }
try { require $cfg; $ok(true, 'بارگذاری config.php'); }
catch (Throwable $e) { $ok(false, 'بارگذاری config.php: ' . $e->getMessage() . ' (خط ' . $e->getLine() . ')', 'خط گفته‌شده را اصلاح کنید؛ مثلاً DIR باید __DIR__ باشد'); exit; }

$ok(defined('JWT_SECRET') && strlen(JWT_SECRET) >= 32 && !str_starts_with(JWT_SECRET, 'change_me'), 'JWT_SECRET', 'یک رشته‌ی تصادفی ۶۴ کاراکتری بگذارید');
$ok(defined('DB_DRIVER') && DB_DRIVER === 'mysql', 'DB_DRIVER = mysql', "روی هاست DB_DRIVER باید 'mysql' باشد");

try {
    $pdo = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $ok(true, 'اتصال به دیتابیس ' . DB_NAME);
    $n = $pdo->query("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE()")->fetchColumn();
    print("       جدول‌ها: $n" . ($n == 0 ? ' (در اولین درخواست به سایت ساخته می‌شوند)' : '') . "\n");
} catch (Throwable $e) {
    $ok(false, 'اتصال به دیتابیس: ' . $e->getMessage(), 'نام دیتابیس/کاربر/رمز را در config.php چک کنید و در cPanel ← MySQL Databases کاربر را با All Privileges به دیتابیس اضافه کنید');
}

$data = __DIR__ . '/data';
$ok(is_dir($data) && is_writable($data), 'پوشه‌ی api/data قابل نوشتن', 'پوشه‌ی api/data را بسازید و دسترسی 755 (یا 775) بدهید');
$ok(is_file(__DIR__ . '/.htaccess'), 'فایل api/.htaccess', 'فایل‌های مخفی (.htaccess) آپلود نشده‌اند؛ در File Manager گزینه‌ی Show Hidden Files را بزنید');
$ok(is_file(dirname(__DIR__) . '/.htaccess'), 'فایل .htaccess کنار index.html', 'فایل .htaccess اصلی آپلود نشده');
$ok(is_file(dirname(__DIR__) . '/index.html'), 'index.html کنار پوشه‌ی api', 'محتوای public_html زیپ باید مستقیم در ریشه‌ی سایت باشد');
$assets = glob(dirname(__DIR__) . '/assets/index-*.js') ?: [];
print('       فایل اصلی فرانت: ' . ($assets ? implode(', ', array_map('basename', $assets)) : 'پیدا نشد') . "\n");
print("\nLOGIN_REQUIRED=" . var_export(defined('LOGIN_REQUIRED') && LOGIN_REQUIRED, true) . "  OTP_ENABLED=" . var_export(defined('OTP_ENABLED') && OTP_ENABLED, true) . "\n");
