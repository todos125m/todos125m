<?php
// برج‌ساز — نقطه‌ی ورود API. همه‌ی درخواست‌های /api/* به اینجا می‌رسند (.htaccess یا php -S).

// خطا در config.php (مثلاً DIR به‌جای __DIR__ یا فایل جاافتاده) به‌جای صفحه‌ی سفید/HTML، JSON خوانا برمی‌گرداند.
try {
    if (!is_file(__DIR__ . '/lib/config.php')) throw new RuntimeException('فایل api/lib/config.php وجود ندارد؛ config.example.php را کپی و پر کنید.');
    require __DIR__ . '/lib/config.php';
} catch (Throwable $e) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error' => 'CONFIG_ERROR', 'detail' => $e->getMessage() . ' (config.php خط ' . $e->getLine() . ')'], JSON_UNESCAPED_UNICODE);
    exit;
}
foreach (['APP_ENV' => 'production', 'OTP_EXPIRY_SECONDS' => 300, 'TOKEN_TTL_DAYS' => 30, 'CORS_ORIGIN' => '*', 'PLATFORM_ADMINS' => []] as $k => $v) {
    if (!defined($k)) define($k, $v);
}

// همه‌ی تاریخ‌ها (سررسید، «امروز»، زمان رویدادها) به وقت ایران؛ فرانت هم تاریخ محلی کاربر را می‌فرستد.
date_default_timezone_set(defined('APP_TIMEZONE') ? APP_TIMEZONE : 'Asia/Tehran');
// روی سرور جزئیات خطا هرگز به کاربر نشان داده نمی‌شود؛ در لاگ پنل سازنده ثبت می‌شود.
ini_set('display_errors', APP_ENV === 'dev' ? '1' : '0');
require __DIR__ . '/lib/db.php';
require __DIR__ . '/lib/jwt.php';
require __DIR__ . '/lib/http.php';
require __DIR__ . '/lib/validate.php';
require __DIR__ . '/lib/sms.php';
require __DIR__ . '/lib/jalali.php';
require __DIR__ . '/lib/audit.php';
require __DIR__ . '/lib/backup.php';
require __DIR__ . '/routes/auth.php';
require __DIR__ . '/routes/buildings.php';
require __DIR__ . '/routes/units.php';
require __DIR__ . '/routes/persons.php';
require __DIR__ . '/routes/finance.php';
require __DIR__ . '/routes/services.php';
require __DIR__ . '/routes/resident.php';
require __DIR__ . '/routes/comms.php';
require __DIR__ . '/routes/bank.php';
require __DIR__ . '/routes/platform.php';

// هشدارها و خطاهای مرگبار PHP هم در لاگ پنل سازنده ثبت شوند (نه فقط exceptionها).
set_error_handler(function (int $no, string $msg, string $file, int $line) {
    if (!(error_reporting() & $no)) return false;
    logError('server', "PHP warning: $msg", "$file:$line", null);
    return APP_ENV !== 'dev'; // روی سرور به خروجی JSON چیزی اضافه نشود
});
register_shutdown_function(function () {
    $e = error_get_last();
    if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        logError('server', 'PHP fatal: ' . $e['message'], $e['file'] . ':' . $e['line'], null);
    }
});

sendCors();

$method = $_SERVER['REQUEST_METHOD'];
$path   = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?: '/';
$path   = '/' . trim(preg_replace('#^.*?/api(?=/|$)#', '', $path), '/');

$routes = [
    ['POST',   '/bank/webhook',                     'bank_webhook'],
    ['GET',    '/buildings/(\d+)/bank/deposits',   'bank_deposits'],
    ['POST',   '/buildings/(\d+)/bank/deposits',   'bank_deposit_create'],
    ['GET',    '/buildings/(\d+)/bank/events',     'bank_events'],
    ['POST',   '/buildings/(\d+)/bank/import',     'bank_import'],
    ['GET',    '/buildings/(\d+)/bank/report',     'bank_report'],
    ['GET',    '/buildings/(\d+)/bank/settings',   'bank_settings'],
    ['PATCH',  '/buildings/(\d+)/bank/settings',   'bank_settings_update'],
    ['POST',   '/buildings/(\d+)/bank/devices',    'bank_device_create'],
    ['DELETE', '/bank/devices/(\d+)',              'bank_device_revoke'],
    ['POST',   '/bank/deposits/(\d+)/confirm',     'bank_deposit_confirm'],
    ['POST',   '/bank/deposits/(\d+)/assign',      'bank_deposit_assign'],
    ['POST',   '/bank/deposits/(\d+)/ignore',      'bank_deposit_ignore'],
    ['POST',   '/bank/deposits/(\d+)/reopen',      'bank_deposit_reopen'],
    ['POST',   '/auth/login',                       'auth_login'],
    ['POST',   '/auth/password',                    'auth_change_password'],
    ['POST',   '/auth/guest',                       'auth_guest'],
    ['POST',   '/auth/send-otp',                    'auth_send_otp'],
    ['POST',   '/auth/verify-otp',                  'auth_verify_otp'],
    ['GET',    '/auth/me',                          'auth_me'],
    ['PATCH',  '/auth/me',                          'auth_update_me'],

    ['GET',    '/buildings',                        'buildings_list'],
    ['POST',   '/buildings',                        'buildings_create'],
    ['GET',    '/buildings/(\d+)',                  'buildings_show'],
    ['PATCH',  '/buildings/(\d+)',                  'buildings_update'],
    ['GET',    '/buildings/(\d+)/members',          'members_list'],
    ['POST',   '/buildings/(\d+)/members',          'members_add'],
    ['DELETE', '/buildings/(\d+)/members/(\d+)',    'members_remove'],

    ['GET',    '/buildings/(\d+)/units',            'units_list'],
    ['POST',   '/buildings/(\d+)/units',            'units_create'],
    ['POST',   '/buildings/(\d+)/units/bulk',       'units_bulk_create'],
    ['POST',   '/buildings/(\d+)/units/import',     'units_import'],
    ['GET',    '/units/(\d+)',                      'units_show'],
    ['PATCH',  '/units/(\d+)',                      'units_update'],
    ['DELETE', '/units/(\d+)',                      'units_delete'],

    ['GET',    '/buildings/(\d+)/persons',          'persons_list'],
    ['POST',   '/units/(\d+)/persons',              'persons_create'],
    ['PATCH',  '/persons/(\d+)',                    'persons_update'],
    ['DELETE', '/persons/(\d+)',                    'persons_delete'],

    ['PATCH',  '/buildings/(\d+)/finance',                     'finance_settings_update'],
    ['GET',    '/buildings/(\d+)/finance/summary',             'finance_summary'],
    ['GET',    '/buildings/(\d+)/finance/statement',           'finance_statement'],
    ['GET',    '/buildings/(\d+)/transactions',                'transactions_list'],
    ['POST',   '/buildings/(\d+)/debts',                       'debts_bulk'],
    ['GET',    '/buildings/(\d+)/charges',                     'charges_periods'],
    ['POST',   '/buildings/(\d+)/charges/preview',             'charges_preview'],
    ['POST',   '/buildings/(\d+)/charges',                     'charges_issue'],
    ['DELETE', '/buildings/(\d+)/charges/(\d{4}-\d{2})',       'charges_revoke'],
    ['POST',   '/buildings/(\d+)/charges/(\d{4}-\d{2})/penalty', 'charges_penalty'],
    ['GET',    '/units/(\d+)/ledger',                          'unit_ledger'],
    ['POST',   '/units/(\d+)/transactions',                    'transactions_create'],
    ['DELETE', '/transactions/(\d+)',                          'transactions_delete'],
    ['GET',    '/buildings/(\d+)/fund',                        'fund_list'],
    ['POST',   '/buildings/(\d+)/fund',                        'fund_create'],
    ['DELETE', '/fund/(\d+)',                                  'fund_delete'],

    ['GET',    '/buildings/(\d+)/staff',                       'staff_list'],
    ['POST',   '/buildings/(\d+)/staff',                       'staff_create'],
    ['PATCH',  '/staff/(\d+)',                                 'staff_update'],
    ['DELETE', '/staff/(\d+)',                                 'staff_delete'],
    ['GET',    '/buildings/(\d+)/equipment',                   'equipment_list'],
    ['POST',   '/buildings/(\d+)/equipment',                   'equipment_create'],
    ['GET',    '/equipment/(\d+)',                             'equipment_show'],
    ['PATCH',  '/equipment/(\d+)',                             'equipment_update'],
    ['DELETE', '/equipment/(\d+)',                             'equipment_delete'],
    ['POST',   '/equipment/(\d+)/services',                    'equipment_service_create'],
    ['DELETE', '/equipment-services/(\d+)',                    'equipment_service_delete'],
    ['GET',    '/buildings/(\d+)/requests',                    'requests_list'],
    ['POST',   '/buildings/(\d+)/requests',                    'requests_create'],
    ['GET',    '/requests/(\d+)',                              'request_show'],
    ['PATCH',  '/requests/(\d+)',                              'request_update'],
    ['POST',   '/requests/(\d+)/transition',                   'request_transition'],
    ['DELETE', '/requests/(\d+)',                              'request_delete'],
    ['GET',    '/buildings/(\d+)/services/summary',            'services_summary'],
    ['GET',    '/buildings/(\d+)/services/report',             'services_report'],

    ['GET',    '/me/residences',                              'me_residences'],
    ['GET',    '/me/units/(\d+)',                              'me_unit'],
    ['POST',   '/me/units/(\d+)/claims',                       'me_claim_create'],
    ['GET',    '/me/units/(\d+)/requests',                     'me_requests'],
    ['POST',   '/me/units/(\d+)/requests',                     'me_request_create'],
    ['GET',    '/buildings/(\d+)/claims',                      'claims_list'],
    ['GET',    '/claims/(\d+)/receipt',                       'claim_receipt'],
    ['POST',   '/claims/(\d+)/review',                         'claim_review'],
    ['GET',    '/me/units/(\d+)/invoice',                       'me_invoice'],

    ['POST',   '/buildings/(\d+)/sms/preview',                  'sms_preview'],
    ['POST',   '/buildings/(\d+)/sms',                          'sms_send'],
    ['GET',    '/buildings/(\d+)/sms',                          'sms_log'],
    ['GET',    '/buildings/(\d+)/audit',                        'audit_list'],
    ['GET',    '/buildings/(\d+)/notices',                      'notices_list'],
    ['POST',   '/buildings/(\d+)/notices',                      'notices_create'],
    ['PATCH',  '/notices/(\d+)',                                'notices_update'],
    ['DELETE', '/notices/(\d+)',                                'notices_delete'],
    ['GET',    '/buildings/(\d+)/meetings',                     'meetings_list'],
    ['POST',   '/buildings/(\d+)/meetings',                     'meetings_create'],
    ['GET',    '/meetings/(\d+)',                               'meeting_show'],
    ['PATCH',  '/meetings/(\d+)',                               'meeting_update'],
    ['DELETE', '/meetings/(\d+)',                               'meeting_delete'],
    ['POST',   '/meetings/(\d+)/resolutions',                   'resolutions_create'],
    ['PATCH',  '/resolutions/(\d+)',                            'resolution_update'],
    ['DELETE', '/resolutions/(\d+)',                            'resolution_delete'],
    ['GET',    '/buildings/(\d+)/resolutions',                  'resolutions_list'],
    ['GET',    '/buildings/(\d+)/report',                       'monthly_report'],
    ['GET',    '/buildings/(\d+)/invoices',                     'invoices'],
    ['GET',    '/buildings/(\d+)/export',                       'building_export'],

    ['POST',   '/client-errors',                                 'client_error'],
    ['GET',    '/platform/overview',                             'platform_overview'],
    ['GET',    '/platform/errors',                               'platform_errors'],
    ['POST',   '/platform/errors/clear',                         'platform_errors_clear'],
    ['GET',    '/platform/backups',                              'platform_backups'],
    ['POST',   '/platform/backups',                              'platform_backup_create'],
    ['GET',    '/platform/backups/(borjsaz-[\w.-]+)',            'platform_backup_download'],
    ['GET',    '/platform/buildings',                            'platform_buildings'],
    ['GET',    '/platform/users',                                'platform_users'],
    ['POST',   '/platform/users/(\d+)/password',                'platform_user_password'],
];

try {
    $pathMatched = false;
    foreach ($routes as [$m, $pattern, $handler]) {
        if (!preg_match('#^' . $pattern . '$#', $path, $params)) continue;
        $pathMatched = true;
        if ($m !== $method) continue;
        array_shift($params);
        $handler(...$params); // پارامترهای عددی با type-hint به int تبدیل می‌شوند
        exit;
    }
    fail($pathMatched ? 'METHOD_NOT_ALLOWED' : 'NOT_FOUND', $pathMatched ? 405 : 404);
} catch (PDOException $e) {
    // اتصال به دیتابیس برقرار نشد (نام/کاربر/رمز اشتباه یا کاربر به دیتابیس وصل نشده) → علت را بگو.
    if (str_contains($e->getMessage(), 'SQLSTATE[HY000] [')) {
        error_log('borjsaz DB connect: ' . $e->getMessage());
        fail('DB_CONNECT', 500, ['detail' => preg_replace('/^SQLSTATE\[HY000\] \[\d+\] /', '', $e->getMessage())]);
    }
    if (isUniqueViolation($e)) fail('DUPLICATE', 409);
    logError('server', 'DB: ' . $e->getMessage(), $e->getFile() . ':' . $e->getLine() . "\n" . $e->getTraceAsString(), optionalUserId());
    fail('SERVER_ERROR', 500);
} catch (Throwable $e) {
    logError('server', $e->getMessage(), $e->getFile() . ':' . $e->getLine() . "\n" . $e->getTraceAsString(), optionalUserId());
    fail('SERVER_ERROR', 500);
}
