<?php
// ردپای تغییرات: هر کار مهمِ مدیریتی (ثبت، ویرایش، حذف، صدور، تأیید) با نام انجام‌دهنده ثبت می‌شود.
// اعضای تیم مدیریت (از جمله هیئت‌مدیره‌ی فقط‌خواندنی) آن را می‌بینند؛ قابل ویرایش یا حذف نیست.

function audit(int $bid, string $action, string $summary, string $entity = '', ?int $entityId = null): void {
    db()->prepare('INSERT INTO audit_log (building_id, user_id, action, entity, entity_id, summary, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
        ->execute([$bid, authUserId(), $action, $entity, $entityId, mb_substr($summary, 0, 500), now()]);
}

/** «واحد ۱۲ (بلوک A)» برای متن ردپا و پیامک. */
function unitName(array $u): string {
    $title = $u['title'] ?? $u['unit_title'] ?? '';
    $block = $u['block'] ?? $u['unit_block'] ?? '';
    $name = preg_match('/^\d+$/', $title) ? "واحد $title" : $title;
    return faDigits($block !== '' ? "{$name}، بلوک {$block}" : $name);
}

function unitNameById(int $unitId): string {
    $s = db()->prepare('SELECT title, block FROM units WHERE id = ?');
    $s->execute([$unitId]);
    return unitName($s->fetch() ?: []);
}
