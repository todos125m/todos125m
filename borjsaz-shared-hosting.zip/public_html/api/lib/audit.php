<?php
// ردپای تغییرات: هر کار مهمِ مدیریتی (ثبت، ویرایش، حذف، صدور، تأیید) با نام انجام‌دهنده ثبت می‌شود.
// اعضای تیم مدیریت (از جمله هیئت‌مدیره‌ی فقط‌خواندنی) آن را می‌بینند؛ قابل ویرایش یا حذف نیست.

/**
 * کارهای خودکار (تطبیق پیامک بانک از وب‌هوک یا cron) کاربر واردشده ندارند: systemActor(مسئول) آن‌ها را به نام
 * سیستم ثبت می‌کند — در ردپا user_id خالی («سیستم»)، و در ردیف مالی created_by = مدیری که مسئول ساختمان است.
 */
function systemActor(?int $txUserId): void {
    $GLOBALS['borjsaz_system_actor'] = $txUserId;
}

function isSystemActor(): bool {
    return array_key_exists('borjsaz_system_actor', $GLOBALS) && $GLOBALS['borjsaz_system_actor'] !== null;
}

/** کاربرِ ثبت‌کننده‌ی ردیف‌های مالی (created_by). */
function actorId(): int {
    return isSystemActor() ? (int) $GLOBALS['borjsaz_system_actor'] : authUserId();
}

function audit(int $bid, string $action, string $summary, string $entity = '', ?int $entityId = null): void {
    db()->prepare('INSERT INTO audit_log (building_id, user_id, action, entity, entity_id, summary, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
        ->execute([$bid, isSystemActor() ? null : authUserId(), $action, $entity, $entityId, mb_substr($summary, 0, 500), now()]);
}

/** «واحد ۱۲ (بلوک A)» برای متن ردپا و پیامک. */
function unitName(array $u): string {
    $title = $u['title'] ?? $u['unit_title'] ?? '';
    $block = $u['block'] ?? $u['unit_block'] ?? '';
    $name = preg_match('/^\d+$/', $title) ? "واحد $title" : $title;
    return faDigits($block !== '' ? "{$name}، بلوک {$block}" : $name);
}

function unitNameById(int $unitId): string {
    $s = db()->prepare('SELECT title, block FROM units WHERE id = ?');
    $s->execute([$unitId]);
    return unitName($s->fetch() ?: []);
}
