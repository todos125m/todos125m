<?php
// پشتیبان‌گیری از کل دیتابیس به فایل .sql.gz — مشترک بین cron (tools/backup.php) و پنل سازنده.
// بازگردانی MySQL: gunzip -c FILE.sql.gz | mysql -u USER -p DBNAME   (یا Import در phpMyAdmin)

const BACKUP_KEEP = 30;

function backupDir(): string {
    return __DIR__ . '/../data/backups';
}

/** یک نسخه‌ی کامل می‌سازد و نسخه‌های قدیمی‌تر از ۳۰ تای آخر را پاک می‌کند. */
function runBackup(PDO $pdo): array {
    $dir = backupDir();
    if (!is_dir($dir) && !mkdir($dir, 0750, true)) throw new RuntimeException("cannot create $dir");
    $file = "$dir/borjsaz-" . date('Ymd-His') . '.sql.gz';
    $mysql = DB_DRIVER === 'mysql';
    $q = fn(string $t) => $mysql ? "`$t`" : "\"$t\"";

    $gz = gzopen($file, 'wb6');
    gzwrite($gz, '-- borjsaz backup ' . date('Y-m-d H:i:s') . ' driver=' . DB_DRIVER . "\n");
    if ($mysql) gzwrite($gz, "SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS = 0;\n");

    $tables = $mysql
        ? $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN)
        : $pdo->query("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'")->fetchAll(PDO::FETCH_COLUMN);

    $rows = 0;
    foreach ($tables as $t) {
        $create = $mysql
            ? $pdo->query("SHOW CREATE TABLE `$t`")->fetch(PDO::FETCH_NUM)[1]
            : $pdo->query('SELECT sql FROM sqlite_master WHERE name = ' . $pdo->quote($t))->fetchColumn();
        gzwrite($gz, "\nDROP TABLE IF EXISTS {$q($t)};\n$create;\n");
        $stmt = $pdo->query("SELECT * FROM {$q($t)}");
        while ($r = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $vals = array_map(fn($v) => $v === null ? 'NULL' : (is_int($v) || is_float($v) ? (string) $v : $pdo->quote((string) $v)), array_values($r));
            gzwrite($gz, "INSERT INTO {$q($t)} VALUES (" . implode(', ', $vals) . ");\n");
            $rows++;
        }
    }
    if ($mysql) gzwrite($gz, "SET FOREIGN_KEY_CHECKS = 1;\n");
    gzclose($gz);

    $all = listBackups();
    foreach (array_slice($all, BACKUP_KEEP) as $old) @unlink("$dir/{$old['name']}");

    return ['name' => basename($file), 'tables' => count($tables), 'rows' => $rows, 'size' => filesize($file)];
}

/** نسخه‌ها، جدیدترین اول. */
function listBackups(): array {
    $files = glob(backupDir() . '/borjsaz-*.sql.gz') ?: [];
    rsort($files);
    return array_map(fn($f) => ['name' => basename($f), 'size' => filesize($f), 'created_at' => date('Y-m-d H:i:s', filemtime($f))], $files);
}
