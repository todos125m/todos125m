<?php
// lib/config.example.php — الگو. روی سرور به lib/config.php کپی و مقادیر واقعی را پر کن.
// lib/config.php در gitignore است (رازهای production).

// 'dev' → پیامک ارسال نمی‌شود و کد OTP در پاسخ برمی‌گردد. روی سرور حتماً 'production'.
define('APP_ENV', 'production');

// ===== دیتابیس =====
// 'mysql' برای هاست؛ 'sqlite' فقط برای توسعه‌ی محلی (جدول‌ها خودکار ساخته می‌شوند).
define('DB_DRIVER', 'mysql');
define('DB_HOST', 'localhost');
define('DB_NAME', 'your_db_name');
define('DB_USER', 'your_db_user');
define('DB_PASS', 'your_db_password');
define('DB_SQLITE_PATH', __DIR__ . '/../data/borjsaz.sqlite');

// ===== رازها — هر کدام یک رشته‌ی hex تصادفیِ مستقل: php -r "echo bin2hex(random_bytes(32));"
define('JWT_SECRET', 'change_me_64_hex_chars');
define('OTP_SECRET', 'change_me_another_independent_64_hex_chars');
define('TOKEN_TTL_DAYS', 30);

// ===== SMS.ir =====
define('SMS_IR_API_KEY', 'your_sms_ir_api_key');
define('SMS_IR_TEMPLATE_ID', 100000); // قالبِ verify با پارامتر CODE
// شماره‌ی خط خدماتی برای پیامک‌های اطلاع‌رسانی (اعلام شارژ، یادآوری بدهی، اطلاعیه، دعوت). خالی = ارسال نمی‌شود.
define('SMS_IR_LINE_NUMBER', '');
// نشانی سامانه که پایینِ پیامک‌ها می‌آید (مثلاً https://setayesh.example.ir)
define('APP_URL', '');
define('OTP_EXPIRY_SECONDS', 300);
// false → ورود فقط با شماره‌ی موبایل و بدون کد پیامکی (موقت؛ ناامن است). true → ورود با کد پیامکی.
define('OTP_ENABLED', false);
// true → ورود با موبایل و رمز عبور (اولین ورود: کاربر رمز دلخواه می‌گذارد؛ فراموشی: پنل سازنده ← کاربران و رمز).
// false → صفحه‌ی ورود حذف می‌شود و همه خودکار با DEFAULT_USER_MOBILE وارد می‌شوند (هر کس آدرس سایت را بداند همه‌چیز را می‌بیند!).
define('LOGIN_REQUIRED', false);
// کاربر پیش‌فرض وقتی ورود حذف شده (مدیر ساختمان‌ها). خالی = اولین شماره‌ی PLATFORM_ADMINS.
define('DEFAULT_USER_MOBILE', '');

// وقتی فرانت و API روی یک دامنه‌اند، '*' مشکلی ندارد (احراز هویت با هدر است، نه کوکی).
define('CORS_ORIGIN', '*');

define('APP_TIMEZONE', 'Asia/Tehran');

// موبایل اعضای تیم پشتیبانی برج‌ساز که «پنل سازنده» (لاگ خطاها، پشتیبان‌ها، فهرست مشتری‌ها) را می‌بینند.
define('PLATFORM_ADMINS', ['09120000000']);
