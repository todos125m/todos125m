<?php
// lib/config.php — تنظیماتِ توسعه‌ی محلی (SQLite، بدون پیامک). روی سرور از config.example.php بساز.
// lib/config.php در gitignore است (رازهای production).

// 'dev' → پیامک ارسال نمی‌شود و کد OTP در پاسخ برمی‌گردد. روی سرور حتماً 'production'.
define('APP_ENV', 'dev');

// ===== دیتابیس =====
// 'mysql' برای هاست؛ 'sqlite' فقط برای توسعه‌ی محلی (جدول‌ها خودکار ساخته می‌شوند).
define('DB_DRIVER', 'sqlite');
define('DB_HOST', 'localhost');
define('DB_NAME', 'your_db_name');
define('DB_USER', 'your_db_user');
define('DB_PASS', 'your_db_password');
define('DB_SQLITE_PATH', __DIR__ . '/../data/borjsaz.sqlite');

// ===== رازها — هر کدام یک رشته‌ی hex تصادفیِ مستقل: php -r "echo bin2hex(random_bytes(32));"
define('JWT_SECRET', '76c081f6d7a72bf44e4c9e99cef4966a931a280f2495e60eae5fc303a521f05f');
define('OTP_SECRET', '9ce3bc6fa5065c9f58c753a55af0a9bf24128dbcfe2c612a88943fca235b4fcd');
define('TOKEN_TTL_DAYS', 30);

// ===== SMS.ir =====
define('SMS_IR_API_KEY', 'your_sms_ir_api_key');
define('SMS_IR_TEMPLATE_ID', 100000); // قالبِ verify با پارامتر CODE
define('OTP_EXPIRY_SECONDS', 300);

// وقتی فرانت و API روی یک دامنه‌اند، '*' مشکلی ندارد (احراز هویت با هدر است، نه کوکی).
define('CORS_ORIGIN', '*');

// پنل سازنده (توسعه‌ی محلی: مدیر نمونه)
define('PLATFORM_ADMINS', ['09121234567', '09912397671']);
