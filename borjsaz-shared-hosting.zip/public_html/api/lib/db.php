<?php
// اتصال PDO (singleton). MySQL روی هاست، SQLite برای توسعه‌ی محلی.
// اسکیمای دیتابیس با فایل‌های migrations/*.{driver}.sql خودکار به‌روز می‌شود.

function db(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;

    $opts = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    if (DB_DRIVER === 'sqlite') {
        if (!is_dir(dirname(DB_SQLITE_PATH))) mkdir(dirname(DB_SQLITE_PATH), 0755, true);
        $pdo = new PDO('sqlite:' . DB_SQLITE_PATH, null, null, $opts);
        $pdo->exec('PRAGMA foreign_keys = ON');
        $pdo->exec('PRAGMA journal_mode = WAL');
    } else {
        $pdo = new PDO(
            'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
            DB_USER, DB_PASS, $opts
        );
    }
    migrate($pdo);
    return $pdo;
}

/**
 * مهاجرت‌های اجرانشده را به ترتیبِ نام اجرا می‌کند. بعد از موفقیت یک فایلِ نشانه در data/
 * می‌سازد تا درخواست‌های بعدی هزینه‌ای نداشته باشند (تا وقتی فایل مهاجرتِ جدیدی اضافه شود).
 */
function migrate(PDO $pdo): void {
    $files = glob(__DIR__ . '/../migrations/*.' . DB_DRIVER . '.sql');
    sort($files);
    $names = array_map(fn($f) => basename($f, '.' . DB_DRIVER . '.sql'), $files);
    $flag  = __DIR__ . '/../data/.migrated-' . DB_DRIVER . '-' . md5(implode('|', $names));
    if (is_file($flag)) return;

    $pdo->exec('CREATE TABLE IF NOT EXISTS migrations (name VARCHAR(100) PRIMARY KEY, applied_at VARCHAR(19) NOT NULL)');
    $done = array_flip($pdo->query('SELECT name FROM migrations')->fetchAll(PDO::FETCH_COLUMN));

    // دیتابیسی که پیش از سیستمِ مهاجرت ساخته شده: جدول‌های پایه هست ولی ثبت نشده.
    if (!$done && tableExists($pdo, 'users')) {
        $pdo->prepare('INSERT INTO migrations (name, applied_at) VALUES (?, ?)')->execute([$names[0], now()]);
        $done[$names[0]] = true;
    }

    $mark = $pdo->prepare('INSERT INTO migrations (name, applied_at) VALUES (?, ?)');
    foreach ($files as $i => $file) {
        $name = $names[$i];
        if (isset($done[$name])) continue;
        $statements = splitSql(file_get_contents($file));
        if (DB_DRIVER === 'sqlite') {
            // DDL در SQLite تراکنشی است: یا کل فایل اعمال می‌شود یا هیچ.
            $pdo->beginTransaction();
            foreach ($statements as $sql) $pdo->exec($sql);
            $mark->execute([$name, now()]);
            $pdo->commit();
            continue;
        }
        // در MySQL هر DDL خودکار commit می‌شود؛ هر دستور جدا ثبت می‌شود تا اجرای دوباره
        // بعد از یک شکستِ نیمه‌کاره، دستورهای انجام‌شده را تکرار نکند.
        foreach ($statements as $k => $sql) {
            if (isset($done["$name#$k"])) continue;
            try {
                $pdo->exec($sql);
            } catch (PDOException $e) {
                error_log("borjsaz migration $name#$k failed: " . $e->getMessage());
                throw $e;
            }
            $mark->execute(["$name#$k", now()]);
        }
        $mark->execute([$name, now()]);
    }

    if (is_dir(dirname($flag)) || @mkdir(dirname($flag), 0755, true)) @file_put_contents($flag, now());
}

function tableExists(PDO $pdo, string $table): bool {
    $sql = DB_DRIVER === 'sqlite'
        ? "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?"
        : 'SELECT 1 FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?';
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$table]);
    return (bool) $stmt->fetchColumn();
}

function splitSql(string $sql): array {
    $sql = preg_replace('/^\s*--.*$/m', '', $sql);
    return array_values(array_filter(array_map('trim', preg_split('/;\s*(?:\r?\n|$)/', $sql))));
}

function now(): string {
    return date('Y-m-d H:i:s');
}

function today(): string {
    return date('Y-m-d');
}

function isUniqueViolation(PDOException $e): bool {
    // MySQL: 23000/1062 — SQLite: 23000 با پیامِ UNIQUE
    return $e->getCode() === '23000' && (str_contains($e->getMessage(), '1062') || stripos($e->getMessage(), 'UNIQUE') !== false);
}

/**
 * داخل تراکنش صدا زده شود: درخواست‌های هم‌زمان روی یک ساختمان (دو کلیک پشت‌سرهم، دو مدیر) پشت هم اجرا
 * می‌شوند تا بررسیِ «قبلاً انجام شده؟» و ثبت، یکجا باشد. SQLite کل دیتابیس را هنگام نوشتن قفل می‌کند.
 */
function lockBuilding(int $bid): void {
    if (DB_DRIVER === 'mysql') db()->prepare('SELECT id FROM buildings WHERE id = ? FOR UPDATE')->execute([$bid]);
    else db()->exec('UPDATE buildings SET id = id WHERE id = ' . $bid);
}

