<?php
// پاسخ JSON، بدنه‌ی درخواست، احراز هویت و ریت‌لیمیت.

function sendCors(): void {
    header('Access-Control-Allow-Origin: ' . CORS_ORIGIN);
    header('Access-Control-Allow-Methods: GET, POST, PATCH, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization');
    header('Access-Control-Max-Age: 86400');
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(204);
        exit;
    }
}

function respond($data, int $code = 200) {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function fail(string $error, int $code = 400, array $extra = []) {
    respond(['error' => $error] + $extra, $code);
}

// سقف ۲MB: ورود از اکسل تا چند هزار ردیف را در یک درخواست می‌فرستد.
function body(): array {
    static $cached = null;
    if ($cached !== null) return $cached;
    $raw = file_get_contents('php://input', false, null, 0, 2 * 1048576 + 1);
    if ($raw !== false && strlen($raw) > 2 * 1048576) fail('PAYLOAD_TOO_LARGE', 413);
    $cached = json_decode($raw ?: '', true, 32) ?? [];
    return is_array($cached) ? $cached : [];
}

function clientIp(): string {
    return $_SERVER['REMOTE_ADDR'] ?? 'unknown';
}

function authUserId(): int {
    static $uid = null;
    if ($uid !== null) return $uid;

    // Apache روی cPanel گاهی هدر Authorization را فقط در REDIRECT_* می‌گذارد.
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
    if (!preg_match('/^Bearer\s+(\S+)$/', $header, $m)) fail('UNAUTHORIZED', 401);

    $claims = jwt_decode($m[1]);
    if (!$claims) fail('UNAUTHORIZED', 401);

    $stmt = db()->prepare('SELECT id, last_seen_at FROM users WHERE id = ?');
    $stmt->execute([(int) $claims['sub']]);
    $user = $stmt->fetch();
    if (!$user) fail('UNAUTHORIZED', 401);

    // آخرین فعالیت (برای آمار کاربران فعال در پنل سازنده) — حداکثر هر ۱۰ دقیقه یک‌بار نوشته می‌شود.
    if (!$user['last_seen_at'] || $user['last_seen_at'] < date('Y-m-d H:i:s', time() - 600)) {
        db()->prepare('UPDATE users SET last_seen_at = ? WHERE id = ?')->execute([now(), $user['id']]);
    }
    return $uid = (int) $claims['sub'];
}

// ریت‌لیمیتِ فایل‌محور (اتمیک با flock).
function rateLimit(string $key, int $max, int $windowSecs): bool {
    $dir = sys_get_temp_dir() . '/borjsaz_rl';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);

    $fp = @fopen($dir . '/' . md5($key) . '.json', 'c+');
    if (!$fp) return true;
    if (!flock($fp, LOCK_EX)) { fclose($fp); return true; }

    $now  = time();
    $hits = json_decode(stream_get_contents($fp) ?: '[]', true) ?: [];
    $hits = array_values(array_filter($hits, fn($t) => ($now - $t) < $windowSecs));
    $ok   = count($hits) < $max;
    if ($ok) {
        $hits[] = $now;
        rewind($fp);
        ftruncate($fp, 0);
        fwrite($fp, json_encode($hits));
        fflush($fp);
    }
    flock($fp, LOCK_UN);
    fclose($fp);
    return $ok;
}
