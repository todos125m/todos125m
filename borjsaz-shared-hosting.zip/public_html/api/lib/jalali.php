<?php
// تبدیل تاریخ شمسی ↔ میلادی برای متن پیامک‌ها و گزارش‌ها (همان الگوریتمِ web/src/lib/jalali.js).

const FA_MONTHS = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];

function gregorianToJalali(int $gy, int $gm, int $gd): array {
    $gdm = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
    $gy2 = $gm > 2 ? $gy + 1 : $gy;
    $days = 355666 + 365 * $gy + intdiv($gy2 + 3, 4) - intdiv($gy2 + 99, 100) + intdiv($gy2 + 399, 400) + $gd + $gdm[$gm - 1];
    $jy = -1595 + 33 * intdiv($days, 12053);
    $days %= 12053;
    $jy += 4 * intdiv($days, 1461);
    $days %= 1461;
    if ($days > 365) {
        $jy += intdiv($days - 1, 365);
        $days = ($days - 1) % 365;
    }
    $jm = $days < 186 ? 1 + intdiv($days, 31) : 7 + intdiv($days - 186, 30);
    $jd = 1 + ($days < 186 ? $days % 31 : ($days - 186) % 30);
    return [$jy, $jm, $jd];
}

function jalaliToGregorian(int $jy, int $jm, int $jd): array {
    $jy += 1595;
    $days = -355668 + 365 * $jy + intdiv($jy, 33) * 8 + intdiv(($jy % 33) + 3, 4) + $jd + ($jm < 7 ? ($jm - 1) * 31 : ($jm - 7) * 30 + 186);
    $gy = 400 * intdiv($days, 146097);
    $days %= 146097;
    if ($days > 36524) {
        $gy += 100 * intdiv(--$days, 36524);
        $days %= 36524;
        if ($days >= 365) $days++;
    }
    $gy += 4 * intdiv($days, 1461);
    $days %= 1461;
    if ($days > 365) {
        $gy += intdiv($days - 1, 365);
        $days = ($days - 1) % 365;
    }
    $gd = $days + 1;
    $leap = ($gy % 4 === 0 && $gy % 100 !== 0) || $gy % 400 === 0;
    $sal = [0, 31, $leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    for ($gm = 1; $gm <= 12 && $gd > $sal[$gm]; $gm++) $gd -= $sal[$gm];
    return [$gy, $gm, $gd];
}

function faDigits($v): string {
    return strtr((string) $v, ['0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴', '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹']);
}

/** '2025-09-22' → '۱۴۰۴/۰۶/۳۱' */
function faDate(?string $iso): string {
    if (!$iso || !preg_match('/^(\d{4})-(\d{2})-(\d{2})/', $iso, $m)) return '';
    [$y, $mo, $d] = gregorianToJalali((int) $m[1], (int) $m[2], (int) $m[3]);
    return faDigits(sprintf('%04d/%02d/%02d', $y, $mo, $d));
}

/** '1404-06' → 'شهریور ۱۴۰۴' */
function faPeriod(string $period): string {
    [$y, $m] = array_map('intval', preg_split('#[-/]#', $period));
    return (FA_MONTHS[$m - 1] ?? '') . ' ' . faDigits($y);
}

/** بازه‌ی میلادیِ یک ماه شمسی: ['2025-08-23', '2025-09-22'] */
function periodRange(string $period): array {
    [$y, $m] = array_map('intval', preg_split('#[-/]#', $period));
    $days = $m <= 6 ? 31 : ($m <= 11 ? 30 : (isJalaliLeap($y) ? 30 : 29));
    $from = jalaliToGregorian($y, $m, 1);
    $to   = jalaliToGregorian($y, $m, $days);
    return [sprintf('%04d-%02d-%02d', ...$from), sprintf('%04d-%02d-%02d', ...$to)];
}

function isJalaliLeap(int $jy): bool {
    // اگر ۳۰ اسفند به ۱ فروردینِ سال بعد نرسد، سال کبیسه است.
    $a = jalaliToGregorian($jy, 12, 30);
    $b = jalaliToGregorian($jy + 1, 1, 1);
    return sprintf('%04d-%02d-%02d', ...$a) !== sprintf('%04d-%02d-%02d', ...$b);
}

function currentPeriod(): string {
    [$y, $m] = gregorianToJalali((int) date('Y'), (int) date('n'), (int) date('j'));
    return sprintf('%04d/%02d', $y, $m);
}

function faMoney(int $amount): string {
    return faDigits(number_format($amount, 0, '.', '٬')) . ' تومان';
}
