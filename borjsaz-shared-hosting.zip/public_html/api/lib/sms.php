<?php
// ارسال کد تأیید با SMS.ir (قالب verify). در حالت dev چیزی ارسال نمی‌شود.

function sendOtpSms(string $mobile, string $code): bool {
    if (APP_ENV === 'dev') return true;

    $ch = curl_init('https://api.sms.ir/v1/send/verify');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_TIMEOUT        => 15,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'Accept: text/plain',
            'x-api-key: ' . SMS_IR_API_KEY,
        ],
        CURLOPT_POSTFIELDS => json_encode([
            'mobile'     => $mobile,
            'templateId' => SMS_IR_TEMPLATE_ID,
            'parameters' => [['name' => 'CODE', 'value' => $code]],
        ]),
    ]);
    $response = curl_exec($ch);
    $err      = curl_error($ch);
    curl_close($ch);

    if ($err) {
        error_log("borjsaz sms: $err");
        return false;
    }
    $data = json_decode((string) $response, true);
    if (($data['status'] ?? 0) !== 1) {
        error_log('borjsaz sms: ' . ($data['message'] ?? $response));
        return false;
    }
    return true;
}

// ================= پیامک‌های اطلاع‌رسانی (خط خدماتی SMS.ir) =================
// هر پیامک در sms_log ثبت می‌شود. در dev یا بدون شماره‌ی خط چیزی ارسال نمی‌شود (وضعیت dev/skipped).

/** ارسال «نظیر به نظیر»: هر شماره متن خودش را می‌گیرد. خروجی: وضعیت ارسال ('sent'|'failed'|'dev'|'skipped'). */
function smsSendMany(array $mobiles, array $texts): string {
    if (APP_ENV === 'dev') return 'dev';
    if (!defined('SMS_IR_LINE_NUMBER') || !SMS_IR_LINE_NUMBER) return 'skipped';
    $ch = curl_init('https://api.sms.ir/v1/send/likeToLike');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'Accept: text/plain', 'x-api-key: ' . SMS_IR_API_KEY],
        CURLOPT_POSTFIELDS     => json_encode([
            'lineNumber'   => (int) SMS_IR_LINE_NUMBER,
            'messageTexts' => array_values($texts),
            'mobiles'      => array_values($mobiles),
        ]),
    ]);
    $response = curl_exec($ch);
    $err = curl_error($ch);
    curl_close($ch);
    if ($err) {
        error_log("borjsaz sms bulk: $err");
        return 'failed';
    }
    $data = json_decode((string) $response, true);
    if (($data['status'] ?? 0) !== 1) {
        error_log('borjsaz sms bulk: ' . ($data['message'] ?? $response));
        return 'failed';
    }
    return 'sent';
}

/**
 * ارسال و ثبت. $messages: [[mobile, text], ...] — شماره‌های تکراری با متن یکسان یک‌بار فرستاده می‌شوند.
 * خروجی: ['count' => n, 'status' => ...]
 */
function smsNotify(int $bid, string $kind, array $messages): array {
    $seen = [];
    $mobiles = $texts = [];
    foreach ($messages as [$mobile, $text]) {
        $mobile = normalizeMobile($mobile ?? '');
        if (!$mobile || isset($seen["$mobile|$text"])) continue;
        $seen["$mobile|$text"] = true;
        $mobiles[] = $mobile;
        $texts[] = $text;
    }
    if (!$mobiles) return ['count' => 0, 'status' => 'none'];

    $status = 'sent';
    foreach (array_chunk(array_keys($mobiles), 100) as $chunk) {
        $s = smsSendMany(array_map(fn($i) => $mobiles[$i], $chunk), array_map(fn($i) => $texts[$i], $chunk));
        if ($s !== 'sent') $status = $s;
        $ins = db()->prepare('INSERT INTO sms_log (building_id, mobile, kind, text, status, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)');
        foreach ($chunk as $i) $ins->execute([$bid, $mobiles[$i], $kind, $texts[$i], $s, authUserId(), now()]);
    }
    return ['count' => count($mobiles), 'status' => $status];
}

/** امضای پیامک‌ها: نام ساختمان + نشانی سامانه (در صورت تعریف). */
function smsFooter(array $building): string {
    $url = defined('APP_URL') && APP_URL ? "\n" . APP_URL : '';
    return "\n{$building['name']}$url";
}
