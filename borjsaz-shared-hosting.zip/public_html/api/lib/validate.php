<?php
// تبدیل ارقام فارسی/عربی و اعتبارسنجی فیلدها.

function toEnDigits($value): string {
    return strtr((string) $value, [
        '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
        '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
        '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
        '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
    ]);
}

// 09123456789 / 9123456789 / +989123456789 / 00989123456789 → 09123456789، وگرنه null
function normalizeMobile($value): ?string {
    $v = preg_replace('/[\s\-()]/', '', toEnDigits($value));
    $v = preg_replace('/^(\+98|0098|98)/', '0', $v);
    if (preg_match('/^9\d{9}$/', $v)) $v = '0' . $v;
    return preg_match('/^09\d{9}$/', $v) ? $v : null;
}

function cleanStr($value, int $maxLen): string {
    $v = trim(preg_replace('/\s+/u', ' ', (string) $value));
    return mb_substr($v, 0, $maxLen);
}

function optInt($value, int $min, int $max): ?int {
    if ($value === null || $value === '') return null;
    $v = toEnDigits($value);
    if (!preg_match('/^-?\d+$/', trim($v))) return null;
    return max($min, min($max, (int) $v));
}

function optDecimal($value, float $max): ?float {
    if ($value === null || $value === '') return null;
    $v = str_replace(['٫', '/', ','], '.', toEnDigits($value));
    if (!is_numeric(trim($v))) return null;
    $f = round((float) $v, 2);
    return ($f < 0 || $f > $max) ? null : $f;
}

function oneOf($value, array $allowed, string $default): string {
    return in_array($value, $allowed, true) ? $value : $default;
}

// مبلغ به تومان: «۱٬۲۰۰٬۰۰۰» یا «1,200,000» → 1200000؛ نامعتبر → null
function money($value, bool $allowNegative = false): ?int {
    if ($value === null || $value === '') return null;
    $v = preg_replace('/[\s,٬،]/u', '', toEnDigits($value));
    if (!preg_match($allowNegative ? '/^-?\d{1,13}$/' : '/^\d{1,13}$/', $v)) return null;
    return (int) $v;
}

// تاریخ میلادیِ ISO (فرانت تاریخ شمسی را تبدیل می‌کند)
function isoDate($value): ?string {
    $v = (string) $value;
    if (!preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $v, $m) || !checkdate((int) $m[2], (int) $m[3], (int) $m[1])) return null;
    return $v;
}

// دوره‌ی شمسی «1405/07»
function jalaliPeriod($value): ?string {
    $v = str_replace('-', '/', toEnDigits(trim((string) $value)));
    return preg_match('#^1[34]\d\d/(0[1-9]|1[0-2])$#', $v) ? $v : null;
}


// شبا: IR + ۲۴ رقم، با بررسیِ رقمِ کنترلی (ISO 13616)
function normalizeSheba($value): ?string {
    $v = strtoupper(preg_replace('/[\s\-]/', '', toEnDigits($value)));
    if (preg_match('/^\d{24}$/', $v)) $v = 'IR' . $v;
    if (!preg_match('/^IR\d{24}$/', $v)) return null;
    $numeric = substr($v, 4) . '1827' . substr($v, 2, 2); // I=18, R=27
    $mod = 0;
    foreach (str_split($numeric) as $d) $mod = ($mod * 10 + (int) $d) % 97;
    return $mod === 1 ? $v : null;
}

// شماره کارت ۱۶ رقمی با الگوریتم لوهن
function normalizeCard($value): ?string {
    $v = preg_replace('/[\s\-]/', '', toEnDigits($value));
    if (!preg_match('/^\d{16}$/', $v)) return null;
    $sum = 0;
    foreach (str_split($v) as $i => $d) {
        $d = (int) $d;
        if ($i % 2 === 0) { $d *= 2; if ($d > 9) $d -= 9; }
        $sum += $d;
    }
    return $sum % 10 === 0 ? $v : null;
}
