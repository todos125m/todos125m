-- برج‌ساز — اسکیمای MySQL (فاز ۱: ساختمان و واحدها)
-- در phpMyAdmin روی دیتابیسِ خالی اجرا کنید.

SET NAMES utf8mb4;

CREATE TABLE users (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  mobile      VARCHAR(11)  NOT NULL UNIQUE,
  full_name   VARCHAR(120) NOT NULL DEFAULT '',
  created_at  DATETIME     NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE otp_codes (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  mobile      VARCHAR(11) NOT NULL,
  code_hash   CHAR(64)    NOT NULL,
  expires_at  DATETIME    NOT NULL,
  attempts    TINYINT UNSIGNED NOT NULL DEFAULT 0,
  used        TINYINT(1)  NOT NULL DEFAULT 0,
  created_at  DATETIME    NOT NULL,
  INDEX idx_otp_mobile (mobile, used)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE buildings (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(120) NOT NULL,
  type        VARCHAR(20)  NOT NULL DEFAULT 'residential',
  city        VARCHAR(60)  NOT NULL DEFAULT '',
  address     VARCHAR(300) NOT NULL DEFAULT '',
  floors      SMALLINT     NULL,
  blocks      SMALLINT     NULL,
  created_by  INT UNSIGNED NOT NULL,
  created_at  DATETIME     NOT NULL,
  updated_at  DATETIME     NOT NULL,
  FOREIGN KEY (created_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- نقش‌ها: manager (مدیر)، board (هیئت‌مدیره، فقط‌خواندنی)، accountant (حسابدار)
CREATE TABLE building_members (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  building_id INT UNSIGNED NOT NULL,
  user_id     INT UNSIGNED NOT NULL,
  role        VARCHAR(20)  NOT NULL,
  created_at  DATETIME     NOT NULL,
  UNIQUE KEY uq_member (building_id, user_id),
  FOREIGN KEY (building_id) REFERENCES buildings(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id)     REFERENCES users(id)     ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- occupancy: owner (مالک‌نشین)، tenant (استیجاری)، vacant (خالی)
CREATE TABLE units (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  building_id     INT UNSIGNED NOT NULL,
  title           VARCHAR(60)  NOT NULL,
  block           VARCHAR(30)  NOT NULL DEFAULT '',
  floor           SMALLINT     NULL,
  area            DECIMAL(8,2) NULL,
  residents_count SMALLINT     NOT NULL DEFAULT 0,
  parking_count   SMALLINT     NOT NULL DEFAULT 0,
  has_storage     TINYINT(1)   NOT NULL DEFAULT 0,
  occupancy       VARCHAR(10)  NOT NULL DEFAULT 'owner',
  notes           VARCHAR(500) NOT NULL DEFAULT '',
  created_at      DATETIME     NOT NULL,
  updated_at      DATETIME     NOT NULL,
  UNIQUE KEY uq_unit (building_id, block, title),
  FOREIGN KEY (building_id) REFERENCES buildings(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- role: owner (مالک)، tenant (مستأجر)
CREATE TABLE persons (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  building_id   INT UNSIGNED NOT NULL,
  unit_id       INT UNSIGNED NOT NULL,
  role          VARCHAR(10)  NOT NULL,
  full_name     VARCHAR(120) NOT NULL,
  mobile        VARCHAR(11)  NULL,
  move_in_date  VARCHAR(10)  NOT NULL DEFAULT '',
  notes         VARCHAR(500) NOT NULL DEFAULT '',
  created_at    DATETIME     NOT NULL,
  updated_at    DATETIME     NOT NULL,
  INDEX idx_person_mobile (mobile),
  FOREIGN KEY (building_id) REFERENCES buildings(id) ON DELETE CASCADE,
  FOREIGN KEY (unit_id)     REFERENCES units(id)     ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
