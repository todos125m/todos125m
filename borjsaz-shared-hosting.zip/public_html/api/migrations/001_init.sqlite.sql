-- برج‌ساز — اسکیمای SQLite (فقط توسعه‌ی محلی؛ هم‌ارزِ schema.mysql.sql)

CREATE TABLE users (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  mobile      TEXT NOT NULL UNIQUE,
  full_name   TEXT NOT NULL DEFAULT '',
  created_at  TEXT NOT NULL
);

CREATE TABLE otp_codes (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  mobile      TEXT NOT NULL,
  code_hash   TEXT NOT NULL,
  expires_at  TEXT NOT NULL,
  attempts    INTEGER NOT NULL DEFAULT 0,
  used        INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT NOT NULL
);
CREATE INDEX idx_otp_mobile ON otp_codes (mobile, used);

CREATE TABLE buildings (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  name        TEXT NOT NULL,
  type        TEXT NOT NULL DEFAULT 'residential',
  city        TEXT NOT NULL DEFAULT '',
  address     TEXT NOT NULL DEFAULT '',
  floors      INTEGER NULL,
  blocks      INTEGER NULL,
  created_by  INTEGER NOT NULL REFERENCES users(id),
  created_at  TEXT NOT NULL,
  updated_at  TEXT NOT NULL
);

CREATE TABLE building_members (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  building_id INTEGER NOT NULL REFERENCES buildings(id) ON DELETE CASCADE,
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role        TEXT NOT NULL,
  created_at  TEXT NOT NULL,
  UNIQUE (building_id, user_id)
);

CREATE TABLE units (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  building_id     INTEGER NOT NULL REFERENCES buildings(id) ON DELETE CASCADE,
  title           TEXT NOT NULL,
  block           TEXT NOT NULL DEFAULT '',
  floor           INTEGER NULL,
  area            REAL NULL,
  residents_count INTEGER NOT NULL DEFAULT 0,
  parking_count   INTEGER NOT NULL DEFAULT 0,
  has_storage     INTEGER NOT NULL DEFAULT 0,
  occupancy       TEXT NOT NULL DEFAULT 'owner',
  notes           TEXT NOT NULL DEFAULT '',
  created_at      TEXT NOT NULL,
  updated_at      TEXT NOT NULL,
  UNIQUE (building_id, block, title)
);

CREATE TABLE persons (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  building_id   INTEGER NOT NULL REFERENCES buildings(id) ON DELETE CASCADE,
  unit_id       INTEGER NOT NULL REFERENCES units(id) ON DELETE CASCADE,
  role          TEXT NOT NULL,
  full_name     TEXT NOT NULL,
  mobile        TEXT NULL,
  move_in_date  TEXT NOT NULL DEFAULT '',
  notes         TEXT NOT NULL DEFAULT '',
  created_at    TEXT NOT NULL,
  updated_at    TEXT NOT NULL
);
CREATE INDEX idx_person_mobile ON persons (mobile);
