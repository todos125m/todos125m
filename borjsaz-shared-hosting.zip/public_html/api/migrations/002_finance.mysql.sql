-- فاز ۲: مدیریت مالی. مبالغ به تومان (عدد صحیح).

ALTER TABLE buildings
  ADD COLUMN postal_code           VARCHAR(10)  NOT NULL DEFAULT '',
  ADD COLUMN opening_balance       BIGINT       NOT NULL DEFAULT 0,
  ADD COLUMN charge_fixed          BIGINT       NOT NULL DEFAULT 0,
  ADD COLUMN charge_per_sqm        BIGINT       NOT NULL DEFAULT 0,
  ADD COLUMN charge_per_person     BIGINT       NOT NULL DEFAULT 0,
  ADD COLUMN charge_vacant_percent SMALLINT     NOT NULL DEFAULT 100,
  ADD COLUMN charge_round          INT          NOT NULL DEFAULT 1000,
  ADD COLUMN charge_due_day        SMALLINT     NOT NULL DEFAULT 10,
  ADD COLUMN late_fee_percent      DECIMAL(5,2) NOT NULL DEFAULT 0,
  ADD COLUMN late_fee_grace_days   SMALLINT     NOT NULL DEFAULT 0,
  ADD COLUMN good_payer_percent    DECIMAL(5,2) NOT NULL DEFAULT 0,
  ADD COLUMN bank_name             VARCHAR(60)  NOT NULL DEFAULT '',
  ADD COLUMN bank_holder           VARCHAR(120) NOT NULL DEFAULT '',
  ADD COLUMN bank_sheba            VARCHAR(26)  NOT NULL DEFAULT '',
  ADD COLUMN bank_card             VARCHAR(16)  NOT NULL DEFAULT '';

ALTER TABLE units ADD COLUMN charge_override BIGINT NULL;

-- هزینه‌ها (out) و درآمدهای ساختمان (in)
CREATE TABLE fund_entries (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  building_id INT UNSIGNED NOT NULL,
  direction   VARCHAR(3)   NOT NULL,
  category    VARCHAR(20)  NOT NULL,
  amount      BIGINT       NOT NULL,
  date        DATE         NOT NULL,
  title       VARCHAR(150) NOT NULL DEFAULT '',
  notes       VARCHAR(500) NOT NULL DEFAULT '',
  allocate    VARCHAR(10)  NOT NULL DEFAULT 'none',
  created_by  INT UNSIGNED NOT NULL,
  created_at  DATETIME     NOT NULL,
  INDEX idx_fund_date (building_id, date),
  FOREIGN KEY (building_id) REFERENCES buildings(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- دفتر حساب واحدها. بدهکار: charge, debt, penalty — بستانکار: payment, discount
CREATE TABLE unit_transactions (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  building_id   INT UNSIGNED NOT NULL,
  unit_id       INT UNSIGNED NOT NULL,
  kind          VARCHAR(10)  NOT NULL,
  amount        BIGINT       NOT NULL,
  title         VARCHAR(150) NOT NULL DEFAULT '',
  period        VARCHAR(7)   NOT NULL DEFAULT '',
  due_date      DATE         NULL,
  date          DATE         NOT NULL,
  method        VARCHAR(10)  NOT NULL DEFAULT '',
  ref_no        VARCHAR(40)  NOT NULL DEFAULT '',
  notes         VARCHAR(500) NOT NULL DEFAULT '',
  fund_entry_id INT UNSIGNED NULL,
  created_by    INT UNSIGNED NOT NULL,
  created_at    DATETIME     NOT NULL,
  INDEX idx_tx_unit (unit_id, date),
  INDEX idx_tx_period (building_id, period, kind),
  FOREIGN KEY (building_id)   REFERENCES buildings(id)    ON DELETE CASCADE,
  FOREIGN KEY (unit_id)       REFERENCES units(id)        ON DELETE CASCADE,
  FOREIGN KEY (fund_entry_id) REFERENCES fund_entries(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
