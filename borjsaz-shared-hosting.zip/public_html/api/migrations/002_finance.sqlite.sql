-- فاز ۲: مدیریت مالی (هم‌ارزِ 002_finance.mysql.sql)

ALTER TABLE buildings ADD COLUMN postal_code TEXT NOT NULL DEFAULT '';
ALTER TABLE buildings ADD COLUMN opening_balance INTEGER NOT NULL DEFAULT 0;
ALTER TABLE buildings ADD COLUMN charge_fixed INTEGER NOT NULL DEFAULT 0;
ALTER TABLE buildings ADD COLUMN charge_per_sqm INTEGER NOT NULL DEFAULT 0;
ALTER TABLE buildings ADD COLUMN charge_per_person INTEGER NOT NULL DEFAULT 0;
ALTER TABLE buildings ADD COLUMN charge_vacant_percent INTEGER NOT NULL DEFAULT 100;
ALTER TABLE buildings ADD COLUMN charge_round INTEGER NOT NULL DEFAULT 1000;
ALTER TABLE buildings ADD COLUMN charge_due_day INTEGER NOT NULL DEFAULT 10;
ALTER TABLE buildings ADD COLUMN late_fee_percent REAL NOT NULL DEFAULT 0;
ALTER TABLE buildings ADD COLUMN late_fee_grace_days INTEGER NOT NULL DEFAULT 0;
ALTER TABLE buildings ADD COLUMN good_payer_percent REAL NOT NULL DEFAULT 0;
ALTER TABLE buildings ADD COLUMN bank_name TEXT NOT NULL DEFAULT '';
ALTER TABLE buildings ADD COLUMN bank_holder TEXT NOT NULL DEFAULT '';
ALTER TABLE buildings ADD COLUMN bank_sheba TEXT NOT NULL DEFAULT '';
ALTER TABLE buildings ADD COLUMN bank_card TEXT NOT NULL DEFAULT '';

ALTER TABLE units ADD COLUMN charge_override INTEGER NULL;

CREATE TABLE fund_entries (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  building_id INTEGER NOT NULL REFERENCES buildings(id) ON DELETE CASCADE,
  direction   TEXT NOT NULL,
  category    TEXT NOT NULL,
  amount      INTEGER NOT NULL,
  date        TEXT NOT NULL,
  title       TEXT NOT NULL DEFAULT '',
  notes       TEXT NOT NULL DEFAULT '',
  allocate    TEXT NOT NULL DEFAULT 'none',
  created_by  INTEGER NOT NULL,
  created_at  TEXT NOT NULL
);
CREATE INDEX idx_fund_date ON fund_entries (building_id, date);

CREATE TABLE unit_transactions (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  building_id   INTEGER NOT NULL REFERENCES buildings(id) ON DELETE CASCADE,
  unit_id       INTEGER NOT NULL REFERENCES units(id) ON DELETE CASCADE,
  kind          TEXT NOT NULL,
  amount        INTEGER NOT NULL,
  title         TEXT NOT NULL DEFAULT '',
  period        TEXT NOT NULL DEFAULT '',
  due_date      TEXT NULL,
  date          TEXT NOT NULL,
  method        TEXT NOT NULL DEFAULT '',
  ref_no        TEXT NOT NULL DEFAULT '',
  notes         TEXT NOT NULL DEFAULT '',
  fund_entry_id INTEGER NULL REFERENCES fund_entries(id) ON DELETE CASCADE,
  created_by    INTEGER NOT NULL,
  created_at    TEXT NOT NULL
);
CREATE INDEX idx_tx_unit ON unit_transactions (unit_id, date);
CREATE INDEX idx_tx_period ON unit_transactions (building_id, period, kind);
