-- فاز ۳: درخواست‌های خدماتی، نیروها، تجهیزات و سرویس دوره‌ای

CREATE TABLE staff (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  building_id   INT UNSIGNED NOT NULL,
  full_name     VARCHAR(120) NOT NULL,
  mobile        VARCHAR(11)  NULL,
  specialty     VARCHAR(60)  NOT NULL DEFAULT '',
  kind          VARCHAR(12)  NOT NULL DEFAULT 'internal',
  default_types VARCHAR(200) NOT NULL DEFAULT '',
  notes         VARCHAR(500) NOT NULL DEFAULT '',
  active        TINYINT(1)   NOT NULL DEFAULT 1,
  created_at    DATETIME     NOT NULL,
  FOREIGN KEY (building_id) REFERENCES buildings(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE equipment (
  id                    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  building_id           INT UNSIGNED NOT NULL,
  name                  VARCHAR(120) NOT NULL,
  category              VARCHAR(20)  NOT NULL DEFAULT 'other',
  location              VARCHAR(120) NOT NULL DEFAULT '',
  staff_id              INT UNSIGNED NULL,
  service_interval_days SMALLINT     NULL,
  last_service_date     DATE         NULL,
  notes                 VARCHAR(500) NOT NULL DEFAULT '',
  active                TINYINT(1)   NOT NULL DEFAULT 1,
  created_at            DATETIME     NOT NULL,
  updated_at            DATETIME     NOT NULL,
  FOREIGN KEY (building_id) REFERENCES buildings(id) ON DELETE CASCADE,
  FOREIGN KEY (staff_id)    REFERENCES staff(id)     ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE equipment_services (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  building_id   INT UNSIGNED NOT NULL,
  equipment_id  INT UNSIGNED NOT NULL,
  date          DATE         NOT NULL,
  cost          BIGINT       NOT NULL DEFAULT 0,
  description   VARCHAR(500) NOT NULL DEFAULT '',
  staff_id      INT UNSIGNED NULL,
  fund_entry_id INT UNSIGNED NULL,
  created_by    INT UNSIGNED NOT NULL,
  created_at    DATETIME     NOT NULL,
  INDEX idx_es_equipment (equipment_id, date),
  FOREIGN KEY (building_id)   REFERENCES buildings(id)    ON DELETE CASCADE,
  FOREIGN KEY (equipment_id)  REFERENCES equipment(id)    ON DELETE CASCADE,
  FOREIGN KEY (staff_id)      REFERENCES staff(id)        ON DELETE SET NULL,
  FOREIGN KEY (fund_entry_id) REFERENCES fund_entries(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- status: new → approved → assigned → done → closed ؛ rejected از هر مرحله‌ی باز
CREATE TABLE service_requests (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  building_id   INT UNSIGNED NOT NULL,
  unit_id       INT UNSIGNED NULL,
  equipment_id  INT UNSIGNED NULL,
  type          VARCHAR(20)  NOT NULL,
  priority      VARCHAR(10)  NOT NULL DEFAULT 'normal',
  title         VARCHAR(150) NOT NULL,
  description   VARCHAR(1000) NOT NULL DEFAULT '',
  reporter_name VARCHAR(120) NOT NULL DEFAULT '',
  status        VARCHAR(10)  NOT NULL DEFAULT 'new',
  assigned_to   INT UNSIGNED NULL,
  cost          BIGINT       NULL,
  work_notes    VARCHAR(1000) NOT NULL DEFAULT '',
  fund_entry_id INT UNSIGNED NULL,
  created_by    INT UNSIGNED NOT NULL,
  created_at    DATETIME     NOT NULL,
  updated_at    DATETIME     NOT NULL,
  done_at       DATETIME     NULL,
  closed_at     DATETIME     NULL,
  INDEX idx_sr_status (building_id, status),
  FOREIGN KEY (building_id)   REFERENCES buildings(id)    ON DELETE CASCADE,
  FOREIGN KEY (unit_id)       REFERENCES units(id)        ON DELETE SET NULL,
  FOREIGN KEY (equipment_id)  REFERENCES equipment(id)    ON DELETE SET NULL,
  FOREIGN KEY (assigned_to)   REFERENCES staff(id)        ON DELETE SET NULL,
  FOREIGN KEY (fund_entry_id) REFERENCES fund_entries(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE request_events (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  request_id  INT UNSIGNED NOT NULL,
  status      VARCHAR(10)  NOT NULL,
  note        VARCHAR(500) NOT NULL DEFAULT '',
  user_id     INT UNSIGNED NULL,
  created_at  DATETIME     NOT NULL,
  FOREIGN KEY (request_id) REFERENCES service_requests(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
