-- فاز ۳: درخواست‌های خدماتی، نیروها، تجهیزات و سرویس دوره‌ای (هم‌ارزِ نسخه‌ی MySQL)

CREATE TABLE staff (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  building_id   INTEGER NOT NULL REFERENCES buildings(id) ON DELETE CASCADE,
  full_name     TEXT NOT NULL,
  mobile        TEXT NULL,
  specialty     TEXT NOT NULL DEFAULT '',
  kind          TEXT NOT NULL DEFAULT 'internal',
  default_types TEXT NOT NULL DEFAULT '',
  notes         TEXT NOT NULL DEFAULT '',
  active        INTEGER NOT NULL DEFAULT 1,
  created_at    TEXT NOT NULL
);

CREATE TABLE equipment (
  id                    INTEGER PRIMARY KEY AUTOINCREMENT,
  building_id           INTEGER NOT NULL REFERENCES buildings(id) ON DELETE CASCADE,
  name                  TEXT NOT NULL,
  category              TEXT NOT NULL DEFAULT 'other',
  location              TEXT NOT NULL DEFAULT '',
  staff_id              INTEGER NULL REFERENCES staff(id) ON DELETE SET NULL,
  service_interval_days INTEGER NULL,
  last_service_date     TEXT NULL,
  notes                 TEXT NOT NULL DEFAULT '',
  active                INTEGER NOT NULL DEFAULT 1,
  created_at            TEXT NOT NULL,
  updated_at            TEXT NOT NULL
);

CREATE TABLE equipment_services (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  building_id   INTEGER NOT NULL REFERENCES buildings(id) ON DELETE CASCADE,
  equipment_id  INTEGER NOT NULL REFERENCES equipment(id) ON DELETE CASCADE,
  date          TEXT NOT NULL,
  cost          INTEGER NOT NULL DEFAULT 0,
  description   TEXT NOT NULL DEFAULT '',
  staff_id      INTEGER NULL REFERENCES staff(id) ON DELETE SET NULL,
  fund_entry_id INTEGER NULL REFERENCES fund_entries(id) ON DELETE SET NULL,
  created_by    INTEGER NOT NULL,
  created_at    TEXT NOT NULL
);
CREATE INDEX idx_es_equipment ON equipment_services (equipment_id, date);

CREATE TABLE service_requests (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  building_id   INTEGER NOT NULL REFERENCES buildings(id) ON DELETE CASCADE,
  unit_id       INTEGER NULL REFERENCES units(id) ON DELETE SET NULL,
  equipment_id  INTEGER NULL REFERENCES equipment(id) ON DELETE SET NULL,
  type          TEXT NOT NULL,
  priority      TEXT NOT NULL DEFAULT 'normal',
  title         TEXT NOT NULL,
  description   TEXT NOT NULL DEFAULT '',
  reporter_name TEXT NOT NULL DEFAULT '',
  status        TEXT NOT NULL DEFAULT 'new',
  assigned_to   INTEGER NULL REFERENCES staff(id) ON DELETE SET NULL,
  cost          INTEGER NULL,
  work_notes    TEXT NOT NULL DEFAULT '',
  fund_entry_id INTEGER NULL REFERENCES fund_entries(id) ON DELETE SET NULL,
  created_by    INTEGER NOT NULL,
  created_at    TEXT NOT NULL,
  updated_at    TEXT NOT NULL,
  done_at       TEXT NULL,
  closed_at     TEXT NULL
);
CREATE INDEX idx_sr_status ON service_requests (building_id, status);

CREATE TABLE request_events (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  request_id  INTEGER NOT NULL REFERENCES service_requests(id) ON DELETE CASCADE,
  status      TEXT NOT NULL,
  note        TEXT NOT NULL DEFAULT '',
  user_id     INTEGER NULL,
  created_at  TEXT NOT NULL
);
