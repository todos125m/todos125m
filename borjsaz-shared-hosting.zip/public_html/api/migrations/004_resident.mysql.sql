-- فاز ۵ (پیش‌افتاده): پنل ساکن — اعلام واریز توسط ساکن و تأیید مدیریت

CREATE TABLE payment_claims (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  building_id  INT UNSIGNED NOT NULL,
  unit_id      INT UNSIGNED NOT NULL,
  user_id      INT UNSIGNED NOT NULL,
  amount       BIGINT       NOT NULL,
  date         DATE         NOT NULL,
  ref_no       VARCHAR(40)  NOT NULL DEFAULT '',
  note         VARCHAR(500) NOT NULL DEFAULT '',
  status       VARCHAR(10)  NOT NULL DEFAULT 'pending',
  review_note  VARCHAR(500) NOT NULL DEFAULT '',
  tx_id        INT UNSIGNED NULL,
  reviewed_by  INT UNSIGNED NULL,
  reviewed_at  DATETIME     NULL,
  created_at   DATETIME     NOT NULL,
  INDEX idx_claim_status (building_id, status),
  FOREIGN KEY (building_id) REFERENCES buildings(id)         ON DELETE CASCADE,
  FOREIGN KEY (unit_id)     REFERENCES units(id)             ON DELETE CASCADE,
  FOREIGN KEY (user_id)     REFERENCES users(id)             ON DELETE CASCADE,
  FOREIGN KEY (tx_id)       REFERENCES unit_transactions(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE service_requests ADD COLUMN source VARCHAR(10) NOT NULL DEFAULT 'manager';
