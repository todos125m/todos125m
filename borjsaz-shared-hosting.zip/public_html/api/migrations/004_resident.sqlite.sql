-- پنل ساکن — اعلام واریز توسط ساکن و تأیید مدیریت (هم‌ارزِ نسخه‌ی MySQL)

CREATE TABLE payment_claims (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  building_id  INTEGER NOT NULL REFERENCES buildings(id) ON DELETE CASCADE,
  unit_id      INTEGER NOT NULL REFERENCES units(id) ON DELETE CASCADE,
  user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  amount       INTEGER NOT NULL,
  date         TEXT NOT NULL,
  ref_no       TEXT NOT NULL DEFAULT '',
  note         TEXT NOT NULL DEFAULT '',
  status       TEXT NOT NULL DEFAULT 'pending',
  review_note  TEXT NOT NULL DEFAULT '',
  tx_id        INTEGER NULL REFERENCES unit_transactions(id) ON DELETE SET NULL,
  reviewed_by  INTEGER NULL,
  reviewed_at  TEXT NULL,
  created_at   TEXT NOT NULL
);
CREATE INDEX idx_claim_status ON payment_claims (building_id, status);

ALTER TABLE service_requests ADD COLUMN source TEXT NOT NULL DEFAULT 'manager';
