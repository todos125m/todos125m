-- ارتباطات و شفافیت: پیامک، ردپای تغییرات، اطلاعیه، جلسات هیئت‌مدیره، سهم مالک، پارکینگ

CREATE TABLE sms_log (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  building_id  INT UNSIGNED NOT NULL,
  mobile       VARCHAR(15)   NOT NULL,
  kind         VARCHAR(20)   NOT NULL,
  text         VARCHAR(1000) NOT NULL,
  status       VARCHAR(10)   NOT NULL,
  created_by   INT UNSIGNED  NULL,
  created_at   DATETIME      NOT NULL,
  INDEX idx_sms_building (building_id, id),
  FOREIGN KEY (building_id) REFERENCES buildings(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE audit_log (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  building_id  INT UNSIGNED NOT NULL,
  user_id      INT UNSIGNED NULL,
  action       VARCHAR(40)   NOT NULL,
  entity       VARCHAR(30)   NOT NULL DEFAULT '',
  entity_id    INT UNSIGNED  NULL,
  summary      VARCHAR(500)  NOT NULL,
  created_at   DATETIME      NOT NULL,
  INDEX idx_audit_building (building_id, id),
  FOREIGN KEY (building_id) REFERENCES buildings(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE notices (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  building_id  INT UNSIGNED NOT NULL,
  title        VARCHAR(150)  NOT NULL,
  body         TEXT          NOT NULL,
  pinned       TINYINT(1)    NOT NULL DEFAULT 0,
  created_by   INT UNSIGNED  NOT NULL,
  created_at   DATETIME      NOT NULL,
  updated_at   DATETIME      NOT NULL,
  INDEX idx_notice_building (building_id, id),
  FOREIGN KEY (building_id) REFERENCES buildings(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE meetings (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  building_id  INT UNSIGNED NOT NULL,
  title        VARCHAR(150)  NOT NULL,
  date         DATE          NOT NULL,
  attendees    VARCHAR(500)  NOT NULL DEFAULT '',
  minutes      TEXT          NOT NULL,
  created_by   INT UNSIGNED  NOT NULL,
  created_at   DATETIME      NOT NULL,
  updated_at   DATETIME      NOT NULL,
  INDEX idx_meeting_building (building_id, date),
  FOREIGN KEY (building_id) REFERENCES buildings(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE resolutions (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  building_id  INT UNSIGNED NOT NULL,
  meeting_id   INT UNSIGNED NOT NULL,
  title        VARCHAR(300)  NOT NULL,
  owner        VARCHAR(120)  NOT NULL DEFAULT '',
  due_date     DATE          NULL,
  status       VARCHAR(10)   NOT NULL DEFAULT 'open',
  done_note    VARCHAR(500)  NOT NULL DEFAULT '',
  done_at      DATETIME      NULL,
  created_at   DATETIME      NOT NULL,
  updated_at   DATETIME      NOT NULL,
  INDEX idx_resolution_status (building_id, status),
  FOREIGN KEY (building_id) REFERENCES buildings(id) ON DELETE CASCADE,
  FOREIGN KEY (meeting_id)  REFERENCES meetings(id)  ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE buildings ADD COLUMN charge_per_parking BIGINT NOT NULL DEFAULT 0;
ALTER TABLE buildings ADD COLUMN sms_notify_staff TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE unit_transactions ADD COLUMN payer VARCHAR(10) NOT NULL DEFAULT 'unit';
