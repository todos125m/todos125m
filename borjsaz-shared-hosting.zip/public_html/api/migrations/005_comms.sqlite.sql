-- ارتباطات و شفافیت: پیامک، ردپای تغییرات، اطلاعیه، جلسات هیئت‌مدیره، سهم مالک، پارکینگ (هم‌ارزِ نسخه‌ی MySQL)

CREATE TABLE sms_log (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  building_id  INTEGER NOT NULL REFERENCES buildings(id) ON DELETE CASCADE,
  mobile       TEXT NOT NULL,
  kind         TEXT NOT NULL,
  text         TEXT NOT NULL,
  status       TEXT NOT NULL,
  created_by   INTEGER NULL,
  created_at   TEXT NOT NULL
);
CREATE INDEX idx_sms_building ON sms_log (building_id, id);

CREATE TABLE audit_log (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  building_id  INTEGER NOT NULL REFERENCES buildings(id) ON DELETE CASCADE,
  user_id      INTEGER NULL,
  action       TEXT NOT NULL,
  entity       TEXT NOT NULL DEFAULT '',
  entity_id    INTEGER NULL,
  summary      TEXT NOT NULL,
  created_at   TEXT NOT NULL
);
CREATE INDEX idx_audit_building ON audit_log (building_id, id);

CREATE TABLE notices (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  building_id  INTEGER NOT NULL REFERENCES buildings(id) ON DELETE CASCADE,
  title        TEXT NOT NULL,
  body         TEXT NOT NULL DEFAULT '',
  pinned       INTEGER NOT NULL DEFAULT 0,
  created_by   INTEGER NOT NULL,
  created_at   TEXT NOT NULL,
  updated_at   TEXT NOT NULL
);
CREATE INDEX idx_notice_building ON notices (building_id, id);

CREATE TABLE meetings (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  building_id  INTEGER NOT NULL REFERENCES buildings(id) ON DELETE CASCADE,
  title        TEXT NOT NULL,
  date         TEXT NOT NULL,
  attendees    TEXT NOT NULL DEFAULT '',
  minutes      TEXT NOT NULL DEFAULT '',
  created_by   INTEGER NOT NULL,
  created_at   TEXT NOT NULL,
  updated_at   TEXT NOT NULL
);
CREATE INDEX idx_meeting_building ON meetings (building_id, date);

CREATE TABLE resolutions (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  building_id  INTEGER NOT NULL REFERENCES buildings(id) ON DELETE CASCADE,
  meeting_id   INTEGER NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
  title        TEXT NOT NULL,
  owner        TEXT NOT NULL DEFAULT '',
  due_date     TEXT NULL,
  status       TEXT NOT NULL DEFAULT 'open',
  done_note    TEXT NOT NULL DEFAULT '',
  done_at      TEXT NULL,
  created_at   TEXT NOT NULL,
  updated_at   TEXT NOT NULL
);
CREATE INDEX idx_resolution_status ON resolutions (building_id, status);

ALTER TABLE buildings ADD COLUMN charge_per_parking INTEGER NOT NULL DEFAULT 0;
ALTER TABLE buildings ADD COLUMN sms_notify_staff INTEGER NOT NULL DEFAULT 1;
ALTER TABLE unit_transactions ADD COLUMN payer TEXT NOT NULL DEFAULT 'unit';
