-- پنل سازنده: لاگ خطاهای سرور و مرورگر، آخرین فعالیت کاربران

CREATE TABLE error_log (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  source       VARCHAR(10)   NOT NULL,
  message      VARCHAR(1000) NOT NULL,
  detail       TEXT          NOT NULL,
  method       VARCHAR(10)   NOT NULL DEFAULT '',
  path         VARCHAR(300)  NOT NULL DEFAULT '',
  user_id      INT UNSIGNED  NULL,
  user_agent   VARCHAR(300)  NOT NULL DEFAULT '',
  ip           VARCHAR(45)   NOT NULL DEFAULT '',
  created_at   DATETIME      NOT NULL,
  INDEX idx_error_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE users ADD COLUMN last_seen_at DATETIME NULL;
