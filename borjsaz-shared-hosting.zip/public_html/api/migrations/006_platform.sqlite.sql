-- پنل سازنده: لاگ خطاهای سرور و مرورگر، آخرین فعالیت کاربران (هم‌ارزِ نسخه‌ی MySQL)

CREATE TABLE error_log (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  source       TEXT NOT NULL,
  message      TEXT NOT NULL,
  detail       TEXT NOT NULL DEFAULT '',
  method       TEXT NOT NULL DEFAULT '',
  path         TEXT NOT NULL DEFAULT '',
  user_id      INTEGER NULL,
  user_agent   TEXT NOT NULL DEFAULT '',
  ip           TEXT NOT NULL DEFAULT '',
  created_at   TEXT NOT NULL
);
CREATE INDEX idx_error_created ON error_log (created_at);

ALTER TABLE users ADD COLUMN last_seen_at TEXT NULL;
