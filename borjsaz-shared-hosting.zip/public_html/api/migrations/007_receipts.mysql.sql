-- عکس فیش واریز ساکن (فایل در data/receipts؛ اینجا فقط نام فایل)

ALTER TABLE payment_claims ADD COLUMN receipt VARCHAR(80) NOT NULL DEFAULT '';
