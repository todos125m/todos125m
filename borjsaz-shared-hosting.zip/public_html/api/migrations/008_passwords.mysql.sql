-- ورود با رمز عبور؛ پشتیبانی می‌تواند رمز را بازنشانی کند (داده‌های کاربر دست نمی‌خورد).
-- token_version: با تغییر/بازنشانی رمز، نشست‌های قبلی همه‌ی دستگاه‌ها باطل می‌شوند.

ALTER TABLE users ADD COLUMN password_hash VARCHAR(255) NOT NULL DEFAULT '';
ALTER TABLE users ADD COLUMN must_change_password TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE users ADD COLUMN token_version INT NOT NULL DEFAULT 0;
