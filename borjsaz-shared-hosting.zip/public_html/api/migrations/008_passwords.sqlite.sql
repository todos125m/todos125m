-- ورود با رمز عبور (هم‌ارزِ نسخه‌ی MySQL)

ALTER TABLE users ADD COLUMN password_hash TEXT NOT NULL DEFAULT '';
ALTER TABLE users ADD COLUMN must_change_password INTEGER NOT NULL DEFAULT 0;
ALTER TABLE users ADD COLUMN token_version INTEGER NOT NULL DEFAULT 0;
