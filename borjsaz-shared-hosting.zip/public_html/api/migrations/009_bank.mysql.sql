-- تطبیق خودکار واریزها با پیامک بانک (Tasker) یا فایل گردش حساب.
-- bank_events: هر پیامک/ردیف خام، یک‌بار (شناسه‌ی رویداد یکتا)؛ bank_deposits: فقط واریزها، با وضعیت تطبیق.

CREATE TABLE bank_devices (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  building_id  INT UNSIGNED NOT NULL,
  name         VARCHAR(60)  NOT NULL,
  token_hash   CHAR(64)     NOT NULL UNIQUE,
  last_seen_at DATETIME     NULL,
  revoked_at   DATETIME     NULL,
  created_by   INT UNSIGNED NOT NULL,
  created_at   DATETIME     NOT NULL,
  FOREIGN KEY (building_id) REFERENCES buildings(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE bank_events (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  building_id  INT UNSIGNED NOT NULL,
  device_id    INT UNSIGNED NULL,
  source       VARCHAR(10)  NOT NULL,
  external_id  VARCHAR(100) NOT NULL,
  sender       VARCHAR(40)  NOT NULL DEFAULT '',
  body         TEXT         NOT NULL,
  received_at  DATETIME     NOT NULL,
  status       VARCHAR(10)  NOT NULL DEFAULT 'new',
  direction    VARCHAR(6)   NOT NULL DEFAULT '',
  amount_rial  BIGINT       NULL,
  balance_rial BIGINT       NULL,
  occurred_at  DATETIME     NULL,
  ref_no       VARCHAR(40)  NOT NULL DEFAULT '',
  continuity   VARCHAR(8)   NOT NULL DEFAULT 'unknown',
  error        VARCHAR(200) NOT NULL DEFAULT '',
  created_at   DATETIME     NOT NULL,
  UNIQUE KEY uq_bank_event (building_id, source, external_id),
  INDEX idx_bank_event_status (building_id, status),
  FOREIGN KEY (building_id) REFERENCES buildings(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE bank_deposits (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  building_id  INT UNSIGNED NOT NULL,
  event_id     INT UNSIGNED NULL UNIQUE,
  amount       BIGINT       NOT NULL,
  occurred_at  DATETIME     NOT NULL,
  ref_no       VARCHAR(40)  NOT NULL DEFAULT '',
  status       VARCHAR(10)  NOT NULL DEFAULT 'unmatched',
  claim_id     INT UNSIGNED NULL,
  unit_id      INT UNSIGNED NULL,
  tx_id        INT UNSIGNED NULL,
  method       VARCHAR(8)   NOT NULL DEFAULT '',
  note         VARCHAR(300) NOT NULL DEFAULT '',
  reviewed_by  INT UNSIGNED NULL,
  reviewed_at  DATETIME     NULL,
  created_at   DATETIME     NOT NULL,
  INDEX idx_bank_dep_status (building_id, status),
  INDEX idx_bank_dep_claim (claim_id),
  INDEX idx_bank_dep_tx (tx_id),
  FOREIGN KEY (building_id) REFERENCES buildings(id) ON DELETE CASCADE,
  FOREIGN KEY (event_id)    REFERENCES bank_events(id) ON DELETE SET NULL,
  FOREIGN KEY (claim_id)    REFERENCES payment_claims(id) ON DELETE SET NULL,
  FOREIGN KEY (unit_id)     REFERENCES units(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE buildings ADD COLUMN bank_sms_unit VARCHAR(5) NOT NULL DEFAULT 'rial';
ALTER TABLE buildings ADD COLUMN bank_senders VARCHAR(300) NOT NULL DEFAULT '';
ALTER TABLE buildings ADD COLUMN bank_auto_approve TINYINT(1) NOT NULL DEFAULT 0;
