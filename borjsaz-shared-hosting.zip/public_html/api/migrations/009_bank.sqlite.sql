-- تطبیق خودکار واریزها با پیامک بانک (هم‌ارزِ نسخه‌ی MySQL)

CREATE TABLE bank_devices (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  building_id  INTEGER NOT NULL REFERENCES buildings(id) ON DELETE CASCADE,
  name         TEXT NOT NULL,
  token_hash   TEXT NOT NULL UNIQUE,
  last_seen_at TEXT NULL,
  revoked_at   TEXT NULL,
  created_by   INTEGER NOT NULL,
  created_at   TEXT NOT NULL
);

CREATE TABLE bank_events (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  building_id  INTEGER NOT NULL REFERENCES buildings(id) ON DELETE CASCADE,
  device_id    INTEGER NULL,
  source       TEXT NOT NULL,
  external_id  TEXT NOT NULL,
  sender       TEXT NOT NULL DEFAULT '',
  body         TEXT NOT NULL,
  received_at  TEXT NOT NULL,
  status       TEXT NOT NULL DEFAULT 'new',
  direction    TEXT NOT NULL DEFAULT '',
  amount_rial  INTEGER NULL,
  balance_rial INTEGER NULL,
  occurred_at  TEXT NULL,
  ref_no       TEXT NOT NULL DEFAULT '',
  continuity   TEXT NOT NULL DEFAULT 'unknown',
  error        TEXT NOT NULL DEFAULT '',
  created_at   TEXT NOT NULL,
  UNIQUE (building_id, source, external_id)
);
CREATE INDEX idx_bank_event_status ON bank_events (building_id, status);

CREATE TABLE bank_deposits (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  building_id  INTEGER NOT NULL REFERENCES buildings(id) ON DELETE CASCADE,
  event_id     INTEGER NULL UNIQUE REFERENCES bank_events(id) ON DELETE SET NULL,
  amount       INTEGER NOT NULL,
  occurred_at  TEXT NOT NULL,
  ref_no       TEXT NOT NULL DEFAULT '',
  status       TEXT NOT NULL DEFAULT 'unmatched',
  claim_id     INTEGER NULL REFERENCES payment_claims(id) ON DELETE SET NULL,
  unit_id      INTEGER NULL REFERENCES units(id) ON DELETE SET NULL,
  tx_id        INTEGER NULL,
  method       TEXT NOT NULL DEFAULT '',
  note         TEXT NOT NULL DEFAULT '',
  reviewed_by  INTEGER NULL,
  reviewed_at  TEXT NULL,
  created_at   TEXT NOT NULL
);
CREATE INDEX idx_bank_dep_status ON bank_deposits (building_id, status);
CREATE INDEX idx_bank_dep_claim ON bank_deposits (claim_id);
CREATE INDEX idx_bank_dep_tx ON bank_deposits (tx_id);

ALTER TABLE buildings ADD COLUMN bank_sms_unit TEXT NOT NULL DEFAULT 'rial';
ALTER TABLE buildings ADD COLUMN bank_senders TEXT NOT NULL DEFAULT '';
ALTER TABLE buildings ADD COLUMN bank_auto_approve INTEGER NOT NULL DEFAULT 0;
