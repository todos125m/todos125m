-- جزئیات پرداخت هزینه: به چه کسی (یا کدام نیرو/پیمانکار)، با چه روشی، شماره پیگیری و عکس فاکتور/رسید.

ALTER TABLE fund_entries ADD COLUMN payee VARCHAR(120) NOT NULL DEFAULT '';
ALTER TABLE fund_entries ADD COLUMN staff_id INT UNSIGNED NULL;
ALTER TABLE fund_entries ADD COLUMN method VARCHAR(10) NOT NULL DEFAULT '';
ALTER TABLE fund_entries ADD COLUMN ref_no VARCHAR(40) NOT NULL DEFAULT '';
ALTER TABLE fund_entries ADD COLUMN attachment VARCHAR(80) NOT NULL DEFAULT '';
