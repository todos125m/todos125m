-- جزئیات پرداخت هزینه (هم‌ارزِ نسخه‌ی MySQL)

ALTER TABLE fund_entries ADD COLUMN payee TEXT NOT NULL DEFAULT '';
ALTER TABLE fund_entries ADD COLUMN staff_id INTEGER NULL;
ALTER TABLE fund_entries ADD COLUMN method TEXT NOT NULL DEFAULT '';
ALTER TABLE fund_entries ADD COLUMN ref_no TEXT NOT NULL DEFAULT '';
ALTER TABLE fund_entries ADD COLUMN attachment TEXT NOT NULL DEFAULT '';
