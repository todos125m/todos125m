<?php
// ورود با کد یک‌بارمصرف پیامکی. کاربر در اولین تأیید ساخته می‌شود.

function otpHash(string $mobile, string $code): string {
    return hash_hmac('sha256', "$mobile:$code", OTP_SECRET);
}

function otpEnabled(): bool {
    return defined('OTP_ENABLED') && OTP_ENABLED;
}

// LOGIN_REQUIRED=false → ورودی در کار نیست؛ فرانت خودکار با کاربر پیش‌فرض (DEFAULT_USER_MOBILE یا اولین PLATFORM_ADMINS) وارد می‌شود.
function loginRequired(): bool {
    return defined('LOGIN_REQUIRED') && LOGIN_REQUIRED;
}

function auth_guest(): void {
    if (loginRequired()) fail('FORBIDDEN', 403);
    if (!rateLimit('guest:ip:' . clientIp(), 60, 600)) fail('TOO_MANY_REQUESTS', 429);
    // DEFAULT_USER_MOBILE خالی یا تعریف‌نشده → اولین شماره‌ی PLATFORM_ADMINS
    $mobile = (defined('DEFAULT_USER_MOBILE') && DEFAULT_USER_MOBILE !== '') ? DEFAULT_USER_MOBILE : (PLATFORM_ADMINS[0] ?? '');
    $mobile = normalizeMobile($mobile);
    if (!$mobile) fail('INVALID_MOBILE');
    $user = findOrCreateUser($mobile);
    respond(['token' => issueToken($user), 'user' => publicUser($user)]);
}

const PASSWORD_MIN = 6;

function validPassword($p): string {
    $p = is_string($p) ? $p : '';
    if (mb_strlen($p) < PASSWORD_MIN || mb_strlen($p) > 72) fail('WEAK_PASSWORD');
    return $p;
}

function loadUser(int $id): array {
    $stmt = db()->prepare('SELECT * FROM users WHERE id = ?');
    $stmt->execute([$id]);
    return $stmt->fetch() ?: fail('NOT_FOUND', 404);
}

/**
 * ورود با موبایل و رمز. کاربری که هنوز رمز ندارد (اولین ورود یا رمزش را پشتیبانی پاک کرده):
 * اگر پیامک فعال است باید با کد پیامکی وارد شود (NEEDS_OTP) وگرنه همین رمز برایش ثبت می‌شود.
 */
function auth_login(): void {
    $b = body();
    $mobile = normalizeMobile($b['mobile'] ?? '');
    if (!$mobile) fail('INVALID_MOBILE');
    if (!rateLimit('login:ip:' . clientIp(), 30, 600) || !rateLimit("login:m:$mobile", 10, 600)) fail('TOO_MANY_REQUESTS', 429);
    $password = is_string($b['password'] ?? null) ? $b['password'] : '';

    $stmt = db()->prepare('SELECT * FROM users WHERE mobile = ?');
    $stmt->execute([$mobile]);
    $user = $stmt->fetch();
    if ($user && $user['password_hash'] !== '') {
        if (!password_verify($password, $user['password_hash'])) fail('INVALID_PASSWORD');
        respond(['token' => issueToken($user), 'user' => publicUser($user)]);
    }
    if (otpEnabled()) fail('NEEDS_OTP');
    $hash = password_hash(validPassword($password), PASSWORD_DEFAULT);
    $user = findOrCreateUser($mobile);
    db()->prepare('UPDATE users SET password_hash = ?, must_change_password = 0 WHERE id = ?')->execute([$hash, $user['id']]);
    $user = loadUser((int) $user['id']);
    respond(['token' => issueToken($user), 'user' => publicUser($user), 'first_login' => true]);
}

/** تغییر رمز توسط خود کاربر. رمز فعلی لازم نیست اگر رمزی ندارد یا پشتیبانی رمز موقت داده. */
function auth_change_password(): void {
    $user = loadUser(authUserId());
    $b = body();
    $new = validPassword($b['password'] ?? '');
    if ($user['password_hash'] !== '' && !(int) $user['must_change_password']
        && !password_verify(is_string($b['current'] ?? null) ? $b['current'] : '', $user['password_hash'])) {
        fail('INVALID_PASSWORD');
    }
    db()->prepare('UPDATE users SET password_hash = ?, must_change_password = 0, token_version = token_version + 1 WHERE id = ?')
        ->execute([password_hash($new, PASSWORD_DEFAULT), $user['id']]);
    // نشست‌های دستگاه‌های دیگر باطل می‌شوند؛ همین دستگاه توکن تازه می‌گیرد.
    respond(['token' => issueToken(loadUser((int) $user['id']))]);
}

function auth_send_otp(): void {
    $mobile = normalizeMobile(body()['mobile'] ?? '');
    if (!$mobile) fail('INVALID_MOBILE');

    // OTP_ENABLED=false → کدی ارسال نمی‌شود و فرانت مستقیم verify را بدون کد صدا می‌زند.
    if (!otpEnabled()) respond(['ok' => true, 'otp' => false]);

    if (!rateLimit('otp:ip:' . clientIp(), 20, 600)) fail('TOO_MANY_REQUESTS', 429);
    if (!rateLimit("otp:m:$mobile", 1, 60) || !rateLimit("otp:mh:$mobile", 8, 3600)) {
        fail('TOO_MANY_REQUESTS', 429);
    }

    $code = (string) random_int(10000, 99999);
    $db   = db();
    $db->prepare('UPDATE otp_codes SET used = 1 WHERE mobile = ? AND used = 0')->execute([$mobile]);
    $db->prepare('INSERT INTO otp_codes (mobile, code_hash, expires_at, created_at) VALUES (?, ?, ?, ?)')
       ->execute([$mobile, otpHash($mobile, $code), date('Y-m-d H:i:s', time() + OTP_EXPIRY_SECONDS), now()]);

    if (!sendOtpSms($mobile, $code)) fail('SMS_FAILED', 502);

    $out = ['ok' => true, 'expires_in' => OTP_EXPIRY_SECONDS, 'resend_in' => 60];
    if (APP_ENV === 'dev') $out['dev_code'] = $code;
    respond($out);
}

function auth_verify_otp(): void {
    $body   = body();
    $mobile = normalizeMobile($body['mobile'] ?? '');
    if (!otpEnabled()) {
        if (!$mobile) fail('INVALID_MOBILE');
        if (!rateLimit('login:ip:' . clientIp(), 30, 600)) fail('TOO_MANY_REQUESTS', 429);
        $user = findOrCreateUser($mobile);
        respond(['token' => issueToken($user), 'user' => publicUser($user)]);
    }
    $code   = preg_replace('/\D/', '', toEnDigits($body['code'] ?? ''));
    if (!$mobile || strlen($code) !== 5) fail('INVALID_OTP');
    if (!rateLimit("verify:$mobile", 10, 600)) fail('TOO_MANY_REQUESTS', 429);

    $db   = db();
    $stmt = $db->prepare('SELECT * FROM otp_codes WHERE mobile = ? AND used = 0 AND expires_at > ? ORDER BY id DESC LIMIT 1');
    $stmt->execute([$mobile, now()]);
    $otp = $stmt->fetch();
    if (!$otp) fail('OTP_EXPIRED');
    if ((int) $otp['attempts'] >= 5) fail('TOO_MANY_ATTEMPTS', 429);

    if (!hash_equals($otp['code_hash'], otpHash($mobile, $code))) {
        $db->prepare('UPDATE otp_codes SET attempts = attempts + 1 WHERE id = ?')->execute([$otp['id']]);
        fail('INVALID_OTP');
    }
    $db->prepare('UPDATE otp_codes SET used = 1 WHERE id = ?')->execute([$otp['id']]);

    $user = findOrCreateUser($mobile);
    respond(['token' => issueToken($user), 'user' => publicUser($user)]);
}

function auth_me(): void {
    $uid = authUserId();
    $stmt = db()->prepare('SELECT * FROM users WHERE id = ?');
    $stmt->execute([$uid]);
    $user = $stmt->fetch();
    respond([
        'user' => publicUser($user) + [
            'is_platform' => isPlatformAdmin($user['mobile']),
            'has_password' => $user['password_hash'] !== '',
            'must_change_password' => (bool) (int) $user['must_change_password'],
            'login_required' => loginRequired(),
        ],
        'buildings' => userBuildings($uid),
        'residences' => userResidences($user['mobile']),
    ]);
}

function auth_update_me(): void {
    $uid  = authUserId();
    $name = cleanStr(body()['full_name'] ?? '', 120);
    if (mb_strlen($name) < 2) fail('INVALID_NAME');
    db()->prepare('UPDATE users SET full_name = ? WHERE id = ?')->execute([$name, $uid]);
    auth_me();
}

function findOrCreateUser(string $mobile, string $fullName = ''): array {
    $db   = db();
    $stmt = $db->prepare('SELECT * FROM users WHERE mobile = ?');
    $stmt->execute([$mobile]);
    if ($user = $stmt->fetch()) {
        if ($fullName !== '' && $user['full_name'] === '') {
            $db->prepare('UPDATE users SET full_name = ? WHERE id = ?')->execute([$fullName, $user['id']]);
            $user['full_name'] = $fullName;
        }
        return $user;
    }
    $db->prepare('INSERT INTO users (mobile, full_name, created_at) VALUES (?, ?, ?)')->execute([$mobile, $fullName, now()]);
    return ['id' => (int) $db->lastInsertId(), 'mobile' => $mobile, 'full_name' => $fullName];
}

function publicUser(array $u): array {
    return ['id' => (int) $u['id'], 'mobile' => $u['mobile'], 'full_name' => $u['full_name']];
}
