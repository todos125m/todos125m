<?php
// ورود با کد یک‌بارمصرف پیامکی. کاربر در اولین تأیید ساخته می‌شود.

function otpHash(string $mobile, string $code): string {
    return hash_hmac('sha256', "$mobile:$code", OTP_SECRET);
}

function otpEnabled(): bool {
    return defined('OTP_ENABLED') && OTP_ENABLED;
}

// LOGIN_REQUIRED=false → ورودی در کار نیست؛ فرانت خودکار با کاربر پیش‌فرض (DEFAULT_USER_MOBILE یا اولین PLATFORM_ADMINS) وارد می‌شود.
function loginRequired(): bool {
    return defined('LOGIN_REQUIRED') && LOGIN_REQUIRED;
}

function auth_guest(): void {
    if (loginRequired()) fail('FORBIDDEN', 403);
    if (!rateLimit('guest:ip:' . clientIp(), 60, 600)) fail('TOO_MANY_REQUESTS', 429);
    // DEFAULT_USER_MOBILE خالی یا تعریف‌نشده → اولین شماره‌ی PLATFORM_ADMINS
    $mobile = (defined('DEFAULT_USER_MOBILE') && DEFAULT_USER_MOBILE !== '') ? DEFAULT_USER_MOBILE : (PLATFORM_ADMINS[0] ?? '');
    $mobile = normalizeMobile($mobile);
    if (!$mobile) fail('INVALID_MOBILE');
    $user = findOrCreateUser($mobile);
    respond(['token' => issueToken($user), 'user' => publicUser($user)]);
}

function auth_send_otp(): void {
    $mobile = normalizeMobile(body()['mobile'] ?? '');
    if (!$mobile) fail('INVALID_MOBILE');

    // OTP_ENABLED=false → کدی ارسال نمی‌شود و فرانت مستقیم verify را بدون کد صدا می‌زند.
    if (!otpEnabled()) respond(['ok' => true, 'otp' => false]);

    if (!rateLimit('otp:ip:' . clientIp(), 20, 600)) fail('TOO_MANY_REQUESTS', 429);
    if (!rateLimit("otp:m:$mobile", 1, 60) || !rateLimit("otp:mh:$mobile", 8, 3600)) {
        fail('TOO_MANY_REQUESTS', 429);
    }

    $code = (string) random_int(10000, 99999);
    $db   = db();
    $db->prepare('UPDATE otp_codes SET used = 1 WHERE mobile = ? AND used = 0')->execute([$mobile]);
    $db->prepare('INSERT INTO otp_codes (mobile, code_hash, expires_at, created_at) VALUES (?, ?, ?, ?)')
       ->execute([$mobile, otpHash($mobile, $code), date('Y-m-d H:i:s', time() + OTP_EXPIRY_SECONDS), now()]);

    if (!sendOtpSms($mobile, $code)) fail('SMS_FAILED', 502);

    $out = ['ok' => true, 'expires_in' => OTP_EXPIRY_SECONDS, 'resend_in' => 60];
    if (APP_ENV === 'dev') $out['dev_code'] = $code;
    respond($out);
}

function auth_verify_otp(): void {
    $body   = body();
    $mobile = normalizeMobile($body['mobile'] ?? '');
    if (!otpEnabled()) {
        if (!$mobile) fail('INVALID_MOBILE');
        if (!rateLimit('login:ip:' . clientIp(), 30, 600)) fail('TOO_MANY_REQUESTS', 429);
        $user = findOrCreateUser($mobile);
        respond(['token' => issueToken($user), 'user' => publicUser($user)]);
    }
    $code   = preg_replace('/\D/', '', toEnDigits($body['code'] ?? ''));
    if (!$mobile || strlen($code) !== 5) fail('INVALID_OTP');
    if (!rateLimit("verify:$mobile", 10, 600)) fail('TOO_MANY_REQUESTS', 429);

    $db   = db();
    $stmt = $db->prepare('SELECT * FROM otp_codes WHERE mobile = ? AND used = 0 AND expires_at > ? ORDER BY id DESC LIMIT 1');
    $stmt->execute([$mobile, now()]);
    $otp = $stmt->fetch();
    if (!$otp) fail('OTP_EXPIRED');
    if ((int) $otp['attempts'] >= 5) fail('TOO_MANY_ATTEMPTS', 429);

    if (!hash_equals($otp['code_hash'], otpHash($mobile, $code))) {
        $db->prepare('UPDATE otp_codes SET attempts = attempts + 1 WHERE id = ?')->execute([$otp['id']]);
        fail('INVALID_OTP');
    }
    $db->prepare('UPDATE otp_codes SET used = 1 WHERE id = ?')->execute([$otp['id']]);

    $user = findOrCreateUser($mobile);
    respond(['token' => issueToken($user), 'user' => publicUser($user)]);
}

function auth_me(): void {
    $uid = authUserId();
    $stmt = db()->prepare('SELECT * FROM users WHERE id = ?');
    $stmt->execute([$uid]);
    $user = $stmt->fetch();
    respond([
        'user' => publicUser($user) + ['is_platform' => isPlatformAdmin($user['mobile'])],
        'buildings' => userBuildings($uid),
        'residences' => userResidences($user['mobile']),
    ]);
}

function auth_update_me(): void {
    $uid  = authUserId();
    $name = cleanStr(body()['full_name'] ?? '', 120);
    if (mb_strlen($name) < 2) fail('INVALID_NAME');
    db()->prepare('UPDATE users SET full_name = ? WHERE id = ?')->execute([$name, $uid]);
    auth_me();
}

function findOrCreateUser(string $mobile, string $fullName = ''): array {
    $db   = db();
    $stmt = $db->prepare('SELECT * FROM users WHERE mobile = ?');
    $stmt->execute([$mobile]);
    if ($user = $stmt->fetch()) {
        if ($fullName !== '' && $user['full_name'] === '') {
            $db->prepare('UPDATE users SET full_name = ? WHERE id = ?')->execute([$fullName, $user['id']]);
            $user['full_name'] = $fullName;
        }
        return $user;
    }
    $db->prepare('INSERT INTO users (mobile, full_name, created_at) VALUES (?, ?, ?)')->execute([$mobile, $fullName, now()]);
    return ['id' => (int) $db->lastInsertId(), 'mobile' => $mobile, 'full_name' => $fullName];
}

function publicUser(array $u): array {
    return ['id' => (int) $u['id'], 'mobile' => $u['mobile'], 'full_name' => $u['full_name']];
}
