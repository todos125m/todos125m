<?php
// تطبیق واریزها با اطلاعات بانک: پیامک بانک (گوشی + Tasker → وب‌هوک)، فایل گردش حساب یا ثبت دستی.
//
// سه مرحله‌ی جدا تا پیامک تکراری یا مبهم پرداخت اشتباه نسازد:
//   ۱. دریافت: هر پیامک/ردیف خام با شناسه‌ی یکتا در bank_events (ارسال دوباره = همان ردیف).
//   ۲. خواندن: مبلغ، مانده، زمان و پیگیری استخراج می‌شود؛ فقط واریزها به bank_deposits می‌روند.
//   ۳. تطبیق: واریز با «اعلام واریز» ساکن جفت می‌شود. فقط تطبیقِ یکتا (یک اعلام ↔ یک واریز) پیشنهاد یا
//      در صورت فعال بودن، خودکار تأیید می‌شود؛ بقیه برای مدیر می‌ماند. هم‌مبلغ بودن به‌تنهایی کافی نیست.
//
// مبالغ سیستم به تومان است؛ پیامک بانک معمولاً ریال است (تنظیم bank_sms_unit).

const DEPOSIT_STATUSES = ['unmatched', 'suggested', 'ambiguous', 'matched', 'ignored'];
const MATCH_WINDOW_DAYS = 1;

// ================= خواندن پیامک =================

/** ارقام فارسی/عربی → لاتین و حذف جداکننده‌ی هزارگان («۱٬۵۰۰٬۰۰۰» → 1500000). */
function bankNormalize(string $text): string {
    $t = toEnDigits($text);
    $t = preg_replace('/(?<=\d)[,٬،.](?=\d{3}(?!\d))/u', '', $t);
    $t = preg_replace('/(?<=\d)[,٬،.](?=\d{3}(?!\d))/u', '', $t); // سه‌رقمی‌های پشت‌سرهم
    return str_replace(["\u{200c}", "\u{200f}", "\u{200e}", 'ي', 'ك'], [' ', '', '', 'ی', 'ک'], $t);
}

/**
 * پیامک بانک → ['direction' => 'credit'|'debit', 'amount' => ریال, 'balance' => ?ریال, 'occurred_at' => ?, 'ref_no' => '']
 * یا null اگر مبلغ/جهت پیدا نشود (برای بررسی دستی می‌ماند). قالب‌های رایج بانک‌های ایرانی را می‌خواند:
 *   «واریز: 1,500,000» «انتقال به حساب ... مبلغ 1500000» «+1,500,000» «1,500,000+» «بستانکار»
 *   «برداشت/خرید/انتقال از: ...» «-1,500,000»؛ مانده/موجودی؛ تاریخ 1405/07/16 یا 05/07/16 یا 0716-1230.
 */
function parseBankSms(string $body, string $receivedAt): ?array {
    $t = bankNormalize($body);
    // پیامک رمز یکبارمصرف/پویا تراکنش نیست.
    if (preg_match('/رمز\s*(?:پویا|یک\s*بار|دوم)|کد\s*(?:تایید|تأیید|فعال)/u', $t)) return null;
    $creditKw = 'واریز|انتقال\s*به|بستانکار|افزایش|دریافت';
    $debitKw  = 'برداشت|خرید|انتقال\s*از|بدهکار|کسر|پرداخت';

    // جهت: اولین نشانه در متن (کلمه یا علامت + / - کنار مبلغ)
    $marks = [];
    if (preg_match("/($creditKw)/u", $t, $m, PREG_OFFSET_CAPTURE)) $marks[$m[0][1]] = 'credit';
    if (preg_match("/($debitKw)/u", $t, $m, PREG_OFFSET_CAPTURE)) $marks[$m[0][1]] = 'debit';
    if (preg_match('/(?<![\d\/:+-])\+\s*\d{3,15}|\d{3,15}\s*\+(?!\d)/u', $t, $m, PREG_OFFSET_CAPTURE)) $marks[$m[0][1]] ??= 'credit';
    if (preg_match('/(?<![\d\/:+-])-\s*\d{4,15}(?![\d\/:])|(?<![\d\/:-])\d{4,15}\s*-(?![\d\/:])/u', $t, $m, PREG_OFFSET_CAPTURE)) $marks[$m[0][1]] ??= 'debit';
    if (!$marks) return null;
    ksort($marks);
    $direction = reset($marks);

    // مبلغ: «مبلغ: ...» مقدم است (کنار «واریز به حساب 123***» شماره‌ی حساب هم هست)؛ بعد عدد چسبیده به کلمه یا علامت.
    $amount = null;
    if (preg_match('/مبلغ\D{0,12}?(\d{3,15})/u', $t, $m)) $amount = $m[1];
    elseif (preg_match("/(?:$creditKw|$debitKw)\s*[:：]?\s*(\d{3,15})/u", $t, $m)) $amount = $m[1];
    elseif (preg_match('/(?<![\d\/:+-])[+-]\s*(\d{3,15})|(\d{3,15})\s*[+-](?![\d\/:])/u', $t, $m)) $amount = $m[1] !== '' ? $m[1] : $m[2];
    if (!$amount || (int) $amount <= 0) return null;

    $balance = null;
    if (preg_match('/(?:مانده|موجودی)\D{0,15}?(-?)\s*(\d{1,15})/u', $t, $m)) $balance = (int) ($m[1] . $m[2]);

    $ref = '';
    if (preg_match('/(?:پیگیری|ارجاع|مرجع|سند|شناسه)\D{0,15}?(\d{4,30})/u', $t, $m)) $ref = $m[1];

    return ['direction' => $direction, 'amount' => (int) $amount, 'balance' => $balance, 'ref_no' => $ref,
            'occurred_at' => bankSmsTime($t, $receivedAt)];
}

/** زمان تراکنش از متن پیامک (شمسی)؛ اگر نبود یا نامعقول بود، زمان دریافت پیامک. */
function bankSmsTime(string $t, string $receivedAt): string {
    $rec = strtotime($receivedAt) ?: time();
    [$ry] = gregorianToJalali((int) date('Y', $rec), (int) date('n', $rec), (int) date('j', $rec));
    $jy = $jm = $jd = null;
    if (preg_match('/(1[34]\d{2})\/(\d{1,2})\/(\d{1,2})/', $t, $m)) [$jy, $jm, $jd] = [(int) $m[1], (int) $m[2], (int) $m[3]];
    elseif (preg_match('/(?<!\d)(\d{2})\/(\d{1,2})\/(\d{1,2})(?!\d)/', $t, $m)) [$jy, $jm, $jd] = [1400 + (int) $m[1], (int) $m[2], (int) $m[3]];
    elseif (preg_match('/(?<!\d)(\d{2})(\d{2})-(\d{2})(\d{2})(?!\d)/', $t, $m)) [$jy, $jm, $jd] = [$ry, (int) $m[1], (int) $m[2]];
    $time = '00:00';
    if (preg_match('/(?<!\d)([01]?\d|2[0-3]):([0-5]\d)(?!\d)/', $t, $m)) $time = sprintf('%02d:%02d', $m[1], $m[2]);
    elseif (preg_match('/(?<!\d)\d{4}-([01]\d|2[0-3])([0-5]\d)(?!\d)/', $t, $m)) $time = "$m[1]:$m[2]";
    if ($jy && $jm >= 1 && $jm <= 12 && $jd >= 1 && $jd <= 31) {
        [$gy, $gm, $gd] = jalaliToGregorian($jy, $jm, $jd);
        $ts = strtotime(sprintf('%04d-%02d-%02d %s:00', $gy, $gm, $gd, $time));
        // تاریخ پیامک نباید آینده یا خیلی قدیمی‌تر از زمان دریافت باشد (خواندن اشتباه)
        if ($ts && $ts <= $rec + 3600 && $ts >= $rec - 40 * 86400) return date('Y-m-d H:i:s', $ts);
    }
    return date('Y-m-d H:i:s', $rec);
}

// ================= دریافت =================

/**
 * یک رویداد خام را یک‌بار ذخیره و پردازش می‌کند. ارسال دوباره‌ی همان رویداد (همان شناسه) کاری نمی‌کند.
 * $row: source, external_id, sender, body, received_at, device_id و برای فایل/دستی: parsed (نتیجه‌ی آماده).
 */
function bankIngest(int $bid, array $row): array {
    $db = db();
    $ins = $db->prepare('INSERT INTO bank_events (building_id, device_id, source, external_id, sender, body, received_at, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    try {
        $ins->execute([$bid, $row['device_id'] ?? null, $row['source'], mb_substr($row['external_id'], 0, 100), mb_substr($row['sender'] ?? '', 0, 40),
                       mb_substr($row['body'] ?? '', 0, 2000), $row['received_at'], now()]);
    } catch (PDOException $e) {
        if (isUniqueViolation($e)) return ['duplicate' => true];
        throw $e;
    }
    $eventId = (int) $db->lastInsertId();
    return bankProcessEvent($eventId, $row['parsed'] ?? null) + ['event_id' => $eventId];
}

/** مرحله‌ی ۲ و ۳: خواندن رویداد، ساخت واریز و تلاش برای تطبیق. cron رویدادهای جامانده (new) را دوباره می‌دهد. */
function bankProcessEvent(int $eventId, ?array $parsed = null): array {
    $db = db();
    $s = $db->prepare('SELECT e.*, b.bank_sms_unit, b.bank_senders FROM bank_events e JOIN buildings b ON b.id = e.building_id WHERE e.id = ?');
    $s->execute([$eventId]);
    $e = $s->fetch();
    if (!$e || $e['status'] !== 'new') return ['status' => $e['status'] ?? 'missing'];
    $bid = (int) $e['building_id'];

    if ($e['source'] === 'sms' && trim($e['bank_senders']) !== '') {
        $allowed = array_filter(array_map(fn($x) => preg_replace('/\D/', '', toEnDigits($x)) ?: trim($x), explode(',', $e['bank_senders'])));
        $sender = preg_replace('/\D/', '', toEnDigits($e['sender'])) ?: trim($e['sender']);
        if (!in_array($sender, $allowed, true)) {
            $db->prepare("UPDATE bank_events SET status = 'ignored', error = ? WHERE id = ?")->execute(['فرستنده جزو شماره‌های بانک نیست', $eventId]);
            return ['status' => 'ignored'];
        }
    }
    $p = $parsed ?? parseBankSms($e['body'], $e['received_at']);
    if (!$p) {
        $db->prepare("UPDATE bank_events SET status = 'error', error = ? WHERE id = ?")->execute(['مبلغ یا نوع تراکنش خوانده نشد', $eventId]);
        return ['status' => 'error'];
    }
    // ریال → تومان (اگر پیامک ریالی است)؛ مبلغ اعشاری تومان نداریم.
    $toToman = fn($v) => $v === null ? null : ($e['bank_sms_unit'] === 'toman' || $e['source'] !== 'sms' ? (int) $v : intdiv((int) $v, 10));
    $signed = $p['direction'] === 'credit' ? $p['amount'] : -$p['amount'];

    // پیوستگی مانده: مانده‌ی قبلی + این تراکنش = مانده‌ی این پیامک؟ اگر نه، پیامکی جاافتاده یا جعلی است.
    $continuity = 'unknown';
    if ($p['balance'] !== null && $e['source'] === 'sms') {
        // device_id = ? (نه COALESCE): در SQLite پارامترها متنی bind می‌شوند و فقط مقایسه با ستون، نوع را تبدیل می‌کند.
        $sameDevice = $e['device_id'] === null ? 'device_id IS NULL' : 'device_id = ' . (int) $e['device_id'];
        $q = $db->prepare("SELECT balance_rial FROM bank_events WHERE building_id = ? AND source = 'sms' AND balance_rial IS NOT NULL AND id <> ?
                             AND $sameDevice AND occurred_at <= ? ORDER BY occurred_at DESC, id DESC LIMIT 1");
        $q->execute([$bid, $eventId, $p['occurred_at']]);
        $prev = $q->fetchColumn();
        if ($prev !== false) $continuity = ((int) $prev + $signed === (int) $p['balance']) ? 'ok' : 'gap';
    }

    $db->beginTransaction();
    $db->prepare('UPDATE bank_events SET status = ?, direction = ?, amount_rial = ?, balance_rial = ?, occurred_at = ?, ref_no = ?, continuity = ? WHERE id = ?')
       ->execute([$p['direction'] === 'credit' ? 'deposit' : 'debit', $p['direction'], $signed, $p['balance'], $p['occurred_at'], mb_substr($p['ref_no'], 0, 40), $continuity, $eventId]);
    $depositId = null;
    if ($p['direction'] === 'credit') {
        $amount = $toToman($p['amount']);
        if ($amount > 0) {
            $db->prepare('INSERT INTO bank_deposits (building_id, event_id, amount, occurred_at, ref_no, created_at) VALUES (?, ?, ?, ?, ?, ?)')
               ->execute([$bid, $eventId, $amount, $p['occurred_at'], mb_substr($p['ref_no'], 0, 40), now()]);
            $depositId = (int) $db->lastInsertId();
        }
    }
    $db->commit();
    if (!$depositId) return ['status' => $p['direction'] === 'credit' ? 'deposit' : 'debit'];
    return ['status' => 'deposit', 'deposit_id' => $depositId, 'match' => bankMatchDeposit($depositId)];
}

// ================= تطبیق =================

/** اعلام‌های «در انتظار» که می‌توانند مال این واریز باشند: هم‌مبلغ، تاریخ ±۱ روز، هنوز به واریز دیگری وصل نشده. */
function bankClaimCandidates(array $d): array {
    $day = substr($d['occurred_at'], 0, 10);
    $s = db()->prepare("SELECT c.* FROM payment_claims c
                         WHERE c.building_id = ? AND c.status = 'pending' AND c.amount = ? AND c.date >= ? AND c.date <= ?
                           AND NOT EXISTS (SELECT 1 FROM bank_deposits x WHERE x.claim_id = c.id AND x.id <> ? AND x.status IN ('suggested', 'matched'))
                         ORDER BY c.id");
    $s->execute([$d['building_id'], $d['amount'], date('Y-m-d', strtotime("$day -" . MATCH_WINDOW_DAYS . ' day')), date('Y-m-d', strtotime("$day +" . MATCH_WINDOW_DAYS . ' day')), $d['id']]);
    $c = $s->fetchAll();
    // شماره پیگیری یکسان (اگر بانک داده) قوی‌ترین نشانه است.
    if ($d['ref_no'] !== '') {
        $same = array_values(array_filter($c, fn($x) => $x['ref_no'] !== '' && (str_ends_with($x['ref_no'], $d['ref_no']) || str_ends_with($d['ref_no'], $x['ref_no']))));
        if ($same) return $same;
    }
    return $c;
}

/** واریزهای بی‌صاحبی که می‌توانند مال این اعلام باشند (برای بررسی دوطرفه‌ی یکتایی). */
function bankDepositCandidates(array $c): array {
    $s = db()->prepare("SELECT * FROM bank_deposits WHERE building_id = ? AND status IN ('unmatched', 'ambiguous', 'suggested') AND amount = ?
                          AND occurred_at >= ? AND occurred_at < ? ORDER BY id");
    $s->execute([$c['building_id'], $c['amount'], date('Y-m-d', strtotime("{$c['date']} -" . MATCH_WINDOW_DAYS . ' day')),
                 date('Y-m-d', strtotime("{$c['date']} +" . (MATCH_WINDOW_DAYS + 1) . ' day'))]);
    return array_values(array_filter($s->fetchAll(), fn($d) => $d['status'] !== 'suggested' || (int) $d['claim_id'] === (int) $c['id']));
}

/**
 * یک واریز را دوباره ارزیابی می‌کند: unmatched (اعلامی نیست)، ambiguous (چند احتمال)، suggested (یک‌به‌یک؛
 * منتظر تأیید مدیر) یا matched (یک‌به‌یک و تأیید خودکار روشن و پیوستگی مانده خراب نیست).
 */
function bankMatchDeposit(int $depositId): string {
    $db = db();
    $s = $db->prepare("SELECT d.*, e.continuity, b.bank_auto_approve FROM bank_deposits d JOIN buildings b ON b.id = d.building_id
                         LEFT JOIN bank_events e ON e.id = d.event_id WHERE d.id = ?");
    $s->execute([$depositId]);
    $d = $s->fetch();
    if (!$d || !in_array($d['status'], ['unmatched', 'ambiguous', 'suggested'], true)) return $d['status'] ?? 'missing';

    $claims = bankClaimCandidates($d);
    $status = 'unmatched';
    $claimId = null;
    if (count($claims) > 1) {
        $status = 'ambiguous';
    } elseif (count($claims) === 1) {
        $deps = bankDepositCandidates($claims[0]);
        if (count($deps) === 1 && (int) $deps[0]['id'] === (int) $d['id']) {
            $status = 'suggested';
            $claimId = (int) $claims[0]['id'];
        } else {
            $status = 'ambiguous';
        }
    }
    $db->prepare('UPDATE bank_deposits SET status = ?, claim_id = ? WHERE id = ? AND status IN (\'unmatched\', \'ambiguous\', \'suggested\')')
       ->execute([$status, $claimId, $depositId]);

    if ($status === 'suggested' && (int) $d['bank_auto_approve'] && $d['continuity'] !== 'gap') {
        return bankAutoApprove($d, $claims[0]) ? 'matched' : 'suggested';
    }
    return $status;
}

/** تأیید خودکار: پرداخت فقط یک‌بار (approveClaimInTx) و به نام سیستم در ردپا. */
function bankAutoApprove(array $d, array $c): bool {
    $db = db();
    $s = $db->prepare("SELECT user_id FROM building_members WHERE building_id = ? AND role = 'manager' ORDER BY id LIMIT 1");
    $s->execute([$d['building_id']]);
    $manager = (int) $s->fetchColumn();
    if (!$manager) return false;
    $prev = $GLOBALS['borjsaz_system_actor'] ?? null;
    systemActor($manager);
    try {
        $db->beginTransaction();
        $txId = approveClaimInTx($c, (int) $d['amount'], 'unit', 'تأیید خودکار با واریز بانکی', 'bank');
        if ($txId === null) return false; // هم‌زمان مدیر بررسی‌اش کرد
        $db->prepare("UPDATE bank_deposits SET status = 'matched', method = 'auto', tx_id = ?, unit_id = ?, reviewed_at = ? WHERE id = ? AND status = 'suggested'")
           ->execute([$txId, (int) $c['unit_id'], now(), $d['id']]);
        $db->commit();
        return true;
    } finally {
        systemActor($prev);
    }
}

/** بعد از ثبت اعلام جدید: واریزهای هم‌مبلغِ نزدیک دوباره ارزیابی می‌شوند. */
function bankMatchForClaim(int $claimId): void {
    $s = db()->prepare('SELECT * FROM payment_claims WHERE id = ?');
    $s->execute([$claimId]);
    $c = $s->fetch();
    if (!$c) return;
    foreach (bankDepositCandidates($c) as $d) bankMatchDeposit((int) $d['id']);
}

// ================= وب‌هوک گوشی =================

/**
 * POST /bank/webhook — از Tasker یا برنامه‌ی ارسال پیامک. هدر X-Device-Token (یا فیلد token).
 * دو شکل بدنه:
 *   JSON: {"id": "شناسه‌ی پیامک", "from": "فرستنده", "body": "متن", "received_at": "اختیاری"}
 *   متن خام (Content-Type: text/plain) = متن پیامک، و id/from/received_at در آدرس (?id=..&from=..) —
 *   برای Tasker ساده‌تر است چون متن پیامک خط جدید و " دارد و JSON دستی را خراب می‌کند.
 * شناسه‌ی رویداد = id + هش متن: ارسال دوباره‌ی همان پیامک تکراری است، ولی دو واریزِ هم‌دقیقه از یک
 * فرستنده (متن/مانده‌ی متفاوت) دو رویداد جدا می‌مانند.
 */
function bank_webhook(): void {
    if (!rateLimit('bankhook:' . clientIp(), 120, 60)) fail('TOO_MANY_REQUESTS', 429);
    if (stripos($_SERVER['CONTENT_TYPE'] ?? '', 'json') === false) {
        $raw = file_get_contents('php://input', false, null, 0, 8001);
        $b = ['body' => $raw === false ? '' : $raw] + array_map(fn($v) => is_string($v) ? $v : '', array_intersect_key($_GET, array_flip(['id', 'from', 'received_at', 'token'])));
    } else {
        $b = body();
    }
    $token = $_SERVER['HTTP_X_DEVICE_TOKEN'] ?? ($b['token'] ?? '');
    if (!is_string($token) || strlen($token) < 20) fail('UNAUTHORIZED', 401);
    $s = db()->prepare('SELECT * FROM bank_devices WHERE token_hash = ? AND revoked_at IS NULL');
    $s->execute([hash('sha256', $token)]);
    $dev = $s->fetch() ?: fail('UNAUTHORIZED', 401);
    db()->prepare('UPDATE bank_devices SET last_seen_at = ? WHERE id = ?')->execute([now(), $dev['id']]);

    $text = is_string($b['body'] ?? null) ? trim($b['body']) : '';
    if ($text === '' || mb_strlen($text) > 2000) fail('INVALID_TEXT');
    $from = is_string($b['from'] ?? null) ? trim($b['from']) : '';
    $received = bankReceivedAt($b['received_at'] ?? null);
    $ext = (is_string($b['id'] ?? null) && trim($b['id']) !== '' ? mb_substr(trim($b['id']), 0, 50) : substr($received, 0, 16)) . ':' . substr(hash('sha256', "$from|$text"), 0, 24);
    $r = bankIngest((int) $dev['building_id'], ['source' => 'sms', 'device_id' => (int) $dev['id'], 'external_id' => "d{$dev['id']}:$ext",
                                                 'sender' => $from, 'body' => $text, 'received_at' => $received]);
    respond(['ok' => true] + $r);
}

/** زمان دریافت: epoch ثانیه/میلی‌ثانیه یا «Y-m-d H:i»؛ نامعتبر یا آینده → اکنون. */
function bankReceivedAt($v): string {
    if (is_numeric($v)) {
        $n = (int) $v;
        if ($n > 1e12) $n = intdiv($n, 1000);
    } else {
        $n = is_string($v) ? strtotime(toEnDigits($v)) : false;
    }
    return ($n && $n <= time() + 300 && $n > time() - 60 * 86400) ? date('Y-m-d H:i:s', $n) : now();
}

// ================= پنل مدیر =================

function bankDepositRow(array $d): array {
    foreach (['id', 'amount', 'claim_id', 'unit_id', 'tx_id', 'event_id'] as $k) $d[$k] = $d[$k] === null ? null : (int) $d[$k];
    return $d;
}

function bank_deposits(int $bid): void {
    requireBuilding($bid);
    $where = ['d.building_id = ?'];
    $args = [$bid];
    $st = $_GET['status'] ?? '';
    if ($st === 'review') $where[] = "d.status IN ('unmatched', 'ambiguous', 'suggested')";
    elseif (in_array($st, DEPOSIT_STATUSES, true)) { $where[] = 'd.status = ?'; $args[] = $st; }
    if ($from = isoDate($_GET['from'] ?? '')) { $where[] = 'd.occurred_at >= ?'; $args[] = $from; }
    if ($to = isoDate($_GET['to'] ?? '')) { $where[] = 'd.occurred_at < ?'; $args[] = date('Y-m-d', strtotime("$to +1 day")); }
    $s = db()->prepare('SELECT d.*, e.body, e.sender, e.source, e.continuity, e.balance_rial,
                               u.title AS unit_title, u.block AS unit_block, cu.title AS claim_unit_title, cu.block AS claim_unit_block,
                               c.unit_id AS claim_unit_id, c.ref_no AS claim_ref_no, c.date AS claim_date, c.receipt AS claim_receipt,
                               us.full_name AS claim_user_name, us.mobile AS claim_user_mobile, r.full_name AS reviewer_name
                          FROM bank_deposits d LEFT JOIN bank_events e ON e.id = d.event_id LEFT JOIN units u ON u.id = d.unit_id
                          LEFT JOIN payment_claims c ON c.id = d.claim_id LEFT JOIN units cu ON cu.id = c.unit_id
                          LEFT JOIN users us ON us.id = c.user_id LEFT JOIN users r ON r.id = d.reviewed_by
                         WHERE ' . implode(' AND ', $where) . ' ORDER BY d.occurred_at DESC, d.id DESC LIMIT 300');
    $s->execute($args);
    $rows = array_map(function ($d) {
        $d = bankDepositRow($d);
        $d['claim_unit_id'] = $d['claim_unit_id'] === null ? null : (int) $d['claim_unit_id'];
        $d['claim_receipt'] = ($d['claim_receipt'] ?? '') !== '';
        return $d;
    }, $s->fetchAll());
    // برای واریز مبهم: اعلام‌های محتمل تا مدیر یکی را انتخاب کند.
    foreach ($rows as &$d) {
        $d['candidates'] = [];
        if ($d['status'] === 'ambiguous') {
            foreach (bankClaimCandidates($d) as $c) {
                $d['candidates'][] = ['id' => (int) $c['id'], 'unit_id' => (int) $c['unit_id'], 'unit' => unitNameById((int) $c['unit_id']),
                                      'date' => $c['date'], 'ref_no' => $c['ref_no'], 'receipt' => $c['receipt'] !== ''];
            }
        }
    }
    respond(['deposits' => $rows]);
}

/** پیامک‌هایی که خوانده نشدند (یا فرستنده‌ی ناشناس): برای ثبت دستی و بهتر کردن الگوی بانک. */
function bank_events(int $bid): void {
    requireBuilding($bid, 'write');
    $st = in_array($_GET['status'] ?? '', ['error', 'ignored', 'debit', 'deposit'], true) ? $_GET['status'] : 'error';
    $s = db()->prepare('SELECT id, source, sender, body, received_at, status, error, continuity FROM bank_events WHERE building_id = ? AND status = ? ORDER BY id DESC LIMIT 100');
    $s->execute([$bid, $st]);
    respond(['events' => array_map(fn($e) => ['id' => (int) $e['id']] + $e, $s->fetchAll())]);
}

function loadDeposit(int $id, string $need = 'write'): array {
    $s = db()->prepare('SELECT * FROM bank_deposits WHERE id = ?');
    $s->execute([$id]);
    $d = $s->fetch() ?: fail('NOT_FOUND', 404);
    requireBuilding((int) $d['building_id'], $need);
    return $d;
}

/** تأیید پیشنهاد یا انتخاب یکی از اعلام‌های محتمل: اعلام با مبلغ واقعیِ بانک تأیید می‌شود. */
function bank_deposit_confirm(int $id): void {
    $d = loadDeposit($id);
    if (!in_array($d['status'], ['suggested', 'ambiguous'], true)) fail('ALREADY_REVIEWED', 409);
    $b = body();
    $claimId = optInt($b['claim_id'] ?? $d['claim_id'], 1, PHP_INT_MAX) ?? fail('NOT_FOUND', 404);
    $s = db()->prepare("SELECT * FROM payment_claims WHERE id = ? AND building_id = ?");
    $s->execute([$claimId, $d['building_id']]);
    $c = $s->fetch() ?: fail('NOT_FOUND', 404);
    $db = db();
    $db->beginTransaction();
    $lock = $db->prepare("UPDATE bank_deposits SET status = 'matched', method = 'manual', claim_id = ?, unit_id = ?, reviewed_by = ?, reviewed_at = ? WHERE id = ? AND status IN ('suggested', 'ambiguous')");
    $lock->execute([$claimId, (int) $c['unit_id'], authUserId(), now(), $id]);
    if ($lock->rowCount() !== 1) { $db->rollBack(); fail('ALREADY_REVIEWED', 409); }
    $txId = approveClaimInTx($c, (int) $d['amount'], $b['payer'] ?? 'unit', 'تأیید با واریز بانکی', 'bank') ?? fail('ALREADY_REVIEWED', 409);
    $db->prepare('UPDATE bank_deposits SET tx_id = ? WHERE id = ?')->execute([$txId, $id]);
    $db->commit();
    respond(['ok' => true, 'tx_id' => $txId]);
}

/** واریز بی‌صاحب → پرداخت مستقیم در حساب یک واحد (بدون اعلام ساکن). */
function bank_deposit_assign(int $id): void {
    $d = loadDeposit($id);
    $b = body();
    $unitId = optInt($b['unit_id'] ?? null, 1, PHP_INT_MAX) ?? fail('INVALID_UNIT');
    $s = db()->prepare('SELECT * FROM units WHERE id = ? AND building_id = ?');
    $s->execute([$unitId, $d['building_id']]);
    $unit = $s->fetch() ?: fail('INVALID_UNIT');
    $note = cleanStr($b['note'] ?? '', 300);
    $db = db();
    $db->beginTransaction();
    $lock = $db->prepare("UPDATE bank_deposits SET status = 'matched', method = 'manual', unit_id = ?, claim_id = NULL, note = ?, reviewed_by = ?, reviewed_at = ? WHERE id = ? AND status IN ('unmatched', 'ambiguous', 'suggested')");
    $lock->execute([$unitId, $note, authUserId(), now(), $id]);
    if ($lock->rowCount() !== 1) { $db->rollBack(); fail('ALREADY_REVIEWED', 409); }
    insertTx(['building_id' => (int) $d['building_id'], 'unit_id' => $unitId, 'kind' => 'payment', 'amount' => (int) $d['amount'],
              'title' => 'واریز بانکی', 'date' => substr($d['occurred_at'], 0, 10), 'method' => 'transfer', 'ref_no' => $d['ref_no'],
              'notes' => $note, 'payer' => payerInput($b['payer'] ?? '')]);
    $txId = (int) $db->lastInsertId();
    $db->prepare('UPDATE bank_deposits SET tx_id = ? WHERE id = ?')->execute([$txId, $id]);
    audit((int) $d['building_id'], 'bank.assign', 'اختصاص واریز بانکی ' . faMoney((int) $d['amount']) . ' به ' . unitName($unit) . ($note ? ": $note" : ''), 'unit', $unitId);
    $db->commit();
    respond(['ok' => true, 'tx_id' => $txId]);
}

/** واریزی که شارژ نیست (مثلاً اجاره‌ی مشاعات یا انتقال داخلی): با دلیل کنار گذاشته می‌شود؛ قابل برگشت. */
function bank_deposit_ignore(int $id): void {
    $d = loadDeposit($id);
    $note = cleanStr(body()['note'] ?? '', 300);
    if (mb_strlen($note) < 2) fail('REASON_REQUIRED');
    $u = db()->prepare("UPDATE bank_deposits SET status = 'ignored', claim_id = NULL, note = ?, reviewed_by = ?, reviewed_at = ? WHERE id = ? AND status IN ('unmatched', 'ambiguous', 'suggested')");
    $u->execute([$note, authUserId(), now(), $id]);
    if ($u->rowCount() !== 1) fail('ALREADY_REVIEWED', 409);
    audit((int) $d['building_id'], 'bank.ignore', 'کنار گذاشتن واریز بانکی ' . faMoney((int) $d['amount']) . ": $note");
    respond(['ok' => true]);
}

function bank_deposit_reopen(int $id): void {
    $d = loadDeposit($id);
    if ($d['status'] !== 'ignored') fail('INVALID_TRANSITION', 409);
    db()->prepare("UPDATE bank_deposits SET status = 'unmatched', note = '', reviewed_by = NULL, reviewed_at = NULL WHERE id = ?")->execute([$id]);
    audit((int) $d['building_id'], 'bank.reopen', 'بازگرداندن واریز بانکی ' . faMoney((int) $d['amount']) . ' به صف بررسی');
    bankMatchDeposit($id);
    respond(['ok' => true]);
}

/** ثبت دستی واریز (مثلاً از روی صورت‌حساب کاغذی) — همان مسیر تطبیق. */
function bank_deposit_create(int $bid): void {
    requireBuilding($bid, 'write');
    $b = body();
    $amount = money($b['amount'] ?? '') ?? fail('INVALID_AMOUNT');
    if ($amount <= 0) fail('INVALID_AMOUNT');
    $date = isoDate($b['date'] ?? '') ?? fail('INVALID_DATE');
    if ($date > today()) fail('INVALID_DATE');
    $time = preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', toEnDigits($b['time'] ?? '')) ? toEnDigits($b['time']) : '12:00';
    $ref = toEnDigits(cleanStr($b['ref_no'] ?? '', 40));
    $r = bankIngest($bid, ['source' => 'manual', 'external_id' => 'm' . bin2hex(random_bytes(8)), 'body' => cleanStr($b['note'] ?? '', 500),
                           'received_at' => now(), 'parsed' => ['direction' => 'credit', 'amount' => $amount, 'balance' => null, 'ref_no' => $ref, 'occurred_at' => "$date $time:00"]]);
    audit($bid, 'bank.manual', 'ثبت دستی واریز بانکی ' . faMoney($amount) . ' (' . faDate($date) . ')');
    respond($r, 201);
}

/**
 * ورود گردش حساب (اکسل یا CSV در مرورگر خوانده و ستون‌ها انتخاب می‌شود): فقط ردیف‌های واریز.
 * rows: [{date, time?, amount, ref_no?, description?, balance?}] ، unit: rial|toman. ردیف تکراری دوباره ثبت نمی‌شود.
 */
function bank_import(int $bid): void {
    requireBuilding($bid, 'write');
    $b = body();
    $rows = is_array($b['rows'] ?? null) ? $b['rows'] : fail('NO_ROWS');
    if (count($rows) > 3000) fail('TOO_MANY_ROWS');
    $rial = ($b['unit'] ?? 'rial') !== 'toman';
    $stats = ['created' => 0, 'duplicate' => 0, 'invalid' => 0, 'matched' => 0, 'suggested' => 0];
    foreach ($rows as $row) {
        if (!is_array($row)) { $stats['invalid']++; continue; }
        $amount = bankAmount($row['amount'] ?? '');
        $date = isoDate(toEnDigits((string) ($row['date'] ?? ''))) ?? jalaliInputToIso((string) ($row['date'] ?? ''));
        if (!$amount || $amount <= 0 || !$date) { $stats['invalid']++; continue; }
        $amountT = $rial ? intdiv($amount, 10) : $amount;
        $time = preg_match('/([01]?\d|2[0-3]):([0-5]\d)/', toEnDigits((string) ($row['time'] ?? '')), $m) ? sprintf('%02d:%02d', $m[1], $m[2]) : '12:00';
        $ref = preg_replace('/\D/', '', toEnDigits((string) ($row['ref_no'] ?? '')));
        $balance = trim((string) ($row['balance'] ?? '')) === '' ? '' : (string) bankAmount($row['balance']);
        $ext = 'f' . hash('sha256', "$date|$time|$amount|$ref|$balance");
        $r = bankIngest($bid, ['source' => 'file', 'external_id' => $ext, 'body' => cleanStr((string) ($row['description'] ?? ''), 500), 'received_at' => now(),
                               'parsed' => ['direction' => 'credit', 'amount' => $amountT, 'balance' => null, 'ref_no' => mb_substr($ref, 0, 40), 'occurred_at' => "$date $time:00"]]);
        if (!empty($r['duplicate'])) { $stats['duplicate']++; continue; }
        $stats['created']++;
        if (($r['match'] ?? '') === 'matched') $stats['matched']++;
        if (($r['match'] ?? '') === 'suggested') $stats['suggested']++;
    }
    audit($bid, 'bank.import', 'ورود گردش حساب: ' . faDigits($stats['created']) . ' واریز جدید');
    respond($stats);
}

/** مبلغ از فایل بانک: «1,500,000»، «1500000.00»، «۱۵۰۰۰۰۰ ریال» → عدد صحیح. */
function bankAmount($v): ?int {
    $t = preg_replace('/[^\d.]/', '', bankNormalize((string) $v));
    $t = preg_replace('/\.\d{1,2}$/', '', $t);
    return money(str_replace('.', '', $t));
}

/** «1405/07/16» شمسی → میلادی ISO (برای فایل‌های بانکی که تاریخ شمسی دارند). */
function jalaliInputToIso(string $v): ?string {
    if (!preg_match('/(1[34]\d{2})[\/\-.](\d{1,2})[\/\-.](\d{1,2})/', toEnDigits($v), $m)) return null;
    [$gy, $gm, $gd] = jalaliToGregorian((int) $m[1], (int) $m[2], (int) $m[3]);
    return sprintf('%04d-%02d-%02d', $gy, $gm, $gd);
}

// ================= دستگاه‌ها و تنظیمات =================

function bank_settings(int $bid): void {
    requireBuilding($bid);
    $b = loadBuilding($bid);
    $s = db()->prepare('SELECT id, name, last_seen_at, revoked_at, created_at FROM bank_devices WHERE building_id = ? ORDER BY id DESC');
    $s->execute([$bid]);
    respond([
        'settings' => ['sms_unit' => $b['bank_sms_unit'], 'senders' => $b['bank_senders'], 'auto_approve' => (bool) (int) $b['bank_auto_approve']],
        'devices' => array_map(fn($d) => ['id' => (int) $d['id']] + $d, $s->fetchAll()),
        'webhook_url' => rtrim(defined('APP_URL') && APP_URL ? APP_URL : '', '/') . '/api/bank/webhook',
    ]);
}

function bank_settings_update(int $bid): void {
    requireBuilding($bid, 'manage');
    $b = body();
    $unit = ($b['sms_unit'] ?? 'rial') === 'toman' ? 'toman' : 'rial';
    $senders = implode(',', array_slice(array_filter(array_map(fn($x) => cleanStr($x, 30), explode(',', toEnDigits((string) ($b['senders'] ?? ''))))), 0, 10));
    $auto = !empty($b['auto_approve']) ? 1 : 0;
    db()->prepare('UPDATE buildings SET bank_sms_unit = ?, bank_senders = ?, bank_auto_approve = ? WHERE id = ?')->execute([$unit, $senders, $auto, $bid]);
    audit($bid, 'bank.settings', 'تنظیمات تطبیق بانکی: واحد پیامک ' . ($unit === 'rial' ? 'ریال' : 'تومان') . '، تأیید خودکار ' . ($auto ? 'روشن' : 'خاموش'));
    bank_settings($bid);
}

/** توکن گوشی فقط یک‌بار نمایش داده می‌شود؛ در دیتابیس فقط هش آن می‌ماند. */
function bank_device_create(int $bid): void {
    requireBuilding($bid, 'manage');
    $name = cleanStr(body()['name'] ?? '', 60) ?: 'گوشی بانک';
    $token = bin2hex(random_bytes(24));
    db()->prepare('INSERT INTO bank_devices (building_id, name, token_hash, created_by, created_at) VALUES (?, ?, ?, ?, ?)')
        ->execute([$bid, $name, hash('sha256', $token), authUserId(), now()]);
    audit($bid, 'bank.device', "افزودن دستگاه دریافت پیامک بانک «{$name}»");
    respond(['id' => (int) db()->lastInsertId(), 'token' => $token], 201);
}

function bank_device_revoke(int $id): void {
    $s = db()->prepare('SELECT * FROM bank_devices WHERE id = ?');
    $s->execute([$id]);
    $d = $s->fetch() ?: fail('NOT_FOUND', 404);
    requireBuilding((int) $d['building_id'], 'manage');
    db()->prepare('UPDATE bank_devices SET revoked_at = ? WHERE id = ? AND revoked_at IS NULL')->execute([now(), $id]);
    audit((int) $d['building_id'], 'bank.device', "باطل کردن دستگاه «{$d['name']}»");
    respond(['ok' => true]);
}

// ================= گزارش روزانه =================

/**
 * جمع‌بندی یک روز: واریزهای بانک، اعلام‌ها، پرداخت‌های ثبت‌شده و مغایرت‌ها. برابری جمع‌ها به‌تنهایی یعنی
 * «درست است» نیست؛ هر مغایرت جدا فهرست می‌شود.
 */
function bankDailyReport(int $bid, string $day): array {
    $db = db();
    $next = date('Y-m-d', strtotime("$day +1 day"));
    $q = function (string $sql, array $args) use ($db) { $s = $db->prepare($sql); $s->execute($args); return $s->fetchAll(); };

    $dep = $q('SELECT status, method, COUNT(*) AS n, COALESCE(SUM(amount), 0) AS total FROM bank_deposits WHERE building_id = ? AND occurred_at >= ? AND occurred_at < ? GROUP BY status, method', [$bid, $day, $next]);
    $by = ['all' => [0, 0], 'auto' => [0, 0], 'manual' => [0, 0], 'unmatched' => [0, 0], 'ambiguous' => [0, 0], 'suggested' => [0, 0], 'ignored' => [0, 0]];
    foreach ($dep as $r) {
        $k = $r['status'] === 'matched' ? ($r['method'] === 'auto' ? 'auto' : 'manual') : $r['status'];
        $by[$k][0] += (int) $r['n']; $by[$k][1] += (int) $r['total'];
        $by['all'][0] += (int) $r['n']; $by['all'][1] += (int) $r['total'];
    }
    $claims = $q("SELECT status, COUNT(*) AS n, COALESCE(SUM(amount), 0) AS total FROM payment_claims WHERE building_id = ? AND date = ? GROUP BY status", [$bid, $day]);
    $payments = $q("SELECT COUNT(*) AS n, COALESCE(SUM(amount), 0) AS total FROM unit_transactions WHERE building_id = ? AND kind = 'payment' AND date = ?", [$bid, $day])[0];
    // اعلامی که تا امروز واریزی برایش در بانک دیده نشده
    $orphanClaims = $q("SELECT c.id, c.amount, c.date, c.ref_no, c.unit_id FROM payment_claims c WHERE c.building_id = ? AND c.status = 'pending' AND c.date <= ?
                          AND NOT EXISTS (SELECT 1 FROM bank_deposits d WHERE d.claim_id = c.id) ORDER BY c.date", [$bid, $day]);
    $gaps = $q("SELECT COUNT(*) AS n FROM bank_events WHERE building_id = ? AND continuity = 'gap' AND occurred_at >= ? AND occurred_at < ?", [$bid, $day, $next])[0];
    $errors = $q("SELECT COUNT(*) AS n FROM bank_events WHERE building_id = ? AND status = 'error' AND received_at >= ? AND received_at < ?", [$bid, $day, $next])[0];

    $pair = fn($a) => ['count' => $a[0], 'total' => $a[1]];
    $claimBy = [];
    foreach ($claims as $c) $claimBy[$c['status']] = ['count' => (int) $c['n'], 'total' => (int) $c['total']];
    return [
        'date' => $day,
        'deposits' => array_map($pair, $by),
        'claims' => $claimBy,
        'payments' => ['count' => (int) $payments['n'], 'total' => (int) $payments['total']],
        'claims_without_deposit' => array_map(fn($c) => ['id' => (int) $c['id'], 'amount' => (int) $c['amount'], 'date' => $c['date'], 'ref_no' => $c['ref_no'], 'unit' => unitNameById((int) $c['unit_id'])], $orphanClaims),
        'balance_gaps' => (int) $gaps['n'],
        'unreadable_sms' => (int) $errors['n'],
    ];
}

function bank_report(int $bid): void {
    requireBuilding($bid);
    respond(bankDailyReport($bid, isoDate($_GET['date'] ?? '') ?? today()));
}

/** cron: رویدادهای پردازش‌نشده (مثلاً قطع وسط کار) و تطبیق دوباره‌ی واریزهای باز. */
function bankCronRun(): array {
    $db = db();
    $stats = ['events' => 0, 'rematched' => 0];
    foreach ($db->query("SELECT id FROM bank_events WHERE status = 'new' AND created_at < '" . date('Y-m-d H:i:s', time() - 60) . "' ORDER BY id LIMIT 500")->fetchAll(PDO::FETCH_COLUMN) as $id) {
        bankProcessEvent((int) $id);
        $stats['events']++;
    }
    foreach ($db->query("SELECT id FROM bank_deposits WHERE status IN ('unmatched', 'ambiguous', 'suggested') AND occurred_at >= '" . date('Y-m-d', strtotime('-30 days')) . "' ORDER BY id LIMIT 2000")->fetchAll(PDO::FETCH_COLUMN) as $id) {
        bankMatchDeposit((int) $id);
        $stats['rematched']++;
    }
    return $stats;
}
