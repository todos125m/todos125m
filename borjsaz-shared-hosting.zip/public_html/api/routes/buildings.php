<?php
// ساختمان‌ها و اعضای تیم مدیریت.

const BUILDING_TYPES = ['residential', 'commercial', 'mixed'];
const MEMBER_ROLES   = ['manager', 'board', 'accountant'];
const WRITE_ROLES    = ['manager', 'accountant'];
const ROLE_LABELS    = ['manager' => 'مدیر', 'board' => 'هیئت‌مدیره', 'accountant' => 'حسابدار'];

// نقشِ کاربرِ فعلی در ساختمان؛ اگر عضو نباشد 404 (وجودِ ساختمان لو نمی‌رود).
function requireBuilding(int $buildingId, string $need = 'read'): string {
    $stmt = db()->prepare('SELECT role FROM building_members WHERE building_id = ? AND user_id = ?');
    $stmt->execute([$buildingId, authUserId()]);
    $role = $stmt->fetchColumn();
    if (!$role) fail('NOT_FOUND', 404);
    if ($need === 'write'  && !in_array($role, WRITE_ROLES, true)) fail('FORBIDDEN', 403);
    if ($need === 'manage' && $role !== 'manager') fail('FORBIDDEN', 403);
    return $role;
}

function userBuildings(int $uid): array {
    $stmt = db()->prepare(
        'SELECT b.id, b.name, b.type, b.city, m.role,
                (SELECT COUNT(*) FROM units u WHERE u.building_id = b.id) AS units_count
           FROM buildings b JOIN building_members m ON m.building_id = b.id
          WHERE m.user_id = ? ORDER BY b.id'
    );
    $stmt->execute([$uid]);
    return array_map(fn($b) => ['id' => (int) $b['id'], 'units_count' => (int) $b['units_count']] + $b, $stmt->fetchAll());
}

function buildingInput(array $b, array $current = []): array {
    $name = cleanStr($b['name'] ?? ($current['name'] ?? ''), 120);
    if (mb_strlen($name) < 2) fail('INVALID_NAME');
    return [
        'name'    => $name,
        'type'    => oneOf($b['type'] ?? ($current['type'] ?? ''), BUILDING_TYPES, 'residential'),
        'city'    => cleanStr($b['city'] ?? ($current['city'] ?? ''), 60),
        'address' => cleanStr($b['address'] ?? ($current['address'] ?? ''), 300),
        'floors'  => array_key_exists('floors', $b) ? optInt($b['floors'], 1, 200) : ($current['floors'] ?? null),
        'blocks'  => array_key_exists('blocks', $b) ? optInt($b['blocks'], 1, 100) : ($current['blocks'] ?? null),
    ];
}

function buildings_list(): void {
    respond(['buildings' => userBuildings(authUserId())]);
}

function buildings_create(): void {
    $uid  = authUserId();
    $body = body();
    $in   = buildingInput($body);
    $initialUnits = optInt($body['initial_units'] ?? null, 0, 2000) ?? 0;

    $db = db();
    $db->beginTransaction();
    $db->prepare('INSERT INTO buildings (name, type, city, address, floors, blocks, created_by, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
       ->execute([$in['name'], $in['type'], $in['city'], $in['address'], $in['floors'], $in['blocks'], $uid, now(), now()]);
    $bid = (int) $db->lastInsertId();
    $db->prepare('INSERT INTO building_members (building_id, user_id, role, created_at) VALUES (?, ?, ?, ?)')
       ->execute([$bid, $uid, 'manager', now()]);
    if ($initialUnits > 0) createNumberedUnits($bid, $initialUnits, 'واحد');
    $db->commit();

    respond(['building' => buildingDetail($bid, 'manager')], 201);
}

function buildings_show(int $bid): void {
    $role = requireBuilding($bid);
    respond(['building' => buildingDetail($bid, $role)]);
}

function buildings_update(int $bid): void {
    requireBuilding($bid, 'manage');
    $stmt = db()->prepare('SELECT * FROM buildings WHERE id = ?');
    $stmt->execute([$bid]);
    $in = buildingInput(body(), $stmt->fetch());
    db()->prepare('UPDATE buildings SET name = ?, type = ?, city = ?, address = ?, floors = ?, blocks = ?, updated_at = ? WHERE id = ?')
        ->execute([$in['name'], $in['type'], $in['city'], $in['address'], $in['floors'], $in['blocks'], now(), $bid]);
    audit($bid, 'building.update', 'ویرایش مشخصات ساختمان');
    respond(['building' => buildingDetail($bid, 'manager')]);
}

function buildingDetail(int $bid, string $role): array {
    $db   = db();
    $stmt = $db->prepare('SELECT * FROM buildings WHERE id = ?');
    $stmt->execute([$bid]);
    $b = $stmt->fetch();

    $q = function (string $sql) use ($db, $bid) {
        $s = $db->prepare($sql);
        $s->execute([$bid]);
        return $s->fetch();
    };

    $u = $q("SELECT COUNT(*) AS units, COALESCE(SUM(residents_count), 0) AS residents, COALESCE(SUM(area), 0) AS area,
                    SUM(CASE WHEN occupancy = 'owner' THEN 1 ELSE 0 END) AS owner_occupied,
                    SUM(CASE WHEN occupancy = 'tenant' THEN 1 ELSE 0 END) AS rented,
                    SUM(CASE WHEN occupancy = 'vacant' THEN 1 ELSE 0 END) AS vacant
               FROM units WHERE building_id = ?");
    $p = $q("SELECT COUNT(*) AS persons,
                    SUM(CASE WHEN role = 'owner' THEN 1 ELSE 0 END) AS owners,
                    SUM(CASE WHEN role = 'tenant' THEN 1 ELSE 0 END) AS tenants,
                    SUM(CASE WHEN mobile IS NOT NULL THEN 1 ELSE 0 END) AS with_mobile
               FROM persons WHERE building_id = ?");
    $unitsWithOwner = (int) $q("SELECT COUNT(DISTINCT unit_id) AS n FROM persons WHERE building_id = ? AND role = 'owner'")['n'];
    $members        = (int) $q('SELECT COUNT(*) AS n FROM building_members WHERE building_id = ?')['n'];

    $units = (int) $u['units'];
    $stats = [
        'units'            => $units,
        'residents'        => (int) $u['residents'],
        'area'             => (float) $u['area'],
        'owner_occupied'   => (int) $u['owner_occupied'],
        'rented'           => (int) $u['rented'],
        'vacant'           => (int) $u['vacant'],
        'persons'          => (int) $p['persons'],
        'owners'           => (int) $p['owners'],
        'tenants'          => (int) $p['tenants'],
        'with_mobile'      => (int) $p['with_mobile'],
        'units_with_owner' => $unitsWithOwner,
        'members'          => $members,
    ];

    // مراحل راه‌اندازی: هر مرحله با داده‌ی واقعی سنجیده می‌شود.
    $setup = [
        ['key' => 'building', 'done' => true],
        ['key' => 'units',    'done' => $units > 0],
        ['key' => 'owners',   'done' => $units > 0 && $unitsWithOwner >= $units],
        ['key' => 'charge',   'done' => chargeConfigured(loadBuilding($bid), $bid)],
        ['key' => 'team',     'done' => $members > 1],
    ];

    return [
        'id' => (int) $b['id'], 'name' => $b['name'], 'type' => $b['type'], 'city' => $b['city'],
        'address' => $b['address'],
        'floors' => $b['floors'] === null ? null : (int) $b['floors'],
        'blocks' => $b['blocks'] === null ? null : (int) $b['blocks'],
        'created_at' => $b['created_at'], 'role' => $role, 'stats' => $stats, 'setup' => $setup,
        'finance' => financeSettings($b),
    ];
}

function members_list(int $bid): void {
    requireBuilding($bid);
    $stmt = db()->prepare(
        'SELECT u.id, u.full_name, u.mobile, m.role, m.created_at
           FROM building_members m JOIN users u ON u.id = m.user_id
          WHERE m.building_id = ? ORDER BY m.id'
    );
    $stmt->execute([$bid]);
    respond(['members' => array_map(fn($r) => ['id' => (int) $r['id']] + $r, $stmt->fetchAll())]);
}

function members_add(int $bid): void {
    requireBuilding($bid, 'manage');
    $body   = body();
    $mobile = normalizeMobile($body['mobile'] ?? '');
    if (!$mobile) fail('INVALID_MOBILE');
    $role = oneOf($body['role'] ?? '', MEMBER_ROLES, '');
    if ($role === '') fail('INVALID_ROLE');

    $user = findOrCreateUser($mobile, cleanStr($body['full_name'] ?? '', 120));
    try {
        db()->prepare('INSERT INTO building_members (building_id, user_id, role, created_at) VALUES (?, ?, ?, ?)')
            ->execute([$bid, $user['id'], $role, now()]);
    } catch (PDOException $e) {
        if (isUniqueViolation($e)) fail('ALREADY_MEMBER', 409);
        throw $e;
    }
    audit($bid, 'member.add', 'افزودن ' . faDigits($mobile) . ' به تیم مدیریت با نقش ' . ROLE_LABELS[$role]);
    members_list($bid);
}

function members_remove(int $bid, int $userId): void {
    requireBuilding($bid, 'manage');
    $db   = db();
    $stmt = $db->prepare('SELECT role FROM building_members WHERE building_id = ? AND user_id = ?');
    $stmt->execute([$bid, $userId]);
    $role = $stmt->fetchColumn();
    if (!$role) fail('NOT_FOUND', 404);

    if ($role === 'manager') {
        $stmt = $db->prepare("SELECT COUNT(*) FROM building_members WHERE building_id = ? AND role = 'manager'");
        $stmt->execute([$bid]);
        if ((int) $stmt->fetchColumn() <= 1) fail('LAST_MANAGER', 409);
    }
    $db->prepare('DELETE FROM building_members WHERE building_id = ? AND user_id = ?')->execute([$bid, $userId]);
    $s = $db->prepare('SELECT COALESCE(NULLIF(full_name, \'\'), mobile) FROM users WHERE id = ?');
    $s->execute([$userId]);
    audit($bid, 'member.remove', 'حذف «' . faDigits($s->fetchColumn()) . '» از تیم مدیریت');
    members_list($bid);
}
