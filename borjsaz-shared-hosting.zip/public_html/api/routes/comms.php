<?php
// ارتباط و شفافیت: پیامک‌های گروهی، ردپای تغییرات، اطلاعیه‌ها، جلسات و مصوبات هیئت‌مدیره،
// گزارش ماهانه، صورت‌حساب قابل چاپ و نسخه‌ی پشتیبانِ داده‌های ساختمان.

const SMS_KINDS = ['invite', 'debt', 'custom'];

// ================= پیامک =================

/** پیام‌های یک ارسال گروهی را می‌سازد (برای پیش‌نمایش و ارسال، یکسان). */
function smsCampaign(int $bid, array $in): array {
    $b    = loadBuilding($bid);
    $kind = oneOf($in['kind'] ?? '', SMS_KINDS, '');
    if ($kind === '') fail('INVALID_KIND');
    $units = array_column(buildingUnits($bid), null, 'id');
    $messages = [];

    if ($kind === 'invite') {
        // فقط کسانی که هنوز وارد سامانه نشده‌اند (مگر «همه» خواسته شود).
        $joined = [];
        if (($in['only_new'] ?? true) !== false) {
            $joined = array_flip(db()->query('SELECT mobile FROM users')->fetchAll(PDO::FETCH_COLUMN));
        }
        foreach (unitContacts($bid, false) as $unitId => $people) {
            foreach ($people as $p) {
                if (isset($joined[$p['mobile']])) continue;
                $messages[] = [$p['mobile'], "{$p['full_name']} گرامی\nپرونده‌ی " . unitName($units[$unitId]) . " در سامانه‌ی مدیریت ساختمان ثبت شد. با همین شماره وارد شوید تا صورت‌حساب، پرداخت‌ها و درخواست‌هایتان را ببینید." . smsFooter($b)];
            }
        }
    } elseif ($kind === 'debt') {
        $min = money($in['min_debt'] ?? '') ?: 1;
        $balances = unitBalances($bid);
        $card = $b['bank_card'] ? "\nکارت: " . faDigits(implode('-', str_split($b['bank_card'], 4))) . ($b['bank_holder'] ? " به نام {$b['bank_holder']}" : '') : '';
        foreach (unitContacts($bid) as $unitId => $people) {
            $debt = $balances[$unitId] ?? 0;
            if ($debt < $min) continue;
            foreach ($people as $p) {
                $messages[] = [$p['mobile'], "{$p['full_name']} گرامی\nمانده‌ی بدهی " . unitName($units[$unitId]) . ': ' . faMoney($debt) . "\nلطفاً در اولین فرصت پرداخت و در سامانه اعلام کنید.$card" . smsFooter($b)];
            }
        }
    } else {
        $text = trim((string) ($in['text'] ?? ''));
        if (mb_strlen($text) < 5) fail('INVALID_TEXT');
        $text = mb_substr($text, 0, 500);
        $audience = oneOf($in['audience'] ?? '', ['all', 'payers', 'owners', 'tenants'], 'all');
        foreach (unitContacts($bid, $audience === 'payers') as $people) {
            foreach ($people as $p) {
                if ($audience === 'owners' && $p['role'] !== 'owner') continue;
                if ($audience === 'tenants' && $p['role'] !== 'tenant') continue;
                $messages[] = [$p['mobile'], $text . smsFooter($b)];
            }
        }
    }
    return [$kind, $messages];
}

function sms_preview(int $bid): void {
    requireBuilding($bid, 'write');
    [, $messages] = smsCampaign($bid, body());
    $mobiles = array_unique(array_column($messages, 0));
    respond(['count' => count($messages), 'recipients' => count($mobiles), 'sample' => $messages[0][1] ?? null, 'live' => APP_ENV !== 'dev']);
}

function sms_send(int $bid): void {
    requireBuilding($bid, 'write');
    if (!rateLimit("sms:$bid", 20, 3600)) fail('TOO_MANY_REQUESTS', 429);
    [$kind, $messages] = smsCampaign($bid, body());
    if (!$messages) fail('NO_RECIPIENTS');
    $res = smsNotify($bid, $kind, $messages);
    audit($bid, "sms.$kind", 'ارسال پیامک ' . SMS_KIND_LABELS[$kind] . ' به ' . faDigits($res['count']) . ' شماره');
    respond($res);
}

const SMS_KIND_LABELS = ['invite' => 'دعوت', 'debt' => 'یادآوری بدهی', 'custom' => 'دلخواه', 'charge' => 'اعلام شارژ', 'assign' => 'تخصیص درخواست', 'claim' => 'رد واریز', 'notice' => 'اطلاعیه'];

function sms_log(int $bid): void {
    requireBuilding($bid);
    $stmt = db()->prepare('SELECT id, mobile, kind, text, status, created_at FROM sms_log WHERE building_id = ? ORDER BY id DESC LIMIT 300');
    $stmt->execute([$bid]);
    $stats = db()->prepare("SELECT COUNT(*) AS total, SUM(CASE WHEN status = 'sent' THEN 1 ELSE 0 END) AS sent, SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) AS failed FROM sms_log WHERE building_id = ? AND created_at >= ?");
    $stats->execute([$bid, date('Y-m-d', strtotime('-30 days'))]);
    $s = $stats->fetch();
    respond([
        'messages' => array_map(fn($m) => ['id' => (int) $m['id']] + $m, $stmt->fetchAll()),
        'last30'   => ['total' => (int) $s['total'], 'sent' => (int) $s['sent'], 'failed' => (int) $s['failed']],
        'live'     => APP_ENV !== 'dev',
    ]);
}

// ================= ردپای تغییرات =================

function audit_list(int $bid): void {
    requireBuilding($bid);
    $where = ['a.building_id = ?'];
    $args  = [$bid];
    if ($before = optInt($_GET['before'] ?? null, 1, PHP_INT_MAX)) { $where[] = 'a.id < ?'; $args[] = $before; }
    if (($prefix = preg_replace('/[^a-z]/', '', $_GET['type'] ?? '')) !== '') { $where[] = 'a.action LIKE ?'; $args[] = "$prefix.%"; }
    if ($unit = optInt($_GET['unit_id'] ?? null, 1, PHP_INT_MAX)) { $where[] = "a.entity = 'unit' AND a.entity_id = ?"; $args[] = $unit; }
    $stmt = db()->prepare('SELECT a.id, a.action, a.entity, a.entity_id, a.summary, a.created_at, u.full_name AS user_name, u.mobile AS user_mobile
                             FROM audit_log a LEFT JOIN users u ON u.id = a.user_id
                            WHERE ' . implode(' AND ', $where) . ' ORDER BY a.id DESC LIMIT 101');
    $stmt->execute($args);
    $rows = array_map(fn($r) => ['id' => (int) $r['id'], 'entity_id' => $r['entity_id'] === null ? null : (int) $r['entity_id']] + $r, $stmt->fetchAll());
    respond(['entries' => array_slice($rows, 0, 100), 'has_more' => count($rows) > 100]);
}

// ================= اطلاعیه‌ها =================

function castNotice(array $n): array {
    return ['id' => (int) $n['id'], 'pinned' => (bool) $n['pinned']] + $n;
}

function buildingNotices(int $bid, int $limit = 100): array {
    $stmt = db()->prepare("SELECT n.id, n.title, n.body, n.pinned, n.created_at, n.updated_at, u.full_name AS author
                             FROM notices n LEFT JOIN users u ON u.id = n.created_by
                            WHERE n.building_id = ? ORDER BY n.pinned DESC, n.id DESC LIMIT $limit");
    $stmt->execute([$bid]);
    return array_map('castNotice', $stmt->fetchAll());
}

function noticeInput(array $b, array $cur = []): array {
    $title = cleanStr($b['title'] ?? ($cur['title'] ?? ''), 150);
    if (mb_strlen($title) < 2) fail('INVALID_TITLE');
    // متن اطلاعیه خط‌بندی دارد؛ فقط فاصله‌های اضافه‌ی سرِ خط‌ها حذف می‌شود.
    $body = trim(preg_replace("/[ \t]+/u", ' ', (string) ($b['body'] ?? ($cur['body'] ?? ''))));
    return ['title' => $title, 'body' => mb_substr($body, 0, 3000), 'pinned' => !empty($b['pinned'] ?? ($cur['pinned'] ?? 0)) ? 1 : 0];
}

function loadNotice(int $id): array {
    $stmt = db()->prepare('SELECT * FROM notices WHERE id = ?');
    $stmt->execute([$id]);
    $n = $stmt->fetch() ?: fail('NOT_FOUND', 404);
    requireBuilding((int) $n['building_id'], 'write');
    return $n;
}

function notices_list(int $bid): void {
    requireBuilding($bid);
    respond(['notices' => buildingNotices($bid)]);
}

function notices_create(int $bid): void {
    requireBuilding($bid, 'write');
    $b  = body();
    $in = noticeInput($b);
    db()->prepare('INSERT INTO notices (building_id, title, body, pinned, created_by, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
        ->execute([$bid, $in['title'], $in['body'], $in['pinned'], authUserId(), now(), now()]);
    $id = (int) db()->lastInsertId();
    audit($bid, 'notice.create', "انتشار اطلاعیه «{$in['title']}»", 'notice', $id);
    $sms = null;
    if (!empty($b['sms'])) {
        $bld = loadBuilding($bid);
        $text = "اطلاعیه: {$in['title']}" . ($in['body'] !== '' ? "\n" . mb_substr($in['body'], 0, 300) . (mb_strlen($in['body']) > 300 ? '…' : '') : '') . smsFooter($bld);
        $messages = [];
        foreach (unitContacts($bid, false) as $people) foreach ($people as $p) $messages[] = [$p['mobile'], $text];
        $sms = smsNotify($bid, 'notice', $messages);
    }
    respond(['notices' => buildingNotices($bid), 'sms' => $sms], 201);
}

function notices_update(int $id): void {
    $n  = loadNotice($id);
    $in = noticeInput(body(), $n);
    db()->prepare('UPDATE notices SET title = ?, body = ?, pinned = ?, updated_at = ? WHERE id = ?')
        ->execute([$in['title'], $in['body'], $in['pinned'], now(), $id]);
    audit((int) $n['building_id'], 'notice.update', "ویرایش اطلاعیه «{$in['title']}»", 'notice', $id);
    respond(['notices' => buildingNotices((int) $n['building_id'])]);
}

function notices_delete(int $id): void {
    $n = loadNotice($id);
    db()->prepare('DELETE FROM notices WHERE id = ?')->execute([$id]);
    audit((int) $n['building_id'], 'notice.delete', "حذف اطلاعیه «{$n['title']}»");
    respond(['notices' => buildingNotices((int) $n['building_id'])]);
}

// ================= جلسات و مصوبات هیئت‌مدیره =================
// همه‌ی اعضای تیم مدیریت (از جمله هیئت‌مدیره) می‌توانند صورت‌جلسه و مصوبه ثبت کنند.

const RESOLUTION_STATUSES = ['open', 'done', 'cancelled'];

function castResolution(array $r): array {
    $r['id'] = (int) $r['id'];
    $r['meeting_id'] = (int) $r['meeting_id'];
    $r['overdue'] = $r['status'] === 'open' && $r['due_date'] && $r['due_date'] < today();
    return $r;
}

function loadMeeting(int $id): array {
    $stmt = db()->prepare('SELECT * FROM meetings WHERE id = ?');
    $stmt->execute([$id]);
    $m = $stmt->fetch() ?: fail('NOT_FOUND', 404);
    requireBuilding((int) $m['building_id']);
    return $m;
}

function meetingInput(array $b, array $cur = []): array {
    $title = cleanStr($b['title'] ?? ($cur['title'] ?? ''), 150);
    if (mb_strlen($title) < 2) fail('INVALID_TITLE');
    return [
        'title'     => $title,
        'date'      => isoDate($b['date'] ?? ($cur['date'] ?? '')) ?? fail('INVALID_DATE'),
        'attendees' => cleanStr($b['attendees'] ?? ($cur['attendees'] ?? ''), 500),
        'minutes'   => mb_substr(trim((string) ($b['minutes'] ?? ($cur['minutes'] ?? ''))), 0, 5000),
    ];
}

function meetings_list(int $bid): void {
    requireBuilding($bid);
    $stmt = db()->prepare("SELECT m.id, m.title, m.date, m.attendees,
                (SELECT COUNT(*) FROM resolutions r WHERE r.meeting_id = m.id) AS resolutions,
                (SELECT COUNT(*) FROM resolutions r WHERE r.meeting_id = m.id AND r.status = 'open') AS open_resolutions
           FROM meetings m WHERE m.building_id = ? ORDER BY m.date DESC, m.id DESC");
    $stmt->execute([$bid]);
    respond(['meetings' => array_map(fn($m) => ['id' => (int) $m['id'], 'resolutions' => (int) $m['resolutions'], 'open_resolutions' => (int) $m['open_resolutions']] + $m, $stmt->fetchAll())]);
}

function meetings_create(int $bid): void {
    requireBuilding($bid);
    $in = meetingInput(body());
    db()->prepare('INSERT INTO meetings (building_id, title, date, attendees, minutes, created_by, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
        ->execute([$bid, $in['title'], $in['date'], $in['attendees'], $in['minutes'], authUserId(), now(), now()]);
    $id = (int) db()->lastInsertId();
    audit($bid, 'meeting.create', "ثبت جلسه «{$in['title']}» " . faDate($in['date']), 'meeting', $id);
    meeting_show($id, 201);
}

/** جلسه + مصوباتش + مصوباتِ بازِ جلسه‌های قبلی (برای پیگیری در همین جلسه). */
function meeting_show(int $id, int $status = 200): void {
    $m = loadMeeting($id);
    $stmt = db()->prepare('SELECT * FROM resolutions WHERE meeting_id = ? ORDER BY id');
    $stmt->execute([$id]);
    $own = array_map('castResolution', $stmt->fetchAll());
    $stmt = db()->prepare("SELECT r.*, m.title AS meeting_title, m.date AS meeting_date FROM resolutions r JOIN meetings m ON m.id = r.meeting_id
                            WHERE r.building_id = ? AND r.status = 'open' AND r.meeting_id <> ? AND (m.date < ? OR (m.date = ? AND m.id < ?))
                            ORDER BY m.date, r.id");
    $stmt->execute([$m['building_id'], $id, $m['date'], $m['date'], $id]);
    respond([
        'meeting' => ['id' => (int) $m['id'], 'building_id' => (int) $m['building_id']] + $m,
        'resolutions' => $own,
        'carried' => array_map('castResolution', $stmt->fetchAll()),
    ], $status);
}

function meeting_update(int $id): void {
    $m  = loadMeeting($id);
    $in = meetingInput(body(), $m);
    db()->prepare('UPDATE meetings SET title = ?, date = ?, attendees = ?, minutes = ?, updated_at = ? WHERE id = ?')
        ->execute([$in['title'], $in['date'], $in['attendees'], $in['minutes'], now(), $id]);
    audit((int) $m['building_id'], 'meeting.update', "ویرایش صورت‌جلسه‌ی «{$in['title']}»", 'meeting', $id);
    meeting_show($id);
}

function meeting_delete(int $id): void {
    $m = loadMeeting($id);
    db()->prepare('DELETE FROM meetings WHERE id = ?')->execute([$id]);
    audit((int) $m['building_id'], 'meeting.delete', "حذف جلسه «{$m['title']}» و مصوباتش");
    respond(['ok' => true]);
}

function resolutionInput(array $b, array $cur = []): array {
    $title = cleanStr($b['title'] ?? ($cur['title'] ?? ''), 300);
    if (mb_strlen($title) < 2) fail('INVALID_TITLE');
    $due = array_key_exists('due_date', $b) ? $b['due_date'] : ($cur['due_date'] ?? null);
    return [
        'title'    => $title,
        'owner'    => cleanStr($b['owner'] ?? ($cur['owner'] ?? ''), 120),
        'due_date' => ($due === null || $due === '') ? null : (isoDate($due) ?? fail('INVALID_DATE')),
    ];
}

function resolutions_create(int $meetingId): void {
    $m  = loadMeeting($meetingId);
    $in = resolutionInput(body());
    db()->prepare("INSERT INTO resolutions (building_id, meeting_id, title, owner, due_date, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, 'open', ?, ?)")
        ->execute([$m['building_id'], $meetingId, $in['title'], $in['owner'], $in['due_date'], now(), now()]);
    audit((int) $m['building_id'], 'resolution.create', "مصوبه‌ی «{$in['title']}»" . ($in['owner'] ? " — مسئول: {$in['owner']}" : ''), 'meeting', $meetingId);
    meeting_show($meetingId, 201);
}

function loadResolution(int $id): array {
    $stmt = db()->prepare('SELECT * FROM resolutions WHERE id = ?');
    $stmt->execute([$id]);
    $r = $stmt->fetch() ?: fail('NOT_FOUND', 404);
    requireBuilding((int) $r['building_id']);
    return $r;
}

function resolution_update(int $id): void {
    $r  = loadResolution($id);
    $b  = body();
    $in = resolutionInput($b, $r);
    $status = oneOf($b['status'] ?? $r['status'], RESOLUTION_STATUSES, $r['status']);
    $doneNote = cleanStr($b['done_note'] ?? $r['done_note'], 500);
    $doneAt = $status === 'open' ? null : ($r['status'] === $status ? $r['done_at'] : now());
    db()->prepare('UPDATE resolutions SET title = ?, owner = ?, due_date = ?, status = ?, done_note = ?, done_at = ?, updated_at = ? WHERE id = ?')
        ->execute([$in['title'], $in['owner'], $in['due_date'], $status, $doneNote, $doneAt, now(), $id]);
    if ($status !== $r['status']) {
        $label = ['open' => 'بازگشایی', 'done' => 'انجام', 'cancelled' => 'لغو'][$status];
        audit((int) $r['building_id'], 'resolution.status', "$label مصوبه‌ی «{$in['title']}»" . ($doneNote ? ": $doneNote" : ''), 'meeting', (int) $r['meeting_id']);
    }
    $from = optInt($b['meeting_id'] ?? null, 1, PHP_INT_MAX);
    meeting_show($from ?: (int) $r['meeting_id']);
}

function resolution_delete(int $id): void {
    $r = loadResolution($id);
    db()->prepare('DELETE FROM resolutions WHERE id = ?')->execute([$id]);
    audit((int) $r['building_id'], 'resolution.delete', "حذف مصوبه‌ی «{$r['title']}»", 'meeting', (int) $r['meeting_id']);
    meeting_show((int) $r['meeting_id']);
}

function resolutions_list(int $bid): void {
    requireBuilding($bid);
    $status = in_array($_GET['status'] ?? '', RESOLUTION_STATUSES, true) ? $_GET['status'] : 'open';
    $stmt = db()->prepare('SELECT r.*, m.title AS meeting_title, m.date AS meeting_date FROM resolutions r JOIN meetings m ON m.id = r.meeting_id
                            WHERE r.building_id = ? AND r.status = ? ORDER BY CASE WHEN r.due_date IS NULL THEN 1 ELSE 0 END, r.due_date, r.id LIMIT 300');
    $stmt->execute([$bid, $status]);
    respond(['resolutions' => array_map('castResolution', $stmt->fetchAll())]);
}

// ================= گزارش ماهانه‌ی هیئت‌مدیره =================

function monthly_report(int $bid): void {
    requireBuilding($bid);
    $period = jalaliPeriod($_GET['period'] ?? '') ?? currentPeriod();
    [$from, $to] = periodRange($period);
    $b  = loadBuilding($bid);
    $db = db();
    $q = function (string $sql, array $args) use ($db) {
        $s = $db->prepare($sql);
        $s->execute($args);
        return $s;
    };

    // مالی
    $charge = $q("SELECT
            COALESCE(SUM(CASE WHEN kind = 'charge' THEN amount ELSE 0 END), 0) AS charged,
            COALESCE(SUM(CASE WHEN kind = 'discount' THEN amount ELSE 0 END), 0) AS discount,
            COALESCE(SUM(CASE WHEN kind = 'penalty' THEN amount ELSE 0 END), 0) AS penalty,
            SUM(CASE WHEN kind = 'charge' THEN 1 ELSE 0 END) AS units
        FROM unit_transactions WHERE building_id = ? AND period = ?", [$bid, $period])->fetch();
    $flow = $q("SELECT
            COALESCE(SUM(CASE WHEN kind = 'payment' AND date BETWEEN ? AND ? THEN amount ELSE 0 END), 0) AS received,
            COALESCE(SUM(CASE WHEN kind = 'payment' AND date <= ? THEN amount ELSE 0 END), 0) AS paid_to_end,
            COALESCE(SUM(CASE WHEN kind IN ('debt') AND date BETWEEN ? AND ? THEN amount ELSE 0 END), 0) AS other_debts
        FROM unit_transactions WHERE building_id = ?", [$from, $to, $to, $from, $to, $bid])->fetch();
    $fund = $q("SELECT
            COALESCE(SUM(CASE WHEN direction = 'in' AND date <= ? THEN amount WHEN direction = 'out' AND date <= ? THEN -amount ELSE 0 END), 0) AS net_to_end,
            COALESCE(SUM(CASE WHEN direction = 'in' AND date BETWEEN ? AND ? THEN amount ELSE 0 END), 0) AS income
        FROM fund_entries WHERE building_id = ?", [$to, $to, $from, $to, $bid])->fetch();
    $expenses = $q("SELECT category, SUM(amount) AS total, COUNT(*) AS n FROM fund_entries WHERE building_id = ? AND direction = 'out' AND date BETWEEN ? AND ? GROUP BY category ORDER BY total DESC",
        [$bid, $from, $to])->fetchAll();
    $expenseTotal = array_sum(array_column($expenses, 'total'));

    // وصولِ شارژ این دوره: واحدهایی که مانده‌شان بعد از این دوره صفر یا بستانکار است.
    $balances = unitBalances($bid);
    $chargedUnits = $q("SELECT unit_id FROM unit_transactions WHERE building_id = ? AND period = ? AND kind = 'charge'", [$bid, $period])->fetchAll(PDO::FETCH_COLUMN);
    $settled = count(array_filter($chargedUnits, fn($u) => ($balances[(int) $u] ?? 0) <= 0));

    $debtors = [];
    $units = array_column(buildingUnits($bid), null, 'id');
    arsort($balances);
    foreach ($balances as $unitId => $bal) {
        if ($bal <= 0 || count($debtors) >= 10) break;
        $debtors[] = ['unit_id' => $unitId, 'title' => $units[$unitId]['title'] ?? '', 'block' => $units[$unitId]['block'] ?? '', 'balance' => $bal];
    }

    // خدمات
    $req = $q("SELECT
            SUM(CASE WHEN created_at BETWEEN ? AND ? THEN 1 ELSE 0 END) AS opened,
            SUM(CASE WHEN done_at BETWEEN ? AND ? THEN 1 ELSE 0 END) AS done,
            SUM(CASE WHEN status IN ('new', 'approved', 'assigned', 'done') THEN 1 ELSE 0 END) AS open_now,
            SUM(CASE WHEN status IN ('new', 'approved', 'assigned') AND priority = 'urgent' THEN 1 ELSE 0 END) AS urgent_now,
            COALESCE(SUM(CASE WHEN done_at BETWEEN ? AND ? THEN cost ELSE 0 END), 0) AS cost
        FROM service_requests WHERE building_id = ?", [$from, "$to 23:59:59", $from, "$to 23:59:59", $from, "$to 23:59:59", $bid])->fetch();
    $byType = $q("SELECT type, COUNT(*) AS n FROM service_requests WHERE building_id = ? AND created_at BETWEEN ? AND ? GROUP BY type ORDER BY n DESC",
        [$bid, $from, "$to 23:59:59"])->fetchAll();
    $services = $q('SELECT es.date, es.cost, e.name FROM equipment_services es JOIN equipment e ON e.id = es.equipment_id WHERE es.building_id = ? AND es.date BETWEEN ? AND ? ORDER BY es.date',
        [$bid, $from, $to])->fetchAll();
    $overdue = [];
    foreach ($q('SELECT * FROM equipment WHERE building_id = ? AND active = 1 AND service_interval_days IS NOT NULL', [$bid])->fetchAll() as $e) {
        $st = equipmentStatus($e);
        if (in_array($st['service_status'], ['overdue', 'never'], true)) $overdue[] = ['name' => $e['name'], 'status' => $st['service_status'], 'next_service_date' => $st['next_service_date']];
    }

    // هیئت‌مدیره
    $meetings = $q('SELECT id, title, date FROM meetings WHERE building_id = ? AND date BETWEEN ? AND ? ORDER BY date', [$bid, $from, $to])->fetchAll();
    $openRes = $q("SELECT r.*, m.title AS meeting_title, m.date AS meeting_date FROM resolutions r JOIN meetings m ON m.id = r.meeting_id WHERE r.building_id = ? AND r.status = 'open' ORDER BY r.due_date IS NULL, r.due_date", [$bid])->fetchAll();
    $doneRes = (int) $q("SELECT COUNT(*) FROM resolutions WHERE building_id = ? AND status = 'done' AND done_at BETWEEN ? AND ?", [$bid, $from, "$to 23:59:59"])->fetchColumn();
    $notices = $q('SELECT id, title, created_at FROM notices WHERE building_id = ? AND created_at BETWEEN ? AND ? ORDER BY id', [$bid, $from, "$to 23:59:59"])->fetchAll();

    respond(['report' => [
        'period' => $period, 'from' => $from, 'to' => $to, 'generated_at' => now(),
        'building' => ['name' => $b['name'], 'address' => $b['address'], 'city' => $b['city']],
        'finance' => [
            'charged' => (int) $charge['charged'], 'discount' => (int) $charge['discount'], 'penalty' => (int) $charge['penalty'],
            'charged_units' => (int) $charge['units'], 'settled_units' => $settled,
            'other_debts' => (int) $flow['other_debts'],
            'received' => (int) $flow['received'], 'income' => (int) $fund['income'], 'expenses' => (int) $expenseTotal,
            'expenses_by_category' => array_map(fn($e) => ['category' => $e['category'], 'total' => (int) $e['total'], 'count' => (int) $e['n']], $expenses),
            'fund_balance_end' => (int) $b['opening_balance'] + (int) $flow['paid_to_end'] + (int) $fund['net_to_end'],
            'units_debt_now' => array_sum(array_filter($balances, fn($v) => $v > 0)),
            'debtor_units_now' => count(array_filter($balances, fn($v) => $v > 0)),
            'top_debtors' => $debtors,
        ],
        'services' => [
            'opened' => (int) $req['opened'], 'done' => (int) $req['done'], 'open_now' => (int) $req['open_now'],
            'urgent_now' => (int) $req['urgent_now'], 'repair_cost' => (int) $req['cost'],
            'by_type' => array_map(fn($t) => ['type' => $t['type'], 'count' => (int) $t['n']], $byType),
            'equipment_services' => array_map(fn($s) => ['name' => $s['name'], 'date' => $s['date'], 'cost' => (int) $s['cost']], $services),
            'equipment_attention' => $overdue,
        ],
        'board' => [
            'meetings' => array_map(fn($m) => ['id' => (int) $m['id']] + $m, $meetings),
            'resolutions_done' => $doneRes,
            'open_resolutions' => array_map('castResolution', $openRes),
            'notices' => array_map(fn($n) => ['id' => (int) $n['id']] + $n, $notices),
        ],
    ]]);
}

// ================= صورت‌حساب قابل چاپ =================

/** صورت‌حسابِ یک دوره برای واحدها: ردیف‌های دوره، مانده‌ی قبل، جمع دوره و مانده‌ی فعلی. */
function invoiceData(int $bid, string $period, ?int $onlyUnit = null): array {
    $b = loadBuilding($bid);
    $stmt = db()->prepare("SELECT * FROM unit_transactions WHERE building_id = ? AND period = ? ORDER BY unit_id, id");
    $stmt->execute([$bid, $period]);
    $lines = [];
    foreach ($stmt->fetchAll() as $t) $lines[(int) $t['unit_id']][] = castTx($t);
    $balances = unitBalances($bid);
    $owner = ownerBalances($bid);

    $s = db()->prepare("SELECT unit_id, role, full_name FROM persons WHERE building_id = ? ORDER BY CASE role WHEN 'owner' THEN 0 ELSE 1 END, id");
    $s->execute([$bid]);
    $people = [];
    foreach ($s->fetchAll() as $p) $people[(int) $p['unit_id']][$p['role']][] = $p['full_name'];

    $out = [];
    foreach (buildingUnits($bid) as $u) {
        $id = (int) $u['id'];
        if ($onlyUnit && $id !== $onlyUnit) continue;
        if (!$onlyUnit && empty($lines[$id])) continue;
        $net = 0;
        foreach ($lines[$id] ?? [] as $t) $net += in_array($t['kind'], DEBIT_KINDS, true) ? $t['amount'] : -$t['amount'];
        $now = $balances[$id] ?? 0;
        $out[] = [
            'unit' => ['id' => $id, 'title' => $u['title'], 'block' => $u['block'], 'floor' => $u['floor'] === null ? null : (int) $u['floor'],
                       'area' => $u['area'] === null ? null : (float) $u['area'], 'residents_count' => (int) $u['residents_count'], 'parking_count' => (int) $u['parking_count']],
            'owners' => $people[$id]['owner'] ?? [], 'tenants' => $people[$id]['tenant'] ?? [],
            'lines' => array_map(fn($t) => ['kind' => $t['kind'], 'title' => $t['title'], 'amount' => $t['amount'], 'payer' => $t['payer']], $lines[$id] ?? []),
            'due_date' => array_values(array_filter(array_column($lines[$id] ?? [], 'due_date')))[0] ?? null,
            'period_total' => $net, 'previous_balance' => $now - $net, 'balance' => $now, 'owner_balance' => $owner[$id] ?? 0,
            'monthly_charge' => chargeFor($u, $b),
        ];
    }
    return [
        'period' => $period, 'issued_at' => today(),
        'building' => ['name' => $b['name'], 'address' => $b['address'], 'city' => $b['city'], 'postal_code' => $b['postal_code'],
                       'bank_name' => $b['bank_name'], 'bank_holder' => $b['bank_holder'], 'bank_sheba' => $b['bank_sheba'], 'bank_card' => $b['bank_card']],
        'invoices' => $out,
    ];
}

function latestChargePeriod(int $bid, ?int $unitId = null): ?string {
    $stmt = db()->prepare("SELECT MAX(period) FROM unit_transactions WHERE building_id = ? AND kind = 'charge'" . ($unitId ? ' AND unit_id = ?' : ''));
    $stmt->execute($unitId ? [$bid, $unitId] : [$bid]);
    return $stmt->fetchColumn() ?: null;
}

function invoices(int $bid): void {
    requireBuilding($bid);
    $unit = optInt($_GET['unit_id'] ?? null, 1, PHP_INT_MAX);
    $period = jalaliPeriod($_GET['period'] ?? '') ?? latestChargePeriod($bid, $unit) ?? currentPeriod();
    respond(invoiceData($bid, $period, $unit));
}

function me_invoice(int $unitId): void {
    $unit = requireResident($unitId);
    $bid = (int) $unit['building_id'];
    $period = jalaliPeriod($_GET['period'] ?? '') ?? latestChargePeriod($bid, $unitId) ?? currentPeriod();
    respond(invoiceData($bid, $period, $unitId));
}

// ================= نسخه‌ی پشتیبان (خروجی کامل داده‌های ساختمان) =================

function building_export(int $bid): void {
    requireBuilding($bid, 'manage');
    $tables = [
        'buildings' => 'id = ?', 'building_members' => 'building_id = ?', 'units' => 'building_id = ?', 'persons' => 'building_id = ?',
        'fund_entries' => 'building_id = ?', 'unit_transactions' => 'building_id = ?', 'payment_claims' => 'building_id = ?',
        'staff' => 'building_id = ?', 'equipment' => 'building_id = ?', 'equipment_services' => 'building_id = ?',
        'service_requests' => 'building_id = ?', 'notices' => 'building_id = ?', 'meetings' => 'building_id = ?',
        'resolutions' => 'building_id = ?', 'audit_log' => 'building_id = ?', 'sms_log' => 'building_id = ?',
    ];
    $data = [];
    foreach ($tables as $t => $where) {
        $s = db()->prepare("SELECT * FROM $t WHERE $where");
        $s->execute([$bid]);
        $data[$t] = $s->fetchAll();
    }
    $s = db()->prepare('SELECT ev.* FROM request_events ev JOIN service_requests r ON r.id = ev.request_id WHERE r.building_id = ?');
    $s->execute([$bid]);
    $data['request_events'] = $s->fetchAll();
    audit($bid, 'building.export', 'دریافت نسخه‌ی پشتیبان کامل');
    respond(['app' => 'borjsaz', 'version' => 1, 'exported_at' => now(), 'building_id' => $bid, 'data' => $data]);
}
