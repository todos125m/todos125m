<?php
// مدیریت مالی: تنظیمات شارژ، صدور شارژ، دفتر حساب واحدها، هزینه و درآمد، صورت‌وضعیت.
// همه‌ی مبالغ عدد صحیح به تومان‌اند. بدهکار: charge, debt, penalty — بستانکار: payment, discount.

const DEBIT_KINDS   = ['charge', 'debt', 'penalty'];
const CREDIT_KINDS  = ['payment', 'discount'];
const KIND_LABELS   = ['charge' => 'شارژ', 'debt' => 'بدهی', 'penalty' => 'جریمه', 'payment' => 'پرداخت', 'discount' => 'تخفیف'];
const PAY_METHODS   = ['cash', 'card', 'transfer', 'online', 'cheque'];
const ALLOCATIONS   = ['equal', 'area', 'residents'];
const OUT_CATEGORIES = ['cleaning', 'elevator', 'water', 'electricity', 'gas', 'repair', 'staff', 'supplies', 'insurance', 'other'];
const IN_CATEGORIES  = ['rent', 'deposit', 'sale', 'other'];

const SETTING_LABELS = [
    'charge_fixed' => 'شارژ ثابت', 'charge_per_sqm' => 'شارژ هر متر', 'charge_per_person' => 'شارژ هر نفر', 'charge_per_parking' => 'شارژ هر پارکینگ',
    'opening_balance' => 'موجودی اولیه', 'charge_vacant_percent' => 'درصد واحد خالی', 'charge_due_day' => 'روز سررسید',
    'late_fee_grace_days' => 'مهلت جریمه', 'charge_round' => 'گرد کردن', 'late_fee_percent' => 'درصد جریمه', 'good_payer_percent' => 'تخفیف خوش‌حسابی',
    'postal_code' => 'کد پستی', 'bank_name' => 'نام بانک', 'bank_holder' => 'صاحب حساب', 'bank_sheba' => 'شبا', 'bank_card' => 'شماره کارت',
    'sms_notify_staff' => 'پیامک به مسئول درخواست',
];

// مانده‌ی هر ردیف: بدهی مثبت، پرداخت منفی
const SIGNED_AMOUNT = "(CASE WHEN kind IN ('charge', 'debt', 'penalty') THEN amount ELSE -amount END)";

function loadBuilding(int $bid): array {
    $stmt = db()->prepare('SELECT * FROM buildings WHERE id = ?');
    $stmt->execute([$bid]);
    return $stmt->fetch();
}

function financeSettings(array $b): array {
    return [
        'postal_code'           => $b['postal_code'],
        'opening_balance'       => (int) $b['opening_balance'],
        'charge_fixed'          => (int) $b['charge_fixed'],
        'charge_per_sqm'        => (int) $b['charge_per_sqm'],
        'charge_per_person'     => (int) $b['charge_per_person'],
        'charge_per_parking'    => (int) $b['charge_per_parking'],
        'charge_vacant_percent' => (int) $b['charge_vacant_percent'],
        'charge_round'          => (int) $b['charge_round'],
        'charge_due_day'        => (int) $b['charge_due_day'],
        'late_fee_percent'      => (float) $b['late_fee_percent'],
        'late_fee_grace_days'   => (int) $b['late_fee_grace_days'],
        'good_payer_percent'    => (float) $b['good_payer_percent'],
        'bank_name'             => $b['bank_name'],
        'bank_holder'           => $b['bank_holder'],
        'bank_sheba'            => $b['bank_sheba'],
        'bank_card'             => $b['bank_card'],
        'sms_notify_staff'      => (bool) $b['sms_notify_staff'],
    ];
}

/** شارژ ماهانه‌ی یک واحد طبق قاعده‌ی ساختمان (یا مبلغِ اختصاصیِ واحد). */
function chargeFor(array $u, array $b): int {
    if ($u['charge_override'] !== null) return max(0, (int) $u['charge_override']);
    $amount = (int) $b['charge_fixed']
        + (int) $b['charge_per_sqm'] * (float) ($u['area'] ?? 0)
        + (int) $b['charge_per_person'] * (int) $u['residents_count']
        + (int) $b['charge_per_parking'] * (int) $u['parking_count'];
    if ($u['occupancy'] === 'vacant') $amount *= (int) $b['charge_vacant_percent'] / 100;
    $round = (int) $b['charge_round'];
    if ($round > 0) $amount = round($amount / $round) * $round;
    return max(0, (int) round($amount));
}

function chargeConfigured(array $b, int $bid): bool {
    if ((int) $b['charge_fixed'] + (int) $b['charge_per_sqm'] + (int) $b['charge_per_person'] + (int) $b['charge_per_parking'] > 0) return true;
    $stmt = db()->prepare('SELECT 1 FROM units WHERE building_id = ? AND charge_override IS NOT NULL LIMIT 1');
    $stmt->execute([$bid]);
    return (bool) $stmt->fetchColumn();
}

/** مانده‌ی همه‌ی واحدهای ساختمان: [unit_id => balance] */
function unitBalances(int $bid): array {
    $stmt = db()->prepare('SELECT unit_id, SUM(' . SIGNED_AMOUNT . ') AS balance FROM unit_transactions WHERE building_id = ? GROUP BY unit_id');
    $stmt->execute([$bid]);
    return array_map('intval', $stmt->fetchAll(PDO::FETCH_KEY_PAIR));
}

function buildingUnits(int $bid): array {
    $stmt = db()->prepare('SELECT * FROM units WHERE building_id = ? ORDER BY block, id');
    $stmt->execute([$bid]);
    return $stmt->fetchAll();
}

function castTx(array $t): array {
    foreach (['id', 'building_id', 'unit_id', 'amount'] as $k) $t[$k] = (int) $t[$k];
    $t['payer'] ??= 'unit';
    $t['fund_entry_id'] = $t['fund_entry_id'] === null ? null : (int) $t['fund_entry_id'];
    return $t;
}

function insertTx(array $t): void {
    db()->prepare('INSERT INTO unit_transactions (building_id, unit_id, kind, amount, title, period, due_date, date, method, ref_no, notes, fund_entry_id, payer, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
        ->execute([
            $t['building_id'], $t['unit_id'], $t['kind'], $t['amount'], $t['title'] ?? '', $t['period'] ?? '',
            $t['due_date'] ?? null, $t['date'], $t['method'] ?? '', $t['ref_no'] ?? '', $t['notes'] ?? '',
            $t['fund_entry_id'] ?? null, $t['payer'] ?? 'unit', authUserId(), now(),
        ]);
}

/**
 * سهم مالک: هزینه‌هایی که با مالک است (مثلاً تعمیرات اساسی) با payer = 'owner' ثبت می‌شوند؛
 * مانده‌ی کلِ واحد همان جمع همه است و «سهم مالک» جداگانه نمایش داده می‌شود.
 */
function payerInput($v): string {
    return $v === 'owner' ? 'owner' : 'unit';
}

function ownerBalances(int $bid): array {
    $stmt = db()->prepare("SELECT unit_id, SUM(" . SIGNED_AMOUNT . ") AS balance FROM unit_transactions WHERE building_id = ? AND payer = 'owner' GROUP BY unit_id");
    $stmt->execute([$bid]);
    return array_map('intval', $stmt->fetchAll(PDO::FETCH_KEY_PAIR));
}

/**
 * گیرندگانِ پیامکِ واحدها: [unit_id => [person, ...]].
 * $payerOnly: واحدِ اجاره‌ای فقط به مستأجر (اگر موبایل دارد)، وگرنه به مالک.
 */
function unitContacts(int $bid, bool $payerOnly = true): array {
    $stmt = db()->prepare("SELECT p.unit_id, p.role, p.full_name, p.mobile, u.occupancy FROM persons p JOIN units u ON u.id = p.unit_id
                            WHERE p.building_id = ? AND p.mobile IS NOT NULL AND p.mobile <> '' ORDER BY p.id");
    $stmt->execute([$bid]);
    $all = [];
    foreach ($stmt->fetchAll() as $p) $all[(int) $p['unit_id']][] = $p;
    if (!$payerOnly) return $all;
    $out = [];
    foreach ($all as $unitId => $people) {
        $tenants = array_values(array_filter($people, fn($p) => $p['role'] === 'tenant'));
        $owners  = array_values(array_filter($people, fn($p) => $p['role'] === 'owner'));
        $out[$unitId] = ($people[0]['occupancy'] === 'tenant' && $tenants) ? $tenants : ($owners ?: $people);
    }
    return $out;
}

/**
 * تقسیم یک مبلغ بین واحدها به نسبتِ مساوی، متراژ یا نفرات. جمعِ سهم‌ها دقیقاً برابر کل است
 * (باقیمانده‌ی گرد کردن به واحدهایی با بیشترین کسر داده می‌شود).
 */
function allocate(int $total, array $units, string $method): array {
    $weights = [];
    foreach ($units as $u) {
        $weights[$u['id']] = match ($method) {
            'area'      => (float) ($u['area'] ?? 0),
            'residents' => (int) $u['residents_count'],
            default     => 1,
        };
    }
    $sum = array_sum($weights);
    if ($sum <= 0) fail('NO_ALLOCATION_BASE');

    $shares = $fractions = [];
    foreach ($weights as $id => $w) {
        $exact = $total * $w / $sum;
        $shares[$id] = (int) floor($exact);
        $fractions[$id] = $exact - $shares[$id];
    }
    arsort($fractions);
    $left = $total - array_sum($shares);
    foreach (array_keys($fractions) as $id) {
        if ($left-- <= 0) break;
        $shares[$id]++;
    }
    return array_filter($shares, fn($s) => $s > 0);
}

// ================= تنظیمات مالی =================

function finance_settings_update(int $bid): void {
    requireBuilding($bid, 'write');
    $b    = body();
    $set  = [];

    $moneyField = function (string $k, bool $neg = false) use ($b, &$set) {
        if (!array_key_exists($k, $b)) return;
        $v = $b[$k] === '' ? 0 : money($b[$k], $neg);
        if ($v === null) fail('INVALID_AMOUNT', 400, ['field' => $k]);
        $set[$k] = $v;
    };
    foreach (['charge_fixed', 'charge_per_sqm', 'charge_per_person', 'charge_per_parking'] as $k) $moneyField($k);
    $moneyField('opening_balance', true);

    $intField = function (string $k, int $min, int $max) use ($b, &$set) {
        if (!array_key_exists($k, $b)) return;
        $v = optInt($b[$k], $min, $max);
        if ($v === null) fail('INVALID_NUMBER', 400, ['field' => $k]);
        $set[$k] = $v;
    };
    $intField('charge_vacant_percent', 0, 100);
    $intField('charge_due_day', 1, 31);
    $intField('late_fee_grace_days', 0, 90);
    if (array_key_exists('charge_round', $b)) {
        $set['charge_round'] = in_array((int) $b['charge_round'], [0, 100, 1000, 10000], true) ? (int) $b['charge_round'] : fail('INVALID_NUMBER', 400, ['field' => 'charge_round']);
    }
    foreach (['late_fee_percent', 'good_payer_percent'] as $k) {
        if (!array_key_exists($k, $b)) continue;
        $v = $b[$k] === '' ? 0.0 : optDecimal($b[$k], 100);
        if ($v === null) fail('INVALID_PERCENT', 400, ['field' => $k]);
        $set[$k] = $v;
    }

    if (array_key_exists('postal_code', $b)) {
        $pc = preg_replace('/\D/', '', toEnDigits($b['postal_code']));
        if ($pc !== '' && strlen($pc) !== 10) fail('INVALID_POSTAL_CODE');
        $set['postal_code'] = $pc;
    }
    if (array_key_exists('sms_notify_staff', $b)) $set['sms_notify_staff'] = empty($b['sms_notify_staff']) ? 0 : 1;
    if (array_key_exists('bank_name', $b))   $set['bank_name']   = cleanStr($b['bank_name'], 60);
    if (array_key_exists('bank_holder', $b)) $set['bank_holder'] = cleanStr($b['bank_holder'], 120);
    if (array_key_exists('bank_sheba', $b)) {
        $raw = trim((string) $b['bank_sheba']);
        $set['bank_sheba'] = $raw === '' ? '' : (normalizeSheba($raw) ?? fail('INVALID_SHEBA'));
    }
    if (array_key_exists('bank_card', $b)) {
        $raw = trim((string) $b['bank_card']);
        $set['bank_card'] = $raw === '' ? '' : (normalizeCard($raw) ?? fail('INVALID_CARD'));
    }

    if ($set) {
        $cols = implode(', ', array_map(fn($k) => "$k = ?", array_keys($set)));
        db()->prepare("UPDATE buildings SET $cols, updated_at = ? WHERE id = ?")->execute([...array_values($set), now(), $bid]);
        audit($bid, 'settings.finance', 'تغییر تنظیمات مالی: ' . implode('، ', array_map(fn($k) => SETTING_LABELS[$k] ?? $k, array_keys($set))));
    }
    respond(['settings' => financeSettings(loadBuilding($bid))]);
}

// ================= خلاصه و صورت‌وضعیت =================

function finance_summary(int $bid): void {
    requireBuilding($bid);
    $from = isoDate($_GET['from'] ?? '') ?? '0000-01-01';
    $to   = isoDate($_GET['to'] ?? '') ?? '9999-12-31';
    $b    = loadBuilding($bid);
    $db   = db();

    $s = $db->prepare("SELECT
            COALESCE(SUM(CASE WHEN kind = 'payment' THEN amount ELSE 0 END), 0) AS paid_all,
            COALESCE(SUM(CASE WHEN kind = 'payment' AND date BETWEEN ? AND ? THEN amount ELSE 0 END), 0) AS paid_range,
            COALESCE(SUM(CASE WHEN kind IN ('charge', 'debt', 'penalty') AND date BETWEEN ? AND ? THEN amount ELSE 0 END), 0) AS billed_range
        FROM unit_transactions WHERE building_id = ?");
    $s->execute([$from, $to, $from, $to, $bid]);
    $tx = $s->fetch();

    $s = $db->prepare("SELECT
            COALESCE(SUM(CASE WHEN direction = 'in' THEN amount ELSE -amount END), 0) AS net_all,
            COALESCE(SUM(CASE WHEN direction = 'out' AND date BETWEEN ? AND ? THEN amount ELSE 0 END), 0) AS out_range,
            COALESCE(SUM(CASE WHEN direction = 'in' AND date BETWEEN ? AND ? THEN amount ELSE 0 END), 0) AS in_range
        FROM fund_entries WHERE building_id = ?");
    $s->execute([$from, $to, $from, $to, $bid]);
    $fund = $s->fetch();

    $balances = unitBalances($bid);
    $s = $db->prepare("SELECT period FROM unit_transactions WHERE building_id = ? AND kind = 'charge' ORDER BY period DESC LIMIT 1");
    $s->execute([$bid]);

    respond(['summary' => [
        'fund_balance'      => (int) $b['opening_balance'] + (int) $tx['paid_all'] + (int) $fund['net_all'],
        'opening_balance'   => (int) $b['opening_balance'],
        'units_debt'        => array_sum(array_filter($balances, fn($v) => $v > 0)),
        'units_credit'      => -array_sum(array_filter($balances, fn($v) => $v < 0)),
        'debtor_units'      => count(array_filter($balances, fn($v) => $v > 0)),
        'received'          => (int) $tx['paid_range'],
        'billed'            => (int) $tx['billed_range'],
        'expenses'          => (int) $fund['out_range'],
        'income'            => (int) $fund['in_range'],
        'charge_configured' => chargeConfigured($b, $bid),
        'last_period'       => $s->fetchColumn() ?: null,
        'pending_claims'    => pendingClaims($bid),
    ]]);
}

function pendingClaims(int $bid): int {
    $s = db()->prepare("SELECT COUNT(*) FROM payment_claims WHERE building_id = ? AND status = 'pending'");
    $s->execute([$bid]);
    return (int) $s->fetchColumn();
}

function finance_statement(int $bid): void {
    requireBuilding($bid);
    $b  = loadBuilding($bid);
    $s  = db()->prepare("SELECT unit_id,
                COALESCE(SUM(CASE WHEN kind IN ('charge', 'debt', 'penalty') THEN amount ELSE 0 END), 0) AS debit,
                COALESCE(SUM(CASE WHEN kind IN ('payment', 'discount') THEN amount ELSE 0 END), 0) AS credit,
                MAX(CASE WHEN kind = 'payment' THEN date END) AS last_payment
           FROM unit_transactions WHERE building_id = ? GROUP BY unit_id");
    $s->execute([$bid]);
    $sums = [];
    foreach ($s->fetchAll() as $r) $sums[(int) $r['unit_id']] = $r;

    $s = db()->prepare("SELECT p.unit_id, p.full_name, p.mobile FROM persons p WHERE p.building_id = ? ORDER BY CASE p.role WHEN 'tenant' THEN 0 ELSE 1 END, p.id");
    $s->execute([$bid]);
    $contact = [];
    foreach ($s->fetchAll() as $p) $contact[(int) $p['unit_id']] ??= $p; // ساکن: اول مستأجر، بعد مالک

    $owner = ownerBalances($bid);
    $rows = [];
    foreach (buildingUnits($bid) as $u) {
        $id = (int) $u['id'];
        $debit  = (int) ($sums[$id]['debit'] ?? 0);
        $credit = (int) ($sums[$id]['credit'] ?? 0);
        $rows[] = [
            'id' => $id, 'title' => $u['title'], 'block' => $u['block'], 'occupancy' => $u['occupancy'],
            'monthly_charge' => chargeFor($u, $b),
            'charge_override' => $u['charge_override'] === null ? null : (int) $u['charge_override'],
            'debit' => $debit, 'credit' => $credit, 'balance' => $debit - $credit, 'owner_balance' => $owner[$id] ?? 0,
            'last_payment' => $sums[$id]['last_payment'] ?? null,
            'contact_name' => $contact[$id]['full_name'] ?? null,
            'contact_mobile' => $contact[$id]['mobile'] ?? null,
        ];
    }
    respond(['units' => $rows]);
}

// ================= دفتر حساب =================

function transactions_list(int $bid): void {
    requireBuilding($bid);
    $where = ['t.building_id = ?'];
    $args  = [$bid];
    $group = $_GET['group'] ?? '';
    if ($group === 'debit')  $where[] = "t.kind IN ('charge', 'debt', 'penalty')";
    if ($group === 'credit') $where[] = "t.kind IN ('payment', 'discount')";
    if (in_array($_GET['kind'] ?? '', [...DEBIT_KINDS, ...CREDIT_KINDS], true)) { $where[] = 't.kind = ?'; $args[] = $_GET['kind']; }
    if ($unit = optInt($_GET['unit_id'] ?? null, 1, PHP_INT_MAX)) { $where[] = 't.unit_id = ?'; $args[] = $unit; }
    if ($period = jalaliPeriod($_GET['period'] ?? '')) { $where[] = 't.period = ?'; $args[] = $period; }
    if ($from = isoDate($_GET['from'] ?? '')) { $where[] = 't.date >= ?'; $args[] = $from; }
    if ($to = isoDate($_GET['to'] ?? '')) { $where[] = 't.date <= ?'; $args[] = $to; }

    $stmt = db()->prepare('SELECT t.*, u.title AS unit_title, u.block AS unit_block
                             FROM unit_transactions t JOIN units u ON u.id = t.unit_id
                            WHERE ' . implode(' AND ', $where) . ' ORDER BY t.date DESC, t.id DESC LIMIT 1000');
    $stmt->execute($args);
    respond(['transactions' => array_map('castTx', $stmt->fetchAll())]);
}

function unit_ledger(int $unitId, int $status = 200): void {
    $unit = loadUnit($unitId);
    $b    = loadBuilding((int) $unit['building_id']);
    $stmt = db()->prepare('SELECT * FROM unit_transactions WHERE unit_id = ? ORDER BY date, id');
    $stmt->execute([$unitId]);
    $running = $owner = 0;
    $rows = [];
    foreach ($stmt->fetchAll() as $t) {
        $t = castTx($t);
        $signed = in_array($t['kind'], DEBIT_KINDS, true) ? $t['amount'] : -$t['amount'];
        $running += $signed;
        if ($t['payer'] === 'owner') $owner += $signed;
        $t['balance'] = $running;
        $rows[] = $t;
    }
    respond([
        'transactions'   => array_reverse($rows), // جدیدترین اول
        'balance'        => $running,
        'owner_balance'  => $owner,
        'monthly_charge' => chargeFor($unit, $b),
    ], $status);
}

function transactions_create(int $unitId): void {
    $unit = loadUnit($unitId, 'write');
    $b    = body();
    $kind = oneOf($b['kind'] ?? '', ['payment', 'debt', 'discount'], '');
    if ($kind === '') fail('INVALID_KIND');
    $amount = money($b['amount'] ?? '');
    if (!$amount) fail('INVALID_AMOUNT');
    $date = isoDate($b['date'] ?? '') ?? fail('INVALID_DATE');

    $defaultTitle = ['payment' => 'پرداخت', 'debt' => 'بدهی', 'discount' => 'تخفیف'][$kind];
    insertTx([
        'building_id' => (int) $unit['building_id'], 'unit_id' => $unitId, 'kind' => $kind, 'amount' => $amount,
        'title'  => cleanStr($b['title'] ?? '', 150) ?: $defaultTitle,
        'date'   => $date,
        'method' => $kind === 'payment' ? oneOf($b['method'] ?? '', PAY_METHODS, 'transfer') : '',
        'ref_no' => toEnDigits(cleanStr($b['ref_no'] ?? '', 40)),
        'notes'  => cleanStr($b['notes'] ?? '', 500),
        'payer'  => payerInput($b['payer'] ?? ''),
    ]);
    audit((int) $unit['building_id'], "tx.$kind", KIND_LABELS[$kind] . ' ' . faMoney($amount) . ' برای ' . unitName($unit), 'unit', $unitId);
    unit_ledger($unitId, 201);
}

function transactions_delete(int $txId): void {
    $stmt = db()->prepare('SELECT * FROM unit_transactions WHERE id = ?');
    $stmt->execute([$txId]);
    $t = $stmt->fetch();
    if (!$t) fail('NOT_FOUND', 404);
    requireBuilding((int) $t['building_id'], 'write');
    // سهمِ یک هزینه‌ی تقسیم‌شده فقط با حذف خودِ هزینه حذف می‌شود (وگرنه جمع تقسیم با هزینه نمی‌خواند).
    if ($t['fund_entry_id'] !== null) fail('LINKED_TO_EXPENSE', 409);
    $db = db();
    $db->beginTransaction();
    // پرداختی که از «اعلام واریز» ساکن آمده: اعلام به صف بررسی برمی‌گردد تا وضعیتش برای ساکن درست بماند.
    $db->prepare("UPDATE payment_claims SET status = 'pending', tx_id = NULL, review_note = '', reviewed_by = NULL, reviewed_at = NULL WHERE tx_id = ?")->execute([$txId]);
    $db->prepare('DELETE FROM unit_transactions WHERE id = ?')->execute([$txId]);
    audit((int) $t['building_id'], 'tx.delete', 'حذف ' . KIND_LABELS[$t['kind']] . ' ' . faMoney((int) $t['amount']) . " «{$t['title']}» از " . unitNameById((int) $t['unit_id']), 'unit', (int) $t['unit_id']);
    $db->commit();
    unit_ledger((int) $t['unit_id']);
}

/** بدهی یک‌جا برای چند واحد: مبلغ ثابت برای هر واحد، یا تقسیمِ یک مبلغ کل. */
function debts_bulk(int $bid): void {
    requireBuilding($bid, 'write');
    $b      = body();
    $title  = cleanStr($b['title'] ?? '', 150);
    if (mb_strlen($title) < 2) fail('INVALID_TITLE');
    $amount = money($b['amount'] ?? '');
    if (!$amount) fail('INVALID_AMOUNT');
    $date   = isoDate($b['date'] ?? '') ?? fail('INVALID_DATE');
    $mode   = oneOf($b['mode'] ?? '', ['each', 'split'], 'each');
    $method = oneOf($b['method'] ?? '', ALLOCATIONS, 'equal');

    $units = buildingUnits($bid);
    if (is_array($b['unit_ids'] ?? null) && $b['unit_ids']) {
        $ids   = array_flip(array_map('intval', $b['unit_ids']));
        $units = array_values(array_filter($units, fn($u) => isset($ids[(int) $u['id']])));
    }
    if (!$units) fail('NO_UNITS');

    $shares = $mode === 'split'
        ? allocate($amount, $units, $method)
        : array_fill_keys(array_map(fn($u) => (int) $u['id'], $units), $amount);

    $db = db();
    $db->beginTransaction();
    foreach ($shares as $unitId => $share) {
        insertTx(['building_id' => $bid, 'unit_id' => $unitId, 'kind' => 'debt', 'amount' => $share, 'title' => $title, 'date' => $date, 'payer' => payerInput($b['payer'] ?? '')]);
    }
    audit($bid, 'debt.bulk', "بدهی «{$title}» برای " . faDigits(count($shares)) . ' واحد، جمع ' . faMoney(array_sum($shares)));
    $db->commit();
    respond(['created' => count($shares), 'total' => array_sum($shares)], 201);
}

// ================= شارژ ماهانه =================

function chargeRows(int $bid, array $b, bool $withDiscount = true): array {
    $balances = unitBalances($bid);
    $pct = (float) $b['good_payer_percent'];
    $rows = [];
    foreach (buildingUnits($bid) as $u) {
        $amount  = chargeFor($u, $b);
        $before  = $balances[(int) $u['id']] ?? 0;
        // خوش‌حسابی: واحدی که پیش از این شارژ بدهی ندارد، تخفیف می‌گیرد.
        $discount = ($withDiscount && $pct > 0 && $amount > 0 && $before <= 0) ? (int) round($amount * $pct / 100) : 0;
        $rows[] = [
            'unit_id' => (int) $u['id'], 'title' => $u['title'], 'block' => $u['block'],
            'amount' => $amount, 'discount' => $discount, 'balance_before' => $before,
        ];
    }
    return $rows;
}

function periodIssued(int $bid, string $period): bool {
    $stmt = db()->prepare("SELECT 1 FROM unit_transactions WHERE building_id = ? AND period = ? AND kind = 'charge' LIMIT 1");
    $stmt->execute([$bid, $period]);
    return (bool) $stmt->fetchColumn();
}

function charges_preview(int $bid): void {
    requireBuilding($bid);
    $period = jalaliPeriod(body()['period'] ?? '') ?? fail('INVALID_PERIOD');
    $b    = loadBuilding($bid);
    $rows = chargeRows($bid, $b);
    respond([
        'period' => $period,
        'already_issued' => periodIssued($bid, $period),
        'rows' => $rows,
        'total' => array_sum(array_column($rows, 'amount')),
        'total_discount' => array_sum(array_column($rows, 'discount')),
    ]);
}

function charges_issue(int $bid): void {
    requireBuilding($bid, 'write');
    $body   = body();
    $period = jalaliPeriod($body['period'] ?? '') ?? fail('INVALID_PERIOD');
    $due    = isoDate($body['due_date'] ?? '') ?? fail('INVALID_DATE');
    $date   = isoDate($body['date'] ?? '') ?? today();
    $title  = cleanStr($body['title'] ?? '', 150) ?: "شارژ " . faPeriod($period);

    $b  = loadBuilding($bid);
    $db = db();
    $db->beginTransaction();
    if (periodIssued($bid, $period)) {
        $db->rollBack();
        fail('PERIOD_ISSUED', 409);
    }
    $rows = chargeRows($bid, $b);
    $count = $total = 0;
    foreach ($rows as $r) {
        if ($r['amount'] <= 0) continue;
        $base = ['building_id' => $bid, 'unit_id' => $r['unit_id'], 'period' => $period, 'due_date' => $due, 'date' => $date];
        insertTx($base + ['kind' => 'charge', 'amount' => $r['amount'], 'title' => $title]);
        if ($r['discount'] > 0) insertTx($base + ['kind' => 'discount', 'amount' => $r['discount'], 'title' => "تخفیف خوش‌حسابی " . faPeriod($period)]);
        $count++;
        $total += $r['amount'];
    }
    if (!$count) {
        $db->rollBack();
        fail('NO_CHARGE_AMOUNT');
    }
    audit($bid, 'charge.issue', 'صدور شارژ ' . faPeriod($period) . ' برای ' . faDigits($count) . ' واحد، جمع ' . faMoney($total));
    $db->commit();
    $sms = !empty($body['notify']) ? smsCharge($bid, $b, $period, $due) : null;
    respond(['created' => $count, 'total' => $total, 'sms' => $sms], 201);
}

/** پیامک اعلام شارژ به پرداخت‌کننده‌ی هر واحد: مبلغ این دوره، مانده‌ی کل و مهلت. */
function smsCharge(int $bid, array $b, string $period, string $due): array {
    $stmt = db()->prepare("SELECT unit_id, SUM(CASE WHEN kind = 'charge' THEN amount ELSE -amount END) AS net FROM unit_transactions WHERE building_id = ? AND period = ? AND kind IN ('charge', 'discount') GROUP BY unit_id");
    $stmt->execute([$bid, $period]);
    $net = array_map('intval', $stmt->fetchAll(PDO::FETCH_KEY_PAIR));
    $balances = unitBalances($bid);
    $units = array_column(buildingUnits($bid), null, 'id');
    $messages = [];
    foreach (unitContacts($bid) as $unitId => $people) {
        if (!isset($net[$unitId])) continue;
        foreach ($people as $p) {
            $messages[] = [$p['mobile'], "{$p['full_name']} گرامی\nشارژ " . faPeriod($period) . ' ' . unitName($units[$unitId]) . ': ' . faMoney($net[$unitId])
                . "\nمانده‌ی قابل پرداخت: " . faMoney(max(0, $balances[$unitId] ?? 0)) . "\nمهلت پرداخت: " . faDate($due) . smsFooter($b)];
        }
    }
    return smsNotify($bid, 'charge', $messages);
}

function charges_periods(int $bid): void {
    requireBuilding($bid);
    $stmt = db()->prepare("SELECT period,
                SUM(CASE WHEN kind = 'charge' THEN 1 ELSE 0 END) AS units,
                SUM(CASE WHEN kind = 'charge' THEN amount ELSE 0 END) AS total,
                SUM(CASE WHEN kind = 'discount' THEN amount ELSE 0 END) AS discount,
                SUM(CASE WHEN kind = 'penalty' THEN amount ELSE 0 END) AS penalty,
                MIN(CASE WHEN kind = 'charge' THEN due_date END) AS due_date,
                MIN(CASE WHEN kind = 'charge' THEN date END) AS date
           FROM unit_transactions WHERE building_id = ? AND period <> '' GROUP BY period ORDER BY period DESC");
    $stmt->execute([$bid]);
    $rows = array_map(fn($r) => [
        'period' => $r['period'], 'units' => (int) $r['units'], 'total' => (int) $r['total'],
        'discount' => (int) $r['discount'], 'penalty' => (int) $r['penalty'],
        'due_date' => $r['due_date'], 'date' => $r['date'],
    ], $stmt->fetchAll());
    respond(['periods' => array_values(array_filter($rows, fn($r) => $r['units'] > 0))]);
}

function charges_revoke(int $bid, string $slug): void {
    requireBuilding($bid, 'write');
    $period = jalaliPeriod($slug) ?? fail('INVALID_PERIOD');
    $stmt = db()->prepare("DELETE FROM unit_transactions WHERE building_id = ? AND period = ? AND kind IN ('charge', 'discount', 'penalty')");
    $stmt->execute([$bid, $period]);
    audit($bid, 'charge.revoke', 'ابطال شارژ ' . faPeriod($period) . ' (' . faDigits($stmt->rowCount()) . ' ردیف)');
    respond(['deleted' => $stmt->rowCount()]);
}

/** جریمه‌ی دیرکرد یک دوره: فقط بعد از سررسید + مهلت، یک‌بار برای هر واحدِ بدهکار. */
function charges_penalty(int $bid, string $slug): void {
    requireBuilding($bid, 'write');
    $period = jalaliPeriod($slug) ?? fail('INVALID_PERIOD');
    $b   = loadBuilding($bid);
    $pct = (float) $b['late_fee_percent'];
    if ($pct <= 0) fail('NO_LATE_FEE');

    $db = db();
    $stmt = $db->prepare("SELECT unit_id, amount, due_date FROM unit_transactions WHERE building_id = ? AND period = ? AND kind = 'charge'");
    $stmt->execute([$bid, $period]);
    $charges = $stmt->fetchAll();
    if (!$charges) fail('NOT_FOUND', 404);

    $applicableFrom = date('Y-m-d', strtotime($charges[0]['due_date'] . ' +' . (int) $b['late_fee_grace_days'] . ' days'));
    if (today() < $applicableFrom) fail('NOT_DUE_YET', 409, ['from' => $applicableFrom]);

    $stmt = $db->prepare("SELECT unit_id FROM unit_transactions WHERE building_id = ? AND period = ? AND kind = 'penalty'");
    $stmt->execute([$bid, $period]);
    $already  = array_flip($stmt->fetchAll(PDO::FETCH_COLUMN));
    $balances = unitBalances($bid);

    $db->beginTransaction();
    $count = $total = 0;
    foreach ($charges as $c) {
        $unitId = (int) $c['unit_id'];
        $owed   = min($balances[$unitId] ?? 0, (int) $c['amount']);
        if (isset($already[$unitId]) || $owed <= 0) continue;
        $fee = (int) round($owed * $pct / 100);
        if ($fee <= 0) continue;
        insertTx(['building_id' => $bid, 'unit_id' => $unitId, 'kind' => 'penalty', 'amount' => $fee, 'title' => "جریمه‌ی دیرکرد " . faPeriod($period), 'period' => $period, 'date' => today()]);
        $count++;
        $total += $fee;
    }
    if ($count) audit($bid, 'charge.penalty', 'جریمه‌ی دیرکرد ' . faPeriod($period) . ' برای ' . faDigits($count) . ' واحد، جمع ' . faMoney($total));
    $db->commit();
    respond(['created' => $count, 'total' => $total]);
}

// ================= هزینه و درآمد =================

function fund_list(int $bid): void {
    requireBuilding($bid);
    $where = ['f.building_id = ?'];
    $args  = [$bid];
    if (in_array($_GET['direction'] ?? '', ['in', 'out'], true)) { $where[] = 'f.direction = ?'; $args[] = $_GET['direction']; }
    if ($from = isoDate($_GET['from'] ?? '')) { $where[] = 'f.date >= ?'; $args[] = $from; }
    if ($to = isoDate($_GET['to'] ?? '')) { $where[] = 'f.date <= ?'; $args[] = $to; }

    $stmt = db()->prepare('SELECT f.*, (SELECT COUNT(*) FROM unit_transactions t WHERE t.fund_entry_id = f.id) AS allocated_units
                             FROM fund_entries f WHERE ' . implode(' AND ', $where) . ' ORDER BY f.date DESC, f.id DESC LIMIT 1000');
    $stmt->execute($args);
    respond(['entries' => array_map(fn($e) => ['id' => (int) $e['id'], 'amount' => (int) $e['amount'], 'allocated_units' => (int) $e['allocated_units']] + $e, $stmt->fetchAll())]);
}

function insertFundEntry(int $bid, string $direction, string $category, int $amount, string $date, string $title, string $notes = '', string $allocate = 'none'): int {
    db()->prepare('INSERT INTO fund_entries (building_id, direction, category, amount, date, title, notes, allocate, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
        ->execute([$bid, $direction, $category, $amount, $date, $title, $notes, $allocate, authUserId(), now()]);
    return (int) db()->lastInsertId();
}

function fund_create(int $bid): void {
    requireBuilding($bid, 'write');
    $b         = body();
    $direction = oneOf($b['direction'] ?? '', ['in', 'out'], '');
    if ($direction === '') fail('INVALID_DIRECTION');
    $category  = oneOf($b['category'] ?? '', $direction === 'out' ? OUT_CATEGORIES : IN_CATEGORIES, 'other');
    $amount    = money($b['amount'] ?? '');
    if (!$amount) fail('INVALID_AMOUNT');
    $date      = isoDate($b['date'] ?? '') ?? fail('INVALID_DATE');
    $allocate  = $direction === 'out' ? oneOf($b['allocate'] ?? '', ALLOCATIONS, 'none') : 'none';
    $title     = cleanStr($b['title'] ?? '', 150);

    $db = db();
    $db->beginTransaction();
    $entryId = insertFundEntry($bid, $direction, $category, $amount, $date, $title, cleanStr($b['notes'] ?? '', 500), $allocate);

    // تقسیمِ هزینه بین واحدها: برای هر واحد یک بدهیِ متصل به این هزینه ثبت می‌شود.
    $allocated = 0;
    if ($allocate !== 'none') {
        foreach (allocate($amount, buildingUnits($bid), $allocate) as $unitId => $share) {
            insertTx(['building_id' => $bid, 'unit_id' => $unitId, 'kind' => 'debt', 'amount' => $share,
                      'title' => $title ?: 'سهم هزینه', 'date' => $date, 'fund_entry_id' => $entryId, 'payer' => payerInput($b['payer'] ?? '')]);
            $allocated++;
        }
    }
    audit($bid, "fund.$direction", ($direction === 'out' ? 'هزینه' : 'درآمد') . ' ' . faMoney($amount) . ($title ? " «{$title}»" : '')
        . ($allocated ? ' — تقسیم بین ' . faDigits($allocated) . ' واحد' : ''), 'fund', $entryId);
    $db->commit();
    respond(['id' => $entryId, 'allocated_units' => $allocated], 201);
}

function fund_delete(int $entryId): void {
    $stmt = db()->prepare('SELECT * FROM fund_entries WHERE id = ?');
    $stmt->execute([$entryId]);
    $e = $stmt->fetch() ?: fail('NOT_FOUND', 404);
    $bid = (int) $e['building_id'];
    requireBuilding($bid, 'write');
    // بدهی‌های تقسیم‌شده‌ی این هزینه با ON DELETE CASCADE حذف می‌شوند.
    db()->prepare('DELETE FROM fund_entries WHERE id = ?')->execute([$entryId]);
    audit($bid, 'fund.delete', 'حذف ' . ($e['direction'] === 'out' ? 'هزینه' : 'درآمد') . ' ' . faMoney((int) $e['amount']) . ($e['title'] ? " «{$e['title']}»" : ''), 'fund', $entryId);
    respond(['ok' => true]);
}
