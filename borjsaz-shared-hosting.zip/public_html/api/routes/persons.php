<?php
// مالکان و مستأجرانِ هر واحد.

const PERSON_ROLES = ['owner', 'tenant'];

function personInput(array $b, array $current = []): array {
    $pick = fn(string $k, $default = '') => array_key_exists($k, $b) ? $b[$k] : ($current[$k] ?? $default);
    $name = cleanStr($pick('full_name'), 120);
    if (mb_strlen($name) < 2) fail('INVALID_NAME');

    $rawMobile = trim((string) ($pick('mobile') ?? ''));
    $mobile = $rawMobile === '' ? null : normalizeMobile($rawMobile);
    if ($rawMobile !== '' && !$mobile) fail('INVALID_MOBILE');

    return [
        'role'         => oneOf($pick('role'), PERSON_ROLES, 'owner'),
        'full_name'    => $name,
        'mobile'       => $mobile,
        'move_in_date' => toEnDigits(cleanStr($pick('move_in_date'), 10)),
        'notes'        => cleanStr($pick('notes'), 500),
    ];
}

function castPerson(array $p): array {
    foreach (['id', 'building_id', 'unit_id'] as $k) $p[$k] = (int) $p[$k];
    return $p;
}

function loadPerson(int $personId, string $need = 'read'): array {
    $stmt = db()->prepare('SELECT * FROM persons WHERE id = ?');
    $stmt->execute([$personId]);
    $p = $stmt->fetch();
    if (!$p) fail('NOT_FOUND', 404);
    requireBuilding((int) $p['building_id'], $need);
    return $p;
}

function persons_list(int $bid): void {
    requireBuilding($bid);
    $stmt = db()->prepare(
        'SELECT p.*, u.title AS unit_title, u.block AS unit_block
           FROM persons p JOIN units u ON u.id = p.unit_id
          WHERE p.building_id = ? ORDER BY u.block, u.id, p.role, p.id'
    );
    $stmt->execute([$bid]);
    respond(['persons' => array_map('castPerson', $stmt->fetchAll())]);
}

function persons_create(int $unitId): void {
    $unit = loadUnit($unitId, 'write');
    $in   = personInput(body());
    $db   = db();
    $db->prepare('INSERT INTO persons (building_id, unit_id, role, full_name, mobile, move_in_date, notes, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
       ->execute([$unit['building_id'], $unitId, ...array_values($in), now(), now()]);

    // ثبتِ اولین مستأجر یعنی واحد استیجاری است.
    if ($in['role'] === 'tenant' && $unit['occupancy'] !== 'tenant') {
        $db->prepare("UPDATE units SET occupancy = 'tenant', updated_at = ? WHERE id = ?")->execute([now(), $unitId]);
    }
    audit((int) $unit['building_id'], 'person.create', 'ثبت ' . ($in['role'] === 'tenant' ? 'مستأجر' : 'مالک') . " «{$in['full_name']}» برای " . unitName($unit), 'unit', $unitId);
    units_show($unitId);
}

function persons_update(int $personId): void {
    $p  = loadPerson($personId, 'write');
    $in = personInput(body(), $p);
    db()->prepare('UPDATE persons SET role = ?, full_name = ?, mobile = ?, move_in_date = ?, notes = ?, updated_at = ? WHERE id = ?')
        ->execute([...array_values($in), now(), $personId]);
    audit((int) $p['building_id'], 'person.update', "ویرایش «{$in['full_name']}» در " . unitNameById((int) $p['unit_id']), 'unit', (int) $p['unit_id']);
    units_show((int) $p['unit_id']);
}

function persons_delete(int $personId): void {
    $p = loadPerson($personId, 'write');
    db()->prepare('DELETE FROM persons WHERE id = ?')->execute([$personId]);
    audit((int) $p['building_id'], 'person.delete', "حذف «{$p['full_name']}» از " . unitNameById((int) $p['unit_id']), 'unit', (int) $p['unit_id']);
    units_show((int) $p['unit_id']);
}
