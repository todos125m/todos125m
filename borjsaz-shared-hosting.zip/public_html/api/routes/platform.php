<?php
// پنل سازنده (تیم پشتیبانی برج‌ساز): سلامت سیستم، لاگ خطاها، پشتیبان‌ها و فهرست مشتری‌ها.
// دسترسی فقط برای موبایل‌های PLATFORM_ADMINS در config.php؛ برای بقیه 404 (وجود پنل لو نمی‌رود).

function isPlatformAdmin(?string $mobile): bool {
    return $mobile && defined('PLATFORM_ADMINS') && in_array($mobile, PLATFORM_ADMINS, true);
}

function requirePlatform(): void {
    $s = db()->prepare('SELECT mobile FROM users WHERE id = ?');
    $s->execute([authUserId()]);
    if (!isPlatformAdmin($s->fetchColumn() ?: null)) fail('NOT_FOUND', 404);
}

/**
 * ثبت خطا در error_log. هرگز خودش خطا نمی‌دهد: اگر دیتابیس در دسترس نباشد فقط در لاگ PHP می‌ماند.
 */
function logError(string $source, string $message, string $detail = '', ?int $userId = null, ?string $page = null): void {
    error_log("borjsaz $source: $message");
    try {
        db()->prepare('INSERT INTO error_log (source, message, detail, method, path, user_id, user_agent, ip, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
            ->execute([
                $source, mb_substr($message, 0, 1000), mb_substr($detail, 0, 8000),
                // خطای مرورگر: «صفحه‌ای که خطا در آن رخ داد»، نه آدرس همین endpoint
                $page === null ? mb_substr($_SERVER['REQUEST_METHOD'] ?? '', 0, 10) : '',
                mb_substr($page ?? (parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: ''), 0, 300),
                $userId, mb_substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 300), clientIp(), now(),
            ]);
    } catch (Throwable $e) {
        error_log('borjsaz error_log insert failed: ' . $e->getMessage());
    }
}

/** شناسه‌ی کاربر اگر توکن معتبر همراه درخواست باشد، بدون اینکه درخواست را رد کند. */
function optionalUserId(): ?int {
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
    if (!preg_match('/^Bearer\s+(\S+)$/', $header, $m)) return null;
    $claims = jwt_decode($m[1]);
    return $claims ? (int) $claims['sub'] : null;
}

/** خطاهای مرورگر کاربران (مثلاً مشکل خاص سافاری) — بدون نیاز به ورود، با محدودیت تعداد. */
function client_error(): void {
    if (!rateLimit('clienterr:' . clientIp(), 30, 3600)) respond(['ok' => true]);
    $b = body();
    $message = cleanStr($b['message'] ?? '', 1000);
    if ($message === '') respond(['ok' => true]);
    logError('client', $message, mb_substr((string) ($b['stack'] ?? ''), 0, 6000), optionalUserId(), cleanStr($b['url'] ?? '', 300));
    respond(['ok' => true]);
}

// ================= وضعیت =================

function platform_overview(): void {
    requirePlatform();
    $db = db();
    $one = function (string $sql, array $a = []) use ($db) {
        $s = $db->prepare($sql);
        $s->execute($a);
        return $s->fetchColumn();
    };
    $since30 = date('Y-m-d H:i:s', strtotime('-30 days'));
    $since1 = date('Y-m-d H:i:s', strtotime('-1 day'));

    $dbVersion = DB_DRIVER === 'mysql' ? $one('SELECT VERSION()') : 'SQLite ' . $one('SELECT sqlite_version()');
    $migrations = $db->query("SELECT name, applied_at FROM migrations WHERE name NOT LIKE '%#%' ORDER BY name")->fetchAll();
    $backups = listBackups();
    $dataDir = __DIR__ . '/../data';
    $diskFree = @disk_free_space($dataDir);

    respond([
        'system' => [
            'env' => APP_ENV,
            'php' => PHP_VERSION,
            'db' => $dbVersion,
            'db_size' => DB_DRIVER === 'sqlite' ? @filesize(DB_SQLITE_PATH) : (int) $one('SELECT SUM(data_length + index_length) FROM information_schema.tables WHERE table_schema = DATABASE()'),
            'disk_free' => $diskFree === false ? null : (int) $diskFree,
            'timezone' => date_default_timezone_get(),
            'server_time' => now(),
            'migrations' => $migrations,
            'data_writable' => is_writable($dataDir),
            'sms_key' => defined('SMS_IR_API_KEY') && SMS_IR_API_KEY !== '' && !str_starts_with(SMS_IR_API_KEY, 'your_'),
            'sms_line' => defined('SMS_IR_LINE_NUMBER') && SMS_IR_LINE_NUMBER !== '',
            'app_url' => defined('APP_URL') ? APP_URL : '',
        ],
        'counts' => [
            'buildings' => (int) $one('SELECT COUNT(*) FROM buildings'),
            'units' => (int) $one('SELECT COUNT(*) FROM units'),
            'users' => (int) $one('SELECT COUNT(*) FROM users'),
            'active_users_30d' => (int) $one('SELECT COUNT(*) FROM users WHERE last_seen_at >= ?', [$since30]),
            'active_users_1d' => (int) $one('SELECT COUNT(*) FROM users WHERE last_seen_at >= ?', [$since1]),
            'errors_1d' => (int) $one('SELECT COUNT(*) FROM error_log WHERE created_at >= ?', [$since1]),
            'errors_30d' => (int) $one('SELECT COUNT(*) FROM error_log WHERE created_at >= ?', [$since30]),
            'sms_30d' => (int) $one('SELECT COUNT(*) FROM sms_log WHERE created_at >= ?', [$since30]),
            'sms_failed_30d' => (int) $one("SELECT COUNT(*) FROM sms_log WHERE status = 'failed' AND created_at >= ?", [$since30]),
            'logins_1d' => (int) $one('SELECT COUNT(*) FROM otp_codes WHERE used = 1 AND created_at >= ?', [$since1]),
        ],
        'last_backup' => $backups[0] ?? null,
    ]);
}

// ================= خطاها =================

function platform_errors(): void {
    requirePlatform();
    $where = ['1 = 1'];
    $args = [];
    if (in_array($_GET['source'] ?? '', ['server', 'client'], true)) { $where[] = 'e.source = ?'; $args[] = $_GET['source']; }
    if ($before = optInt($_GET['before'] ?? null, 1, PHP_INT_MAX)) { $where[] = 'e.id < ?'; $args[] = $before; }
    $stmt = db()->prepare('SELECT e.*, u.mobile AS user_mobile, u.full_name AS user_name FROM error_log e LEFT JOIN users u ON u.id = e.user_id
                            WHERE ' . implode(' AND ', $where) . ' ORDER BY e.id DESC LIMIT 101');
    $stmt->execute($args);
    $rows = array_map(fn($r) => ['id' => (int) $r['id'], 'user_id' => $r['user_id'] === null ? null : (int) $r['user_id']] + $r, $stmt->fetchAll());
    respond(['errors' => array_slice($rows, 0, 100), 'has_more' => count($rows) > 100]);
}

function platform_errors_clear(): void {
    requirePlatform();
    $days = optInt(body()['older_than_days'] ?? 0, 0, 3650) ?? 0;
    $stmt = db()->prepare('DELETE FROM error_log WHERE created_at < ?');
    $stmt->execute([$days ? date('Y-m-d H:i:s', strtotime("-$days days")) : '9999-12-31']);
    respond(['deleted' => $stmt->rowCount()]);
}

// ================= پشتیبان‌ها =================

function platform_backups(): void {
    requirePlatform();
    respond(['backups' => listBackups(), 'keep' => BACKUP_KEEP]);
}

function platform_backup_create(): void {
    requirePlatform();
    if (!rateLimit('backup:' . authUserId(), 10, 3600)) fail('TOO_MANY_REQUESTS', 429);
    $r = runBackup(db());
    respond(['backup' => $r, 'backups' => listBackups()], 201);
}

function platform_backup_download(string $name): void {
    requirePlatform();
    if (!preg_match('/^borjsaz-\d{8}-\d{4,6}\.sql\.gz$/', $name)) fail('NOT_FOUND', 404);
    $path = backupDir() . "/$name";
    if (!is_file($path)) fail('NOT_FOUND', 404);
    header('Content-Type: application/gzip');
    header('Content-Disposition: attachment; filename="' . $name . '"');
    header('Content-Length: ' . filesize($path));
    header('Cache-Control: no-store');
    readfile($path);
    exit;
}

// ================= مشتری‌ها =================

function platform_buildings(): void {
    requirePlatform();
    $since30 = date('Y-m-d H:i:s', strtotime('-30 days'));
    $stmt = db()->prepare("SELECT b.id, b.name, b.city, b.created_at,
            (SELECT COUNT(*) FROM units u WHERE u.building_id = b.id) AS units,
            (SELECT COUNT(*) FROM persons p WHERE p.building_id = b.id) AS persons,
            (SELECT COUNT(*) FROM persons p WHERE p.building_id = b.id AND p.mobile IN (SELECT mobile FROM users)) AS persons_joined,
            (SELECT COUNT(*) FROM building_members m WHERE m.building_id = b.id) AS members,
            (SELECT MAX(created_at) FROM audit_log a WHERE a.building_id = b.id) AS last_activity,
            (SELECT COUNT(*) FROM sms_log s WHERE s.building_id = b.id AND s.created_at >= ?) AS sms_30d,
            (SELECT COUNT(*) FROM unit_transactions t WHERE t.building_id = b.id AND t.kind = 'payment' AND t.created_at >= ?) AS payments_30d,
            (SELECT us.mobile FROM building_members m JOIN users us ON us.id = m.user_id WHERE m.building_id = b.id AND m.role = 'manager' ORDER BY m.id LIMIT 1) AS manager_mobile,
            (SELECT us.full_name FROM building_members m JOIN users us ON us.id = m.user_id WHERE m.building_id = b.id AND m.role = 'manager' ORDER BY m.id LIMIT 1) AS manager_name
        FROM buildings b ORDER BY b.id DESC");
    $stmt->execute([$since30, $since30]);
    $ints = ['id', 'units', 'persons', 'persons_joined', 'members', 'sms_30d', 'payments_30d'];
    respond(['buildings' => array_map(function ($r) use ($ints) {
        foreach ($ints as $k) $r[$k] = (int) $r[$k];
        return $r;
    }, $stmt->fetchAll())]);
}
