<?php
// گزارش‌گیری برای حسابدار و هیئت‌مدیره: بازه‌ی تاریخ دلخواه و فیلتر؛ چاپ/PDF و اکسل در فرانت.
//   expenses  هزینه‌ها (دسته، پرداخت‌شونده) با جمع به تفکیک دسته و پرداخت‌شونده
//   income    دریافتی از واحدها + درآمدهای دیگر صندوق
//   unit      گردش حساب یک واحد: مانده‌ی اول دوره، ردیف‌ها با مانده‌ی جاری، مانده‌ی پایان
//   balances  وضعیت همه‌ی حساب‌ها: اول دوره، بدهکار، بستانکار، پایان، سهم مالک
//   cashbook  دفتر صندوق: هر ورود و خروج پول با موجودی جاری (همان فرمول موجودی صندوق داشبورد)
// همه‌ی اعضای تیم مدیریت (حتی هیئت‌مدیره‌ی فقط‌خواندنی) گزارش می‌بینند.

const REPORT_TYPES = ['expenses', 'income', 'unit', 'balances', 'cashbook'];

function reportRange(): array {
    $from = isoDate($_GET['from'] ?? '') ?? '1900-01-01';
    $to   = isoDate($_GET['to'] ?? '') ?? '2999-12-31';
    if ($from > $to) fail('INVALID_DATE');
    return [$from, $to];
}

function report_run(int $bid, string $type): void {
    requireBuilding($bid);
    if (!in_array($type, REPORT_TYPES, true)) fail('NOT_FOUND', 404);
    [$from, $to] = reportRange();
    $data = ("report_$type")($bid, $from, $to);
    respond(['type' => $type, 'from' => $from, 'to' => $to, 'building' => loadBuilding($bid)['name']] + $data);
}

function unitNames(int $bid): array {
    $names = [];
    foreach (buildingUnits($bid) as $u) $names[(int) $u['id']] = unitName($u);
    return $names;
}

function report_expenses(int $bid, string $from, string $to): array {
    $where = ["f.building_id = ?", "f.direction = 'out'", 'f.date BETWEEN ? AND ?'];
    $args = [$bid, $from, $to];
    if ($cat = cleanStr($_GET['category'] ?? '', 20)) { $where[] = 'f.category = ?'; $args[] = $cat; }
    if ($staff = optInt($_GET['staff_id'] ?? null, 1, PHP_INT_MAX)) { $where[] = 'f.staff_id = ?'; $args[] = $staff; }
    if (($payee = cleanStr($_GET['payee'] ?? '', 120)) !== '') { $where[] = 'f.payee LIKE ?'; $args[] = "%$payee%"; }
    $s = db()->prepare('SELECT f.id, f.date, f.category, f.title, f.payee, f.method, f.ref_no, f.amount, f.attachment, f.notes, f.allocate
                          FROM fund_entries f WHERE ' . implode(' AND ', $where) . ' ORDER BY f.date, f.id');
    $s->execute($args);
    $rows = [];
    $byCat = $byPayee = [];
    $total = 0;
    foreach ($s->fetchAll() as $r) {
        $r['id'] = (int) $r['id'];
        $r['amount'] = (int) $r['amount'];
        $r['attachment'] = $r['attachment'] !== '';
        $rows[] = $r;
        $total += $r['amount'];
        $byCat[$r['category']] = ($byCat[$r['category']] ?? 0) + $r['amount'];
        $p = $r['payee'] !== '' ? $r['payee'] : '—';
        $byPayee[$p] = ($byPayee[$p] ?? 0) + $r['amount'];
    }
    arsort($byCat);
    arsort($byPayee);
    $pairs = fn($a, $k) => array_map(fn($name, $sum) => [$k => (string) $name, 'total' => $sum, 'percent' => $total ? round($sum * 100 / $total, 1) : 0], array_keys($a), $a);
    return ['rows' => $rows, 'total' => $total, 'by_category' => $pairs($byCat, 'category'), 'by_payee' => $pairs($byPayee, 'payee')];
}

function report_income(int $bid, string $from, string $to): array {
    $names = unitNames($bid);
    $where = ["t.building_id = ?", "t.kind = 'payment'", 't.date BETWEEN ? AND ?'];
    $args = [$bid, $from, $to];
    if ($unit = optInt($_GET['unit_id'] ?? null, 1, PHP_INT_MAX)) { $where[] = 't.unit_id = ?'; $args[] = $unit; }
    if ($method = cleanStr($_GET['method'] ?? '', 10)) { $where[] = 't.method = ?'; $args[] = $method; }
    $s = db()->prepare('SELECT t.id, t.date, t.unit_id, t.title, t.method, t.ref_no, t.amount, t.payer FROM unit_transactions t WHERE ' . implode(' AND ', $where) . ' ORDER BY t.date, t.id');
    $s->execute($args);
    $rows = [];
    $byMethod = [];
    $fromUnits = 0;
    foreach ($s->fetchAll() as $t) {
        $amount = (int) $t['amount'];
        $rows[] = ['source' => 'unit', 'date' => $t['date'], 'who' => $names[(int) $t['unit_id']] ?? '', 'title' => $t['title'], 'method' => $t['method'],
                   'ref_no' => $t['ref_no'], 'amount' => $amount, 'payer' => $t['payer'] ?? 'unit'];
        $fromUnits += $amount;
        $byMethod[$t['method'] ?: '—'] = ($byMethod[$t['method'] ?: '—'] ?? 0) + $amount;
    }
    $other = 0;
    if (!$unit) {
        $s = db()->prepare("SELECT date, category, title, payee, method, ref_no, amount FROM fund_entries WHERE building_id = ? AND direction = 'in' AND date BETWEEN ? AND ?"
            . ($method ? ' AND method = ?' : '') . ' ORDER BY date, id');
        $s->execute($method ? [$bid, $from, $to, $method] : [$bid, $from, $to]);
        foreach ($s->fetchAll() as $f) {
            $rows[] = ['source' => 'fund', 'date' => $f['date'], 'who' => $f['payee'], 'title' => $f['title'], 'category' => $f['category'], 'method' => $f['method'],
                       'ref_no' => $f['ref_no'], 'amount' => (int) $f['amount']];
            $other += (int) $f['amount'];
        }
        usort($rows, fn($a, $b) => strcmp($a['date'], $b['date']));
    }
    arsort($byMethod);
    return ['rows' => $rows, 'total' => $fromUnits + $other, 'from_units' => $fromUnits, 'other_income' => $other,
            'by_method' => array_map(fn($m, $sum) => ['method' => (string) $m, 'total' => $sum], array_keys($byMethod), $byMethod)];
}

/** گردش حساب یک واحد در بازه؛ مانده‌ی اول دوره = جمع همه‌ی ردیف‌های قبل از «از». */
function report_unit(int $bid, string $from, string $to): array {
    $unitId = optInt($_GET['unit_id'] ?? null, 1, PHP_INT_MAX) ?? fail('INVALID_UNIT');
    $s = db()->prepare('SELECT * FROM units WHERE id = ? AND building_id = ?');
    $s->execute([$unitId, $bid]);
    $unit = $s->fetch() ?: fail('INVALID_UNIT');
    $s = db()->prepare('SELECT * FROM unit_transactions WHERE unit_id = ? ORDER BY date, id');
    $s->execute([$unitId]);
    $opening = $openingOwner = 0;
    $running = $owner = $debit = $credit = 0;
    $rows = [];
    foreach ($s->fetchAll() as $t) {
        $t = castTx($t);
        $signed = in_array($t['kind'], DEBIT_KINDS, true) ? $t['amount'] : -$t['amount'];
        if ($t['date'] < $from) {
            $opening += $signed;
            if ($t['payer'] === 'owner') $openingOwner += $signed;
            continue;
        }
        if ($t['date'] > $to) break;
        if (!$rows) { $running = $opening; $owner = $openingOwner; }
        $running += $signed;
        if ($t['payer'] === 'owner') $owner += $signed;
        if ($signed > 0) $debit += $signed; else $credit -= $signed;
        $rows[] = ['date' => $t['date'], 'kind' => $t['kind'], 'title' => $t['title'], 'method' => $t['method'], 'ref_no' => $t['ref_no'],
                   'payer' => $t['payer'], 'debit' => max($signed, 0), 'credit' => max(-$signed, 0), 'balance' => $running];
    }
    if (!$rows) { $running = $opening; $owner = $openingOwner; }
    $p = db()->prepare("SELECT role, full_name, mobile FROM persons WHERE unit_id = ? ORDER BY CASE role WHEN 'owner' THEN 0 ELSE 1 END, id");
    $p->execute([$unitId]);
    return ['unit' => ['id' => $unitId, 'name' => unitName($unit)], 'people' => $p->fetchAll(),
            'opening' => $opening, 'debit' => $debit, 'credit' => $credit, 'closing' => $running, 'owner_balance' => $owner, 'rows' => $rows];
}

/** وضعیت همه‌ی حساب‌ها در بازه (مثبت = بدهکار، منفی = بستانکار). */
function report_balances(int $bid, string $from, string $to): array {
    $s = db()->prepare('SELECT unit_id,
            SUM(CASE WHEN date < ? THEN ' . SIGNED_AMOUNT . ' ELSE 0 END) AS opening,
            SUM(CASE WHEN date BETWEEN ? AND ? AND kind IN (\'charge\', \'debt\', \'penalty\') THEN amount ELSE 0 END) AS debit,
            SUM(CASE WHEN date BETWEEN ? AND ? AND kind IN (\'payment\', \'discount\') THEN amount ELSE 0 END) AS credit,
            SUM(CASE WHEN date <= ? AND payer = \'owner\' THEN ' . SIGNED_AMOUNT . ' ELSE 0 END) AS owner_balance
          FROM unit_transactions WHERE building_id = ? GROUP BY unit_id');
    $s->execute([$from, $from, $to, $from, $to, $to, $bid]);
    $agg = [];
    foreach ($s->fetchAll() as $r) $agg[(int) $r['unit_id']] = $r;
    $p = db()->prepare("SELECT unit_id, role, full_name FROM persons WHERE building_id = ? ORDER BY CASE role WHEN 'owner' THEN 0 ELSE 1 END, id");
    $p->execute([$bid]);
    $people = [];
    foreach ($p->fetchAll() as $x) $people[(int) $x['unit_id']][] = $x['full_name'];
    $rows = [];
    $tot = ['opening' => 0, 'debit' => 0, 'credit' => 0, 'closing' => 0, 'owner_balance' => 0];
    foreach (buildingUnits($bid) as $u) {
        $a = $agg[(int) $u['id']] ?? ['opening' => 0, 'debit' => 0, 'credit' => 0, 'owner_balance' => 0];
        $r = ['unit_id' => (int) $u['id'], 'unit' => unitName($u), 'people' => implode('، ', $people[(int) $u['id']] ?? []),
              'opening' => (int) $a['opening'], 'debit' => (int) $a['debit'], 'credit' => (int) $a['credit'], 'owner_balance' => (int) $a['owner_balance']];
        $r['closing'] = $r['opening'] + $r['debit'] - $r['credit'];
        foreach ($tot as $k => $_) $tot[$k] += $r[$k];
        $rows[] = $r;
    }
    return ['rows' => $rows, 'totals' => $tot, 'debtors' => count(array_filter($rows, fn($r) => $r['closing'] > 0))];
}

/** دفتر صندوق: موجودی اولیه + دریافتی از واحدها + درآمدها − هزینه‌ها (همان موجودی صندوق داشبورد). */
function report_cashbook(int $bid, string $from, string $to): array {
    $b = loadBuilding($bid);
    $names = unitNames($bid);
    $db = db();
    $s = $db->prepare("SELECT COALESCE(SUM(amount), 0) FROM unit_transactions WHERE building_id = ? AND kind = 'payment' AND date < ?");
    $s->execute([$bid, $from]);
    $opening = (int) $b['opening_balance'] + (int) $s->fetchColumn();
    $s = $db->prepare("SELECT COALESCE(SUM(CASE WHEN direction = 'in' THEN amount ELSE -amount END), 0) FROM fund_entries WHERE building_id = ? AND date < ?");
    $s->execute([$bid, $from]);
    $opening += (int) $s->fetchColumn();

    $moves = [];
    $s = $db->prepare("SELECT id, date, unit_id, title, method, ref_no, amount FROM unit_transactions WHERE building_id = ? AND kind = 'payment' AND date BETWEEN ? AND ?");
    $s->execute([$bid, $from, $to]);
    foreach ($s->fetchAll() as $t) $moves[] = ['date' => $t['date'], 'order' => 'a' . str_pad($t['id'], 10, '0', STR_PAD_LEFT), 'type' => 'unit_payment',
        'title' => ($t['title'] ?: 'پرداخت') . ' — ' . ($names[(int) $t['unit_id']] ?? ''), 'party' => $names[(int) $t['unit_id']] ?? '', 'method' => $t['method'], 'ref_no' => $t['ref_no'], 'in' => (int) $t['amount'], 'out' => 0];
    $s = $db->prepare("SELECT id, date, direction, category, title, payee, method, ref_no, amount FROM fund_entries WHERE building_id = ? AND date BETWEEN ? AND ?");
    $s->execute([$bid, $from, $to]);
    foreach ($s->fetchAll() as $f) $moves[] = ['date' => $f['date'], 'order' => 'b' . str_pad($f['id'], 10, '0', STR_PAD_LEFT), 'type' => $f['direction'] === 'in' ? 'income' : 'expense',
        'category' => $f['category'], 'title' => $f['title'], 'party' => $f['payee'], 'method' => $f['method'], 'ref_no' => $f['ref_no'],
        'in' => $f['direction'] === 'in' ? (int) $f['amount'] : 0, 'out' => $f['direction'] === 'out' ? (int) $f['amount'] : 0];
    usort($moves, fn($x, $y) => [$x['date'], $x['order']] <=> [$y['date'], $y['order']]);
    $balance = $opening;
    $in = $out = 0;
    foreach ($moves as &$m) {
        $balance += $m['in'] - $m['out'];
        $in += $m['in'];
        $out += $m['out'];
        $m['balance'] = $balance;
        unset($m['order']);
    }
    return ['opening' => $opening, 'in' => $in, 'out' => $out, 'closing' => $balance, 'rows' => $moves];
}

/** پیشنهاد «پرداخت به» در فرم هزینه و فیلتر گزارش: نیروها/پیمانکاران + نام‌هایی که قبلاً استفاده شده. */
function report_payees(int $bid): void {
    requireBuilding($bid);
    $s = db()->prepare('SELECT id, full_name, specialty FROM staff WHERE building_id = ? ORDER BY active DESC, full_name');
    $s->execute([$bid]);
    $staff = array_map(fn($x) => ['id' => (int) $x['id']] + $x, $s->fetchAll());
    $s = db()->prepare("SELECT payee, COUNT(*) AS n FROM fund_entries WHERE building_id = ? AND payee <> '' AND staff_id IS NULL GROUP BY payee ORDER BY n DESC LIMIT 50");
    $s->execute([$bid]);
    respond(['staff' => $staff, 'payees' => $s->fetchAll(PDO::FETCH_COLUMN)]);
}
