<?php
// پنل ساکن: هر کسی که موبایلش در پرونده‌ی یک واحد (مالک یا مستأجر) ثبت شده، با همان موبایل وارد می‌شود
// و فقط اطلاعات واحد(های) خودش را می‌بیند. اعلام واریز ساکن بعد از تأیید مدیریت در حساب واحد ثبت می‌شود.

function currentUserMobile(): string {
    $stmt = db()->prepare('SELECT mobile FROM users WHERE id = ?');
    $stmt->execute([authUserId()]);
    return (string) $stmt->fetchColumn();
}

/** واحدهایی که کاربرِ فعلی مالک یا مستأجرشان است. */
function userResidences(string $mobile): array {
    $stmt = db()->prepare(
        "SELECT p.unit_id, MIN(p.role) AS role, MIN(p.full_name) AS full_name, u.title AS unit_title, u.block AS unit_block,
                b.id AS building_id, b.name AS building_name
           FROM persons p JOIN units u ON u.id = p.unit_id JOIN buildings b ON b.id = p.building_id
          WHERE p.mobile = ? GROUP BY p.unit_id, u.title, u.block, b.id, b.name ORDER BY b.id, u.id"
    );
    $stmt->execute([$mobile]);
    return array_map(fn($r) => ['unit_id' => (int) $r['unit_id'], 'building_id' => (int) $r['building_id']] + $r, $stmt->fetchAll());
}

/** واحد را فقط وقتی برمی‌گرداند که کاربرِ فعلی ساکن/مالکِ آن باشد؛ وگرنه 404. */
function requireResident(int $unitId): array {
    $stmt = db()->prepare('SELECT p.full_name, p.role FROM persons p WHERE p.unit_id = ? AND p.mobile = ? ORDER BY p.id LIMIT 1');
    $stmt->execute([$unitId, currentUserMobile()]);
    $person = $stmt->fetch();
    if (!$person) fail('NOT_FOUND', 404);
    $stmt = db()->prepare('SELECT * FROM units WHERE id = ?');
    $stmt->execute([$unitId]);
    return $stmt->fetch() + ['person_name' => $person['full_name'], 'person_role' => $person['role']];
}

function me_residences(): void {
    respond(['residences' => userResidences(currentUserMobile())]);
}

function me_unit(int $unitId, int $status = 200): void {
    $unit = requireResident($unitId);
    $b = loadBuilding((int) $unit['building_id']);

    $stmt = db()->prepare('SELECT id, kind, amount, title, period, due_date, date, method, ref_no, payer FROM unit_transactions WHERE unit_id = ? ORDER BY date, id');
    $stmt->execute([$unitId]);
    $running = $owner = 0;
    $rows = [];
    foreach ($stmt->fetchAll() as $t) {
        $t['id'] = (int) $t['id'];
        $t['amount'] = (int) $t['amount'];
        $signed = in_array($t['kind'], DEBIT_KINDS, true) ? $t['amount'] : -$t['amount'];
        $running += $signed;
        if ($t['payer'] === 'owner') $owner += $signed;
        $t['balance'] = $running;
        $rows[] = $t;
    }

    $stmt = db()->prepare("SELECT MAX(due_date) FROM unit_transactions WHERE unit_id = ? AND kind = 'charge'");
    $stmt->execute([$unitId]);
    $lastDue = $stmt->fetchColumn() ?: null;

    $stmt = db()->prepare('SELECT id, amount, date, ref_no, note, status, review_note, receipt, created_at FROM payment_claims WHERE unit_id = ? ORDER BY id DESC LIMIT 20');
    $stmt->execute([$unitId]);
    $claims = array_map(fn($c) => ['id' => (int) $c['id'], 'amount' => (int) $c['amount'], 'receipt' => $c['receipt'] !== ''] + $c, $stmt->fetchAll());
    $stmt = db()->prepare("SELECT COALESCE(SUM(amount), 0) FROM payment_claims WHERE unit_id = ? AND status = 'pending'");
    $stmt->execute([$unitId]);
    $pending = (int) $stmt->fetchColumn();

    respond([
        'unit' => ['id' => $unitId, 'title' => $unit['title'], 'block' => $unit['block'], 'person_name' => $unit['person_name'], 'person_role' => $unit['person_role']],
        'building' => [
            'id' => (int) $b['id'], 'name' => $b['name'],
            'bank_name' => $b['bank_name'], 'bank_holder' => $b['bank_holder'], 'bank_sheba' => $b['bank_sheba'], 'bank_card' => $b['bank_card'],
            'address' => $b['address'], 'city' => $b['city'],
        ],
        'balance' => $running,
        'owner_balance' => $owner,
        'monthly_charge' => chargeFor($unit, $b),
        'notices' => buildingNotices((int) $b['id'], 10),
        'last_due_date' => $lastDue,
        'pending_claims' => $pending,
        'transactions' => array_reverse($rows),
        'claims' => $claims,
    ], $status);
}

function me_claim_create(int $unitId): void {
    $unit = requireResident($unitId);
    if (!rateLimit('claim:' . authUserId(), 10, 3600)) fail('TOO_MANY_REQUESTS', 429);
    $b = body();
    $amount = money($b['amount'] ?? '');
    if (!$amount) fail('INVALID_AMOUNT');
    $date = isoDate($b['date'] ?? '') ?? fail('INVALID_DATE');
    if ($date > today()) fail('INVALID_DATE');
    $ref = toEnDigits(cleanStr($b['ref_no'] ?? '', 40));
    if ($ref === '' && empty($b['receipt'])) fail('REF_REQUIRED');
    $receipt = saveReceipt($b['receipt'] ?? '', (int) $unit['building_id']);
    db()->prepare('INSERT INTO payment_claims (building_id, unit_id, user_id, amount, date, ref_no, note, receipt, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
        ->execute([$unit['building_id'], $unitId, authUserId(), $amount, $date, $ref, cleanStr($b['note'] ?? '', 500), $receipt, now()]);
    me_unit($unitId, 201);
}

const RECEIPT_TYPES = ['jpeg' => 'jpg', 'png' => 'png', 'webp' => 'webp'];

/** عکس فیش (data URL که فرانت فشرده کرده) → data/receipts/{ساختمان}/؛ نام فایل برمی‌گردد. خالی = بدون فیش. */
function saveReceipt($dataUrl, int $bid): string {
    if (!is_string($dataUrl) || $dataUrl === '') return '';
    if (!preg_match('#^data:image/(jpeg|png|webp);base64,([A-Za-z0-9+/=]+)$#', $dataUrl, $m)) fail('INVALID_RECEIPT');
    $bin = base64_decode($m[2], true);
    if ($bin === false || strlen($bin) > 1536 * 1024) fail('INVALID_RECEIPT');
    $info = @getimagesizefromstring($bin);
    if (!$info || $info['mime'] !== 'image/' . $m[1]) fail('INVALID_RECEIPT');
    $dir = __DIR__ . "/../data/receipts/$bid";
    if (!is_dir($dir) && !@mkdir($dir, 0755, true)) fail('SERVER_ERROR', 500);
    $name = bin2hex(random_bytes(16)) . '.' . RECEIPT_TYPES[$m[1]];
    if (file_put_contents("$dir/$name", $bin) === false) fail('SERVER_ERROR', 500);
    return $name;
}

/** فیش یک واریز: فقط برای تیم مدیریت همان ساختمان یا خود ساکنی که اعلامش کرده. */
function claim_receipt(int $claimId): void {
    $stmt = db()->prepare('SELECT building_id, user_id, receipt FROM payment_claims WHERE id = ?');
    $stmt->execute([$claimId]);
    $c = $stmt->fetch() ?: fail('NOT_FOUND', 404);
    if ((int) $c['user_id'] !== authUserId()) requireBuilding((int) $c['building_id']);
    $file = __DIR__ . '/../data/receipts/' . (int) $c['building_id'] . '/' . basename($c['receipt']);
    if ($c['receipt'] === '' || !is_file($file)) fail('NOT_FOUND', 404);
    $ext = pathinfo($file, PATHINFO_EXTENSION);
    header('Content-Type: image/' . ($ext === 'jpg' ? 'jpeg' : $ext));
    header('Content-Length: ' . filesize($file));
    header('Cache-Control: private, max-age=86400');
    readfile($file);
    exit;
}

function me_requests(int $unitId, int $status = 200): void {
    requireResident($unitId);
    $stmt = db()->prepare('SELECT r.id, r.type, r.priority, r.title, r.description, r.status, r.work_notes, r.created_at, r.done_at, r.closed_at, s.full_name AS staff_name
                             FROM service_requests r LEFT JOIN staff s ON s.id = r.assigned_to WHERE r.unit_id = ? ORDER BY r.id DESC LIMIT 100');
    $stmt->execute([$unitId]);
    respond(['requests' => array_map(fn($r) => ['id' => (int) $r['id']] + $r, $stmt->fetchAll())], $status);
}

/** درخواستِ ساکن در وضعیت «در انتظار بررسی» می‌ماند تا مدیریت تأیید و تخصیص دهد. */
function me_request_create(int $unitId): void {
    $unit = requireResident($unitId);
    if (!rateLimit('req:' . authUserId(), 20, 86400)) fail('TOO_MANY_REQUESTS', 429);
    $b = body();
    $title = cleanStr($b['title'] ?? '', 150);
    if (mb_strlen($title) < 2) fail('INVALID_TITLE');
    $db = db();
    $db->beginTransaction();
    $db->prepare("INSERT INTO service_requests (building_id, unit_id, type, priority, title, description, reporter_name, status, source, created_by, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, 'new', 'resident', ?, ?, ?)")
       ->execute([$unit['building_id'], $unitId, oneOf($b['type'] ?? '', REQUEST_TYPES, 'other'), oneOf($b['priority'] ?? '', ['normal', 'urgent'], 'normal'),
                  $title, cleanStr($b['description'] ?? '', 1000), $unit['person_name'], authUserId(), now(), now()]);
    logRequestEvent((int) $db->lastInsertId(), 'new', 'ثبت توسط ساکن');
    $db->commit();
    me_requests($unitId, 201);
}

// ================= سمت مدیریت: بررسی واریزهای اعلام‌شده =================

function claims_list(int $bid): void {
    requireBuilding($bid);
    $status = in_array($_GET['status'] ?? '', ['pending', 'approved', 'rejected'], true) ? $_GET['status'] : null;
    $stmt = db()->prepare('SELECT c.*, u.title AS unit_title, u.block AS unit_block, us.full_name AS user_name, us.mobile AS user_mobile
                             FROM payment_claims c JOIN units u ON u.id = c.unit_id JOIN users us ON us.id = c.user_id
                            WHERE c.building_id = ?' . ($status ? ' AND c.status = ?' : '') . ' ORDER BY c.id DESC LIMIT 300');
    $stmt->execute($status ? [$bid, $status] : [$bid]);
    respond(['claims' => array_map(fn($c) => ['id' => (int) $c['id'], 'unit_id' => (int) $c['unit_id'], 'amount' => (int) $c['amount'], 'receipt' => $c['receipt'] !== ''] + $c, $stmt->fetchAll())]);
}

/** تأیید = ثبت پرداخت در حساب واحد (با امکان اصلاح مبلغ)؛ رد = با دلیل. */
function claim_review(int $claimId): void {
    $stmt = db()->prepare('SELECT * FROM payment_claims WHERE id = ?');
    $stmt->execute([$claimId]);
    $c = $stmt->fetch() ?: fail('NOT_FOUND', 404);
    requireBuilding((int) $c['building_id'], 'write');
    if ($c['status'] !== 'pending') fail('ALREADY_REVIEWED', 409);

    $b = body();
    $action = $b['action'] ?? '';
    $note = cleanStr($b['note'] ?? '', 500);
    if ($action === 'approve') {
        $amount = isset($b['amount']) && $b['amount'] !== '' ? (money($b['amount']) ?? fail('INVALID_AMOUNT')) : (int) $c['amount'];
        if ($amount <= 0) fail('INVALID_AMOUNT');
    } elseif ($action === 'reject') {
        if (mb_strlen($note) < 2) fail('REASON_REQUIRED');
    } else {
        fail('INVALID_ACTION');
    }
    $db = db();
    $db->beginTransaction();
    // فقط یک درخواست می‌تواند اعلام را از «در انتظار» بیرون بیاورد (دو کلیک یا دو مدیر هم‌زمان → یک پرداخت).
    $claim = $db->prepare("UPDATE payment_claims SET status = ?, reviewed_by = ?, reviewed_at = ? WHERE id = ? AND status = 'pending'");
    $claim->execute([$action === 'approve' ? 'approved' : 'rejected', authUserId(), now(), $claimId]);
    if ($claim->rowCount() !== 1) {
        $db->rollBack();
        fail('ALREADY_REVIEWED', 409);
    }
    if ($action === 'approve') {
        insertTx(['building_id' => (int) $c['building_id'], 'unit_id' => (int) $c['unit_id'], 'kind' => 'payment', 'amount' => $amount,
                  'title' => 'واریز اعلام‌شده توسط ساکن', 'date' => $c['date'], 'method' => 'transfer', 'ref_no' => $c['ref_no'], 'notes' => $c['note'],
                  'payer' => payerInput($b['payer'] ?? '')]);
        $txId = (int) $db->lastInsertId();
        $db->prepare("UPDATE payment_claims SET status = 'approved', amount = ?, tx_id = ?, review_note = ?, reviewed_by = ?, reviewed_at = ? WHERE id = ?")
           ->execute([$amount, $txId, $note, authUserId(), now(), $claimId]);
        audit((int) $c['building_id'], 'claim.approve', 'تأیید واریز ' . faMoney($amount) . ' ' . unitNameById((int) $c['unit_id']) . ' (پیگیری ' . faDigits($c['ref_no']) . ')', 'unit', (int) $c['unit_id']);
    } else {
        $db->prepare("UPDATE payment_claims SET status = 'rejected', review_note = ?, reviewed_by = ?, reviewed_at = ? WHERE id = ?")
           ->execute([$note, authUserId(), now(), $claimId]);
        audit((int) $c['building_id'], 'claim.reject', 'رد واریز ' . faMoney((int) $c['amount']) . ' ' . unitNameById((int) $c['unit_id']) . ": $note", 'unit', (int) $c['unit_id']);
    }
    $db->commit();
    if ($action === 'reject') {
        // ساکن باید بداند واریزش پذیرفته نشد (وگرنه فکر می‌کند حسابش صاف است).
        $s = db()->prepare('SELECT mobile FROM users WHERE id = ?');
        $s->execute([$c['user_id']]);
        $bld = loadBuilding((int) $c['building_id']);
        smsNotify((int) $c['building_id'], 'claim', [[$s->fetchColumn(), 'واریز ' . faMoney((int) $c['amount']) . ' (پیگیری ' . faDigits($c['ref_no']) . ") تأیید نشد.\nدلیل: $note" . smsFooter($bld)]]);
    }
    claims_list((int) $c['building_id']);
}
