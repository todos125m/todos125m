<?php
// خدمات: نیروها و پیمانکاران، تجهیزات و سرویس دوره‌ای، درخواست‌های خدماتی با چرخه‌ی ۵ مرحله‌ای.

const REQUEST_TYPES = ['repair', 'cleaning', 'facilities', 'elevator', 'utilities', 'common', 'other'];
const PRIORITIES    = ['low', 'normal', 'urgent'];
const OPEN_STATUSES = ['new', 'approved', 'assigned', 'done'];
const EQUIPMENT_CATEGORIES = ['elevator', 'pump', 'electrical', 'hvac', 'cctv', 'safety', 'other'];
const SOON_DAYS = 7;

// ================= نیروها =================

function castStaff(array $s): array {
    $s['id'] = (int) $s['id'];
    $s['active'] = (bool) $s['active'];
    $s['default_types'] = $s['default_types'] === '' ? [] : explode(',', $s['default_types']);
    unset($s['building_id']);
    return $s;
}

function staffInput(array $b, array $cur = []): array {
    $pick = fn($k, $d = '') => array_key_exists($k, $b) ? $b[$k] : ($cur[$k] ?? $d);
    $name = cleanStr($pick('full_name'), 120);
    if (mb_strlen($name) < 2) fail('INVALID_NAME');
    // پیمانکارها اغلب تلفن ثابت دارند: موبایل یا شماره‌ی ۸ تا ۱۱ رقمی
    $raw = preg_replace('/[\s\-]/', '', toEnDigits($pick('mobile') ?? ''));
    $mobile = $raw === '' ? null : (normalizeMobile($raw) ?? (preg_match('/^\d{8,11}$/', $raw) ? $raw : fail('INVALID_PHONE')));
    $types = $pick('default_types', []);
    if (is_string($types)) $types = $types === '' ? [] : explode(',', $types);
    $types = array_values(array_intersect(REQUEST_TYPES, (array) $types));
    return [
        'full_name' => $name,
        'mobile' => $mobile,
        'specialty' => cleanStr($pick('specialty'), 60),
        'kind' => oneOf($pick('kind', 'internal'), ['internal', 'contractor'], 'internal'),
        'default_types' => implode(',', $types),
        'notes' => cleanStr($pick('notes'), 500),
        'active' => $pick('active', 1) ? 1 : 0,
    ];
}

function loadStaff(int $id, string $need = 'read'): array {
    $stmt = db()->prepare('SELECT * FROM staff WHERE id = ?');
    $stmt->execute([$id]);
    $s = $stmt->fetch() ?: fail('NOT_FOUND', 404);
    requireBuilding((int) $s['building_id'], $need);
    return $s;
}

function staff_list(int $bid): void {
    requireBuilding($bid);
    $stmt = db()->prepare("SELECT s.*,
            (SELECT COUNT(*) FROM service_requests r WHERE r.assigned_to = s.id AND r.status IN ('assigned', 'done')) AS open_requests
        FROM staff s WHERE s.building_id = ? ORDER BY s.active DESC, s.id");
    $stmt->execute([$bid]);
    respond(['staff' => array_map(fn($s) => castStaff($s) + ['open_requests' => (int) $s['open_requests']], $stmt->fetchAll())]);
}

function staff_create(int $bid): void {
    requireBuilding($bid, 'write');
    $in = staffInput(body());
    db()->prepare('INSERT INTO staff (building_id, full_name, mobile, specialty, kind, default_types, notes, active, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
        ->execute([$bid, ...array_values($in), now()]);
    staff_list($bid);
}

function staff_update(int $id): void {
    $s  = loadStaff($id, 'write');
    $in = staffInput(body(), $s);
    db()->prepare('UPDATE staff SET full_name = ?, mobile = ?, specialty = ?, kind = ?, default_types = ?, notes = ?, active = ? WHERE id = ?')
        ->execute([...array_values($in), $id]);
    staff_list((int) $s['building_id']);
}

function staff_delete(int $id): void {
    $s = loadStaff($id, 'write');
    // سوابق درخواست‌ها و سرویس‌ها می‌مانند (ارجاع NULL می‌شود).
    db()->prepare('DELETE FROM staff WHERE id = ?')->execute([$id]);
    staff_list((int) $s['building_id']);
}

// ================= تجهیزات =================

function equipmentStatus(array $e): array {
    $interval = $e['service_interval_days'] === null ? null : (int) $e['service_interval_days'];
    $last     = $e['last_service_date'];
    $next     = ($interval && $last) ? date('Y-m-d', strtotime("$last +$interval days")) : null;
    $status   = 'none';
    if ($interval) {
        $status = match (true) {
            $last === null => 'never',
            $next < today() => 'overdue',
            $next <= date('Y-m-d', strtotime('+' . SOON_DAYS . ' days')) => 'soon',
            default => 'ok',
        };
    }
    return ['next_service_date' => $next, 'service_status' => $status];
}

function castEquipment(array $e): array {
    foreach (['id', 'building_id'] as $k) $e[$k] = (int) $e[$k];
    $e['staff_id'] = $e['staff_id'] === null ? null : (int) $e['staff_id'];
    $e['service_interval_days'] = $e['service_interval_days'] === null ? null : (int) $e['service_interval_days'];
    $e['active'] = (bool) $e['active'];
    return $e + equipmentStatus($e);
}

function equipmentInput(array $b, array $cur = []): array {
    $pick = fn($k, $d = '') => array_key_exists($k, $b) ? $b[$k] : ($cur[$k] ?? $d);
    $name = cleanStr($pick('name'), 120);
    if (mb_strlen($name) < 2) fail('INVALID_NAME');
    $last = $pick('last_service_date', null);
    return [
        'name' => $name,
        'category' => oneOf($pick('category', 'other'), EQUIPMENT_CATEGORIES, 'other'),
        'location' => cleanStr($pick('location'), 120),
        'staff_id' => optInt($pick('staff_id', null), 1, PHP_INT_MAX),
        'service_interval_days' => optInt($pick('service_interval_days', null), 1, 3650),
        'last_service_date' => ($last === null || $last === '') ? null : (isoDate($last) ?? fail('INVALID_DATE')),
        'notes' => cleanStr($pick('notes'), 500),
        'active' => $pick('active', 1) ? 1 : 0,
    ];
}

function checkStaffBelongs(?int $staffId, int $bid): void {
    if ($staffId === null) return;
    $stmt = db()->prepare('SELECT 1 FROM staff WHERE id = ? AND building_id = ?');
    $stmt->execute([$staffId, $bid]);
    if (!$stmt->fetchColumn()) fail('INVALID_STAFF');
}

function loadEquipment(int $id, string $need = 'read'): array {
    $stmt = db()->prepare('SELECT * FROM equipment WHERE id = ?');
    $stmt->execute([$id]);
    $e = $stmt->fetch() ?: fail('NOT_FOUND', 404);
    requireBuilding((int) $e['building_id'], $need);
    return $e;
}

function equipment_list(int $bid): void {
    requireBuilding($bid);
    $stmt = db()->prepare("SELECT e.*, s.full_name AS staff_name,
            (SELECT COUNT(*) FROM service_requests r WHERE r.equipment_id = e.id) AS request_count,
            (SELECT COUNT(*) FROM service_requests r WHERE r.equipment_id = e.id AND r.status IN ('new', 'approved', 'assigned', 'done')) AS open_requests
        FROM equipment e LEFT JOIN staff s ON s.id = e.staff_id WHERE e.building_id = ? ORDER BY e.active DESC, e.category, e.id");
    $stmt->execute([$bid]);
    respond(['equipment' => array_map(fn($e) => castEquipment($e) + ['request_count' => (int) $e['request_count'], 'open_requests' => (int) $e['open_requests']], $stmt->fetchAll())]);
}

function equipment_create(int $bid): void {
    requireBuilding($bid, 'write');
    $in = equipmentInput(body());
    checkStaffBelongs($in['staff_id'], $bid);
    db()->prepare('INSERT INTO equipment (building_id, name, category, location, staff_id, service_interval_days, last_service_date, notes, active, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
        ->execute([$bid, ...array_values($in), now(), now()]);
    equipment_show((int) db()->lastInsertId(), 201);
}

function equipment_show(int $id, int $status = 200): void {
    $e = loadEquipment($id);
    $db = db();
    $s = $db->prepare('SELECT es.*, st.full_name AS staff_name FROM equipment_services es LEFT JOIN staff st ON st.id = es.staff_id WHERE es.equipment_id = ? ORDER BY es.date DESC, es.id DESC');
    $s->execute([$id]);
    $services = array_map(fn($r) => ['id' => (int) $r['id'], 'cost' => (int) $r['cost']] + $r, $s->fetchAll());
    $s = $db->prepare('SELECT id, title, status, priority, created_at, done_at, cost FROM service_requests WHERE equipment_id = ? ORDER BY id DESC');
    $s->execute([$id]);
    $requests = array_map(fn($r) => ['id' => (int) $r['id'], 'cost' => $r['cost'] === null ? null : (int) $r['cost']] + $r, $s->fetchAll());
    respond([
        'equipment' => castEquipment($e),
        'services' => $services,
        'requests' => $requests,
        'total_cost' => array_sum(array_column($services, 'cost')) + array_sum(array_map(fn($r) => $r['cost'] ?? 0, $requests)),
    ], $status);
}

function equipment_update(int $id): void {
    $e  = loadEquipment($id, 'write');
    $in = equipmentInput(body(), $e);
    checkStaffBelongs($in['staff_id'], (int) $e['building_id']);
    db()->prepare('UPDATE equipment SET name = ?, category = ?, location = ?, staff_id = ?, service_interval_days = ?, last_service_date = ?, notes = ?, active = ?, updated_at = ? WHERE id = ?')
        ->execute([...array_values($in), now(), $id]);
    equipment_show($id);
}

function equipment_delete(int $id): void {
    $e = loadEquipment($id, 'write');
    db()->prepare('DELETE FROM equipment WHERE id = ?')->execute([$id]);
    audit((int) $e['building_id'], 'equipment.delete', "حذف تجهیز «{$e['name']}»");
    respond(['ok' => true]);
}

function expenseCategoryFor(?string $equipmentCategory, ?string $requestType = null): string {
    if ($equipmentCategory === 'elevator' || $requestType === 'elevator') return 'elevator';
    if ($requestType === 'cleaning') return 'cleaning';
    return 'repair';
}

/** ثبت سرویس: سررسید بعدی جلو می‌رود؛ هزینه (اختیاری) در صندوق ثبت می‌شود. */
function equipment_service_create(int $id): void {
    $e = loadEquipment($id, 'write');
    $b = body();
    $bid  = (int) $e['building_id'];
    $date = isoDate($b['date'] ?? '') ?? fail('INVALID_DATE');
    $cost = ($b['cost'] ?? '') === '' ? 0 : (money($b['cost']) ?? fail('INVALID_AMOUNT'));
    $staff = optInt($b['staff_id'] ?? null, 1, PHP_INT_MAX);
    checkStaffBelongs($staff, $bid);
    $desc = cleanStr($b['description'] ?? '', 500);

    $db = db();
    $db->beginTransaction();
    $fundId = null;
    if (!empty($b['record_expense']) && $cost > 0) {
        $fundId = insertFundEntry($bid, 'out', expenseCategoryFor($e['category']), $cost, $date, "سرویس {$e['name']}", $desc);
    }
    $db->prepare('INSERT INTO equipment_services (building_id, equipment_id, date, cost, description, staff_id, fund_entry_id, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
       ->execute([$bid, $id, $date, $cost, $desc, $staff, $fundId, authUserId(), now()]);
    // آخرین سرویس = جدیدترین تاریخ ثبت‌شده (ثبت دیرهنگامِ سرویس قدیمی سررسید را عقب نمی‌برد)
    $db->prepare('UPDATE equipment SET last_service_date = (SELECT MAX(date) FROM equipment_services WHERE equipment_id = ?), updated_at = ? WHERE id = ?')
       ->execute([$id, now(), $id]);
    audit($bid, 'equipment.service', "ثبت سرویس «{$e['name']}»" . ($cost ? ' — ' . faMoney($cost) : ''), 'equipment', $id);
    $db->commit();
    equipment_show($id, 201);
}

function equipment_service_delete(int $serviceId): void {
    $stmt = db()->prepare('SELECT * FROM equipment_services WHERE id = ?');
    $stmt->execute([$serviceId]);
    $s = $stmt->fetch() ?: fail('NOT_FOUND', 404);
    requireBuilding((int) $s['building_id'], 'write');
    $db = db();
    $db->beginTransaction();
    $db->prepare('DELETE FROM equipment_services WHERE id = ?')->execute([$serviceId]);
    if ($s['fund_entry_id']) $db->prepare('DELETE FROM fund_entries WHERE id = ?')->execute([$s['fund_entry_id']]);
    $db->prepare('UPDATE equipment SET last_service_date = (SELECT MAX(date) FROM equipment_services WHERE equipment_id = ?) WHERE id = ?')
       ->execute([$s['equipment_id'], $s['equipment_id']]);
    $db->commit();
    equipment_show((int) $s['equipment_id']);
}

// ================= درخواست‌ها =================

function castRequest(array $r): array {
    foreach (['id', 'building_id'] as $k) $r[$k] = (int) $r[$k];
    foreach (['unit_id', 'equipment_id', 'assigned_to', 'cost', 'fund_entry_id'] as $k) $r[$k] = $r[$k] === null ? null : (int) $r[$k];
    return $r;
}

function requestSelect(): string {
    return 'SELECT r.*, u.title AS unit_title, u.block AS unit_block, e.name AS equipment_name, s.full_name AS staff_name, s.mobile AS staff_mobile
              FROM service_requests r
              LEFT JOIN units u ON u.id = r.unit_id
              LEFT JOIN equipment e ON e.id = r.equipment_id
              LEFT JOIN staff s ON s.id = r.assigned_to';
}

function loadRequest(int $id, string $need = 'read'): array {
    $stmt = db()->prepare('SELECT * FROM service_requests WHERE id = ?');
    $stmt->execute([$id]);
    $r = $stmt->fetch() ?: fail('NOT_FOUND', 404);
    requireBuilding((int) $r['building_id'], $need);
    return $r;
}

function logRequestEvent(int $requestId, string $status, string $note = ''): void {
    db()->prepare('INSERT INTO request_events (request_id, status, note, user_id, created_at) VALUES (?, ?, ?, ?, ?)')
        ->execute([$requestId, $status, $note, authUserId(), now()]);
}

function requestTargets(array $b, int $bid): array {
    $unit = optInt($b['unit_id'] ?? null, 1, PHP_INT_MAX);
    if ($unit) {
        $s = db()->prepare('SELECT 1 FROM units WHERE id = ? AND building_id = ?');
        $s->execute([$unit, $bid]);
        if (!$s->fetchColumn()) fail('INVALID_UNIT');
    }
    $equip = optInt($b['equipment_id'] ?? null, 1, PHP_INT_MAX);
    if ($equip) {
        $s = db()->prepare('SELECT 1 FROM equipment WHERE id = ? AND building_id = ?');
        $s->execute([$equip, $bid]);
        if (!$s->fetchColumn()) fail('INVALID_EQUIPMENT');
    }
    return [$unit, $equip];
}

function requests_list(int $bid): void {
    requireBuilding($bid);
    $where = ['r.building_id = ?'];
    $args  = [$bid];
    $status = $_GET['status'] ?? 'open';
    if ($status === 'open') $where[] = "r.status IN ('new', 'approved', 'assigned', 'done')";
    elseif (in_array($status, ['new', 'approved', 'assigned', 'done', 'closed', 'rejected'], true)) { $where[] = 'r.status = ?'; $args[] = $status; }
    foreach (['unit_id', 'equipment_id', 'assigned_to'] as $k) {
        if ($v = optInt($_GET[$k] ?? null, 1, PHP_INT_MAX)) { $where[] = "r.$k = ?"; $args[] = $v; }
    }
    $stmt = db()->prepare(requestSelect() . ' WHERE ' . implode(' AND ', $where) . "
        ORDER BY CASE r.status WHEN 'new' THEN 0 WHEN 'approved' THEN 1 WHEN 'assigned' THEN 2 WHEN 'done' THEN 3 ELSE 4 END,
                 CASE r.priority WHEN 'urgent' THEN 0 WHEN 'normal' THEN 1 ELSE 2 END, r.id DESC LIMIT 500");
    $stmt->execute($args);
    respond(['requests' => array_map('castRequest', $stmt->fetchAll())]);
}

/**
 * ثبت درخواست توسط مدیریت = ثبت + تأیید هم‌زمان. اگر نوع درخواست مسئول پیش‌فرض داشته باشد،
 * خودکار به او تخصیص می‌یابد. (درخواست‌هایی که بعداً ساکن ثبت کند در وضعیت new می‌مانند.)
 */
function requests_create(int $bid): void {
    requireBuilding($bid, 'write');
    $b = body();
    $title = cleanStr($b['title'] ?? '', 150);
    if (mb_strlen($title) < 2) fail('INVALID_TITLE');
    $type = oneOf($b['type'] ?? '', REQUEST_TYPES, 'other');
    [$unit, $equip] = requestTargets($b, $bid);

    $assignee = optInt($b['assigned_to'] ?? null, 1, PHP_INT_MAX);
    if ($assignee) checkStaffBelongs($assignee, $bid);
    if (!$assignee) {
        $match = DB_DRIVER === 'mysql' ? 'FIND_IN_SET(?, default_types)' : "(',' || default_types || ',') LIKE ?";
        $s = db()->prepare("SELECT id FROM staff WHERE building_id = ? AND active = 1 AND $match ORDER BY id LIMIT 1");
        $s->execute([$bid, DB_DRIVER === 'mysql' ? $type : "%,$type,%"]);
        $assignee = $s->fetchColumn() ?: null;
    }
    $status = $assignee ? 'assigned' : 'approved';

    $db = db();
    $db->beginTransaction();
    $db->prepare('INSERT INTO service_requests (building_id, unit_id, equipment_id, type, priority, title, description, reporter_name, status, assigned_to, created_by, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
       ->execute([$bid, $unit, $equip, $type, oneOf($b['priority'] ?? '', PRIORITIES, 'normal'), $title, cleanStr($b['description'] ?? '', 1000),
                  cleanStr($b['reporter_name'] ?? '', 120), $status, $assignee, authUserId(), now(), now()]);
    $id = (int) $db->lastInsertId();
    logRequestEvent($id, 'new');
    logRequestEvent($id, 'approved', 'ثبت توسط مدیریت');
    if ($assignee) logRequestEvent($id, 'assigned', 'تخصیص خودکار به مسئول این نوع درخواست');
    $db->commit();
    if ($assignee) smsAssignee($id);
    request_show($id, 201);
}

function request_show(int $id, int $status = 200): void {
    $r = loadRequest($id);
    $stmt = db()->prepare(requestSelect() . ' WHERE r.id = ?');
    $stmt->execute([$id]);
    $row = castRequest($stmt->fetch());
    $ev = db()->prepare('SELECT ev.status, ev.note, ev.created_at, u.full_name AS user_name FROM request_events ev LEFT JOIN users u ON u.id = ev.user_id WHERE ev.request_id = ? ORDER BY ev.id');
    $ev->execute([$id]);
    $tx = null;
    if ($r['fund_entry_id']) {
        $t = db()->prepare("SELECT id, amount FROM unit_transactions WHERE fund_entry_id = ? LIMIT 1");
        $t->execute([$r['fund_entry_id']]);
        $tx = $t->fetch() ?: null;
    }
    respond(['request' => $row + ['charged_to_unit' => (bool) $tx], 'events' => $ev->fetchAll()], $status);
}

function request_update(int $id): void {
    $r = loadRequest($id, 'write');
    if (!in_array($r['status'], OPEN_STATUSES, true)) fail('REQUEST_CLOSED', 409);
    $b = body();
    $title = cleanStr($b['title'] ?? $r['title'], 150);
    if (mb_strlen($title) < 2) fail('INVALID_TITLE');
    [$unit, $equip] = requestTargets(['unit_id' => $b['unit_id'] ?? $r['unit_id'], 'equipment_id' => $b['equipment_id'] ?? $r['equipment_id']] , (int) $r['building_id']);
    db()->prepare('UPDATE service_requests SET title = ?, description = ?, type = ?, priority = ?, unit_id = ?, equipment_id = ?, reporter_name = ?, updated_at = ? WHERE id = ?')
        ->execute([
            $title, cleanStr($b['description'] ?? $r['description'], 1000), oneOf($b['type'] ?? $r['type'], REQUEST_TYPES, 'other'),
            oneOf($b['priority'] ?? $r['priority'], PRIORITIES, 'normal'), $unit, $equip, cleanStr($b['reporter_name'] ?? $r['reporter_name'], 120), now(), $id,
        ]);
    request_show($id);
}

/**
 * تغییر وضعیت. انتقال‌های مجاز:
 *   approve: new → approved         assign: new/approved/assigned → assigned (با staff_id)
 *   done: approved/assigned → done  (هزینه، شرح کار؛ اختیاری: ثبت در صندوق، بدهی واحد)
 *   close: done → closed            reject: هر وضعیت باز → rejected (با دلیل)
 *   reopen: closed/rejected → approved
 */
function request_transition(int $id): void {
    $r = loadRequest($id, 'write');
    $b = body();
    $action = $b['action'] ?? '';
    $note   = cleanStr($b['note'] ?? '', 500);
    $bid    = (int) $r['building_id'];
    $from   = $r['status'];

    $allowed = [
        'approve' => ['new'],
        'assign'  => ['new', 'approved', 'assigned'],
        'done'    => ['approved', 'assigned'],
        'close'   => ['done'],
        'reject'  => OPEN_STATUSES,
        'reopen'  => ['closed', 'rejected'],
    ];
    if (!isset($allowed[$action])) fail('INVALID_ACTION');
    if (!in_array($from, $allowed[$action], true)) fail('INVALID_TRANSITION', 409, ['status' => $from]);

    $db = db();
    $db->beginTransaction();
    $set = ['updated_at' => now()];
    switch ($action) {
        case 'approve':
            $set['status'] = 'approved';
            break;
        case 'assign':
            $staff = optInt($b['staff_id'] ?? null, 1, PHP_INT_MAX) ?? fail('INVALID_STAFF');
            checkStaffBelongs($staff, $bid);
            $set['status'] = 'assigned';
            $set['assigned_to'] = $staff;
            $s = $db->prepare('SELECT full_name FROM staff WHERE id = ?');
            $s->execute([$staff]);
            $note = trim('به ' . $s->fetchColumn() . ($note ? "؛ $note" : ''));
            break;
        case 'done':
            $cost = ($b['cost'] ?? '') === '' ? null : (money($b['cost']) ?? fail('INVALID_AMOUNT'));
            $set['status'] = 'done';
            $set['cost'] = $cost;
            $set['work_notes'] = cleanStr($b['work_notes'] ?? '', 1000);
            $set['done_at'] = now();
            if ($cost && !empty($b['record_expense'])) {
                $cat = null;
                if ($r['equipment_id']) {
                    $s = $db->prepare('SELECT category FROM equipment WHERE id = ?');
                    $s->execute([$r['equipment_id']]);
                    $cat = $s->fetchColumn() ?: null;
                }
                $chargeUnit = !empty($b['charge_unit']) && $r['unit_id'];
                $fundId = insertFundEntry($bid, 'out', expenseCategoryFor($cat, $r['type']), $cost, today(), "درخواست #{$id}: {$r['title']}", '', $chargeUnit ? 'unit' : 'none');
                $set['fund_entry_id'] = $fundId;
                // هزینه‌ی کار داخل واحد به حساب همان واحد بدهی می‌خورد (با حذف هزینه، بدهی هم حذف می‌شود).
                if ($chargeUnit) {
                    insertTx(['building_id' => $bid, 'unit_id' => (int) $r['unit_id'], 'kind' => 'debt', 'amount' => $cost,
                              'title' => "هزینه‌ی درخواست #{$id}: {$r['title']}", 'date' => today(), 'fund_entry_id' => $fundId]);
                }
            }
            break;
        case 'close':
            $set['status'] = 'closed';
            $set['closed_at'] = now();
            break;
        case 'reject':
            if (mb_strlen($note) < 2) fail('REASON_REQUIRED');
            $set['status'] = 'rejected';
            $set['closed_at'] = now();
            break;
        case 'reopen':
            $set['status'] = 'approved';
            $set['closed_at'] = null;
            $set['done_at'] = null;
            break;
    }
    $cols = implode(', ', array_map(fn($k) => "$k = ?", array_keys($set)));
    $db->prepare("UPDATE service_requests SET $cols WHERE id = ?")->execute([...array_values($set), $id]);
    logRequestEvent($id, $set['status'] ?? $from, $action === 'done' ? cleanStr($b['work_notes'] ?? '', 500) : $note);
    if ($action === 'done' && !empty($set['fund_entry_id'])) audit($bid, 'request.cost', "هزینه‌ی درخواست #{$id} «{$r['title']}»: " . faMoney((int) $set['cost']), 'request', $id);
    if ($action === 'reject') audit($bid, 'request.reject', "رد درخواست #{$id} «{$r['title']}»: $note", 'request', $id);
    $db->commit();
    if ($action === 'assign') smsAssignee($id);
    request_show($id);
}

/** پیامک به نیرو/پیمانکاری که درخواست به او سپرده شد (اگر موبایل دارد و در تنظیمات فعال است). */
function smsAssignee(int $id): void {
    $stmt = db()->prepare(requestSelect() . ' WHERE r.id = ?');
    $stmt->execute([$id]);
    $r = $stmt->fetch();
    if (!$r || !$r['staff_mobile']) return;
    $b = loadBuilding((int) $r['building_id']);
    if (!(int) $b['sms_notify_staff']) return;
    $where = $r['unit_title'] !== null ? unitName($r) : ($r['equipment_name'] ?: '');
    $text = "{$r['staff_name']} گرامی\nدرخواست جدید #" . faDigits($id) . ($r['priority'] === 'urgent' ? ' (فوری)' : '') . ": {$r['title']}"
        . ($where ? "\nمحل: $where" : '') . ($r['description'] ? "\n" . mb_substr($r['description'], 0, 200) : '') . smsFooter($b);
    smsNotify((int) $r['building_id'], 'assign', [[$r['staff_mobile'], $text]]);
}

function request_delete(int $id): void {
    $r = loadRequest($id, 'write');
    db()->prepare('DELETE FROM service_requests WHERE id = ?')->execute([$id]);
    audit((int) $r['building_id'], 'request.delete', "حذف درخواست #{$id} «{$r['title']}»");
    respond(['ok' => true]);
}

// ================= خلاصه و گزارش =================

function services_summary(int $bid): void {
    requireBuilding($bid);
    $s = db()->prepare("SELECT status, priority, COUNT(*) AS n FROM service_requests WHERE building_id = ? AND status IN ('new', 'approved', 'assigned', 'done') GROUP BY status, priority");
    $s->execute([$bid]);
    $counts = ['new' => 0, 'approved' => 0, 'assigned' => 0, 'done' => 0, 'urgent' => 0];
    foreach ($s->fetchAll() as $r) {
        $counts[$r['status']] += (int) $r['n'];
        if ($r['priority'] === 'urgent') $counts['urgent'] += (int) $r['n'];
    }
    $s = db()->prepare('SELECT * FROM equipment WHERE building_id = ? AND active = 1 AND service_interval_days IS NOT NULL');
    $s->execute([$bid]);
    $due = [];
    foreach ($s->fetchAll() as $e) {
        $e = castEquipment($e);
        if (in_array($e['service_status'], ['overdue', 'soon', 'never'], true)) {
            $due[] = ['id' => $e['id'], 'name' => $e['name'], 'category' => $e['category'], 'next_service_date' => $e['next_service_date'], 'service_status' => $e['service_status']];
        }
    }
    usort($due, fn($a, $b) => strcmp($a['next_service_date'] ?? '0000', $b['next_service_date'] ?? '0000'));
    respond(['requests' => $counts, 'due_services' => $due]);
}

/** گزارش عملکرد خدمات در یک بازه (R4). */
function services_report(int $bid): void {
    requireBuilding($bid);
    $from = isoDate($_GET['from'] ?? '') ?? '0000-01-01';
    $to   = isoDate($_GET['to'] ?? '') ?? '9999-12-31';
    $toEnd = "$to 23:59:59";
    $db = db();

    $s = $db->prepare('SELECT * FROM service_requests WHERE building_id = ? AND created_at BETWEEN ? AND ?');
    $s->execute([$bid, $from, $toEnd]);
    $rows = $s->fetchAll();

    $byStatus = $byType = [];
    $hours = [];
    foreach ($rows as $r) {
        $byStatus[$r['status']] = ($byStatus[$r['status']] ?? 0) + 1;
        $byType[$r['type']] = ($byType[$r['type']] ?? 0) + 1;
        if ($r['done_at']) $hours[] = (strtotime($r['done_at']) - strtotime($r['created_at'])) / 3600;
    }

    // هزینه و خرابیِ هر تجهیز در بازه: درخواست‌ها + سرویس‌ها
    $s = $db->prepare("SELECT e.id, e.name, e.category,
            (SELECT COUNT(*) FROM service_requests r WHERE r.equipment_id = e.id AND r.created_at BETWEEN ? AND ?) AS failures,
            (SELECT COALESCE(SUM(r.cost), 0) FROM service_requests r WHERE r.equipment_id = e.id AND r.done_at BETWEEN ? AND ?) AS repair_cost,
            (SELECT COUNT(*) FROM equipment_services es WHERE es.equipment_id = e.id AND es.date BETWEEN ? AND ?) AS services,
            (SELECT COALESCE(SUM(es.cost), 0) FROM equipment_services es WHERE es.equipment_id = e.id AND es.date BETWEEN ? AND ?) AS service_cost
        FROM equipment e WHERE e.building_id = ?");
    $s->execute([$from, $toEnd, $from, $toEnd, $from, $to, $from, $to, $bid]);
    $equipment = array_values(array_filter(array_map(fn($e) => [
        'id' => (int) $e['id'], 'name' => $e['name'], 'category' => $e['category'],
        'failures' => (int) $e['failures'], 'repair_cost' => (int) $e['repair_cost'],
        'services' => (int) $e['services'], 'service_cost' => (int) $e['service_cost'],
    ], $s->fetchAll()), fn($e) => $e['failures'] || $e['services']));
    usort($equipment, fn($a, $b) => [$b['failures'], $b['repair_cost'] + $b['service_cost']] <=> [$a['failures'], $a['repair_cost'] + $a['service_cost']]);

    $s = $db->prepare("SELECT COALESCE(SUM(cost), 0) FROM service_requests WHERE building_id = ? AND done_at BETWEEN ? AND ?");
    $s->execute([$bid, $from, $toEnd]);

    respond(['report' => [
        'total' => count($rows),
        'by_status' => $byStatus,
        'by_type' => $byType,
        'resolved' => count($hours),
        'avg_resolution_hours' => $hours ? round(array_sum($hours) / count($hours), 1) : null,
        'repair_cost' => (int) $s->fetchColumn(),
        'equipment' => $equipment,
    ]]);
}
