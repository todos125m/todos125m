<?php
// واحدها: فهرست، ثبت، ساخت سریع، ورود از اکسل.

const OCCUPANCY = ['owner', 'tenant', 'vacant'];

function unitInput(array $b, array $current = []): array {
    $pick = fn(string $k, $default = null) => array_key_exists($k, $b) ? $b[$k] : ($current[$k] ?? $default);
    $title = cleanStr($pick('title', ''), 60);
    if ($title === '') fail('INVALID_TITLE');
    return [
        'title'           => toEnDigits($title),
        'block'           => toEnDigits(cleanStr($pick('block', ''), 30)),
        'floor'           => optInt($pick('floor'), -10, 200),
        'area'            => optDecimal($pick('area'), 100000),
        'residents_count' => optInt($pick('residents_count', 0), 0, 100) ?? 0,
        'parking_count'   => optInt($pick('parking_count', 0), 0, 20) ?? 0,
        'has_storage'     => $pick('has_storage', 0) ? 1 : 0,
        'occupancy'       => oneOf($pick('occupancy', 'owner'), OCCUPANCY, 'owner'),
        'notes'           => cleanStr($pick('notes', ''), 500),
        // شارژ اختصاصی (تومان)؛ خالی یعنی طبق قاعده‌ی ساختمان
        'charge_override' => chargeOverrideInput($b, $current),
    ];
}

function chargeOverrideInput(array $b, array $current) {
    if (!array_key_exists('charge_override', $b)) return $current['charge_override'] ?? null;
    if ($b['charge_override'] === null || $b['charge_override'] === '') return null;
    return money($b['charge_override']) ?? fail('INVALID_AMOUNT');
}

function loadUnit(int $unitId, string $need = 'read'): array {
    $stmt = db()->prepare('SELECT * FROM units WHERE id = ?');
    $stmt->execute([$unitId]);
    $unit = $stmt->fetch();
    if (!$unit) fail('NOT_FOUND', 404);
    requireBuilding((int) $unit['building_id'], $need);
    return $unit;
}

function castUnit(array $u): array {
    foreach (['id', 'building_id', 'residents_count', 'parking_count', 'has_storage', 'persons_count', 'balance'] as $k) {
        if (isset($u[$k])) $u[$k] = (int) $u[$k];
    }
    $u['floor'] = $u['floor'] === null ? null : (int) $u['floor'];
    $u['area']  = $u['area'] === null ? null : (float) $u['area'];
    $u['has_storage'] = (bool) $u['has_storage'];
    $u['charge_override'] = $u['charge_override'] === null ? null : (int) $u['charge_override'];
    return $u;
}

function units_list(int $bid): void {
    requireBuilding($bid);
    $person = fn(string $role, string $col) =>
        "(SELECT p.$col FROM persons p WHERE p.unit_id = u.id AND p.role = '$role' ORDER BY p.id LIMIT 1)";
    $stmt = db()->prepare(
        "SELECT u.*, {$person('owner', 'full_name')} AS owner_name, {$person('owner', 'mobile')} AS owner_mobile,
                {$person('tenant', 'full_name')} AS tenant_name, {$person('tenant', 'mobile')} AS tenant_mobile,
                (SELECT COUNT(*) FROM persons p WHERE p.unit_id = u.id) AS persons_count,
                (SELECT COALESCE(SUM(" . SIGNED_AMOUNT . "), 0) FROM unit_transactions t WHERE t.unit_id = u.id) AS balance
           FROM units u WHERE u.building_id = ? ORDER BY u.block, u.id"
    );
    $stmt->execute([$bid]);
    $b = loadBuilding($bid);
    respond(['units' => array_map(fn($u) => castUnit($u) + ['monthly_charge' => chargeFor($u, $b)], $stmt->fetchAll())]);
}

function units_create(int $bid): void {
    requireBuilding($bid, 'write');
    $in = unitInput(body());
    try {
        db()->prepare('INSERT INTO units (building_id, title, block, floor, area, residents_count, parking_count, has_storage, occupancy, notes, charge_override, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
            ->execute([$bid, ...array_values($in), now(), now()]);
    } catch (PDOException $e) {
        if (isUniqueViolation($e)) fail('DUPLICATE_UNIT', 409);
        throw $e;
    }
    $id = (int) db()->lastInsertId();
    audit($bid, 'unit.create', 'افزودن ' . unitName($in), 'unit', $id);
    units_show($id);
}

// «واحد ۱» تا «واحد N» — عنوان‌های تکراری رد می‌شوند و شماره ادامه پیدا می‌کند.
function createNumberedUnits(int $bid, int $count, string $prefix, string $block = ''): int {
    $db   = db();
    $stmt = $db->prepare('SELECT title FROM units WHERE building_id = ? AND block = ?');
    $stmt->execute([$bid, $block]);
    $taken = array_flip($stmt->fetchAll(PDO::FETCH_COLUMN));

    $ins = $db->prepare('INSERT INTO units (building_id, title, block, created_at, updated_at) VALUES (?, ?, ?, ?, ?)');
    $created = 0;
    for ($n = 1; $created < $count; $n++) {
        $title = trim("$prefix $n");
        if (isset($taken[$title])) continue;
        $ins->execute([$bid, $title, $block, now(), now()]);
        $created++;
    }
    return $created;
}

function units_bulk_create(int $bid): void {
    requireBuilding($bid, 'write');
    $body  = body();
    $count = optInt($body['count'] ?? null, 1, 500);
    if (!$count) fail('INVALID_COUNT');
    $prefix = cleanStr($body['prefix'] ?? 'واحد', 40);
    $block  = toEnDigits(cleanStr($body['block'] ?? '', 30));

    $db = db();
    $db->beginTransaction();
    $created = createNumberedUnits($bid, $count, $prefix, $block);
    audit($bid, 'unit.bulk', 'افزودن ' . faDigits($created) . ' واحد یک‌جا');
    $db->commit();
    respond(['created' => $created], 201);
}

function units_show(int $unitId): void {
    $unit = loadUnit($unitId);
    $stmt = db()->prepare("SELECT * FROM persons WHERE unit_id = ? ORDER BY CASE role WHEN 'owner' THEN 0 ELSE 1 END, id");
    $stmt->execute([$unitId]);
    respond(['unit' => castUnit($unit), 'persons' => array_map('castPerson', $stmt->fetchAll())]);
}

function units_update(int $unitId): void {
    $unit = loadUnit($unitId, 'write');
    $in   = unitInput(body(), $unit);
    try {
        db()->prepare('UPDATE units SET title = ?, block = ?, floor = ?, area = ?, residents_count = ?, parking_count = ?, has_storage = ?, occupancy = ?, notes = ?, charge_override = ?, updated_at = ? WHERE id = ?')
            ->execute([...array_values($in), now(), $unitId]);
    } catch (PDOException $e) {
        if (isUniqueViolation($e)) fail('DUPLICATE_UNIT', 409);
        throw $e;
    }
    $changes = [];
    if ($unit['charge_override'] !== $in['charge_override'] && (string) $unit['charge_override'] !== (string) $in['charge_override']) {
        $changes[] = $in['charge_override'] === null ? 'شارژ اختصاصی برداشته شد' : 'شارژ اختصاصی ' . faMoney((int) $in['charge_override']);
    }
    if ($unit['occupancy'] !== $in['occupancy']) $changes[] = 'وضعیت سکونت';
    if ((string) $unit['area'] !== (string) $in['area'] || (int) $unit['residents_count'] !== (int) $in['residents_count'] || (int) $unit['parking_count'] !== (int) $in['parking_count']) $changes[] = 'متراژ/نفرات/پارکینگ';
    audit((int) $unit['building_id'], 'unit.update', 'ویرایش ' . unitName($in) . ($changes ? ' — ' . implode('، ', $changes) : ''), 'unit', $unitId);
    units_show($unitId);
}

function units_delete(int $unitId): void {
    $unit = loadUnit($unitId, 'write');
    // پرداخت‌های واقعیِ یک واحد جزو تاریخچه‌ی صندوق‌اند؛ حذف واحد نباید موجودی و گزارش‌ها را بی‌صدا عوض کند.
    $stmt = db()->prepare('SELECT COUNT(*) FROM unit_transactions WHERE unit_id = ?');
    $stmt->execute([$unitId]);
    if ((int) $stmt->fetchColumn() > 0) fail('UNIT_HAS_TRANSACTIONS', 409);
    db()->prepare('DELETE FROM units WHERE id = ?')->execute([$unitId]);
    audit((int) $unit['building_id'], 'unit.delete', 'حذف ' . unitName($unit));
    respond(['ok' => true]);
}

/**
 * ورود از اکسل. هر ردیف: title, block, floor, area, residents_count, parking_count,
 * owner_name, owner_mobile, tenant_name, tenant_mobile.
 * اول همه‌ی ردیف‌ها اعتبارسنجی می‌شوند؛ اگر خطایی باشد هیچ چیزی ذخیره نمی‌شود.
 * واحدِ هم‌نام (در همان بلوک) به‌روزرسانی می‌شود، نه تکرار.
 */
function units_import(int $bid): void {
    requireBuilding($bid, 'write');
    $rows = body()['rows'] ?? null;
    if (!is_array($rows) || !$rows) fail('NO_ROWS');
    if (count($rows) > 2000) fail('TOO_MANY_ROWS');

    $errors = [];
    $clean  = [];
    $seen   = [];
    foreach (array_values($rows) as $i => $r) {
        $rowErr = [];
        $title = toEnDigits(cleanStr($r['title'] ?? '', 60));
        $block = toEnDigits(cleanStr($r['block'] ?? '', 30));
        if ($title === '') $rowErr[] = 'title';
        $key = "$block|$title";
        if ($title !== '' && isset($seen[$key])) $rowErr[] = 'duplicate';
        $seen[$key] = true;

        $area = optDecimal($r['area'] ?? null, 100000);
        if (($r['area'] ?? '') !== '' && $area === null) $rowErr[] = 'area';

        $people = [];
        foreach (['owner', 'tenant'] as $role) {
            $name   = cleanStr($r["{$role}_name"] ?? '', 120);
            $rawMob = trim((string) ($r["{$role}_mobile"] ?? ''));
            $mobile = $rawMob === '' ? null : normalizeMobile($rawMob);
            if ($rawMob !== '' && !$mobile) $rowErr[] = "{$role}_mobile";
            if ($name === '' && $mobile) $name = $role === 'owner' ? 'مالک' : 'مستأجر';
            if ($name !== '') $people[$role] = ['name' => $name, 'mobile' => $mobile];
        }

        if ($rowErr) {
            $errors[] = ['row' => $i, 'fields' => $rowErr];
            continue;
        }
        $clean[] = [
            'title' => $title, 'block' => $block,
            'floor' => optInt($r['floor'] ?? null, -10, 200),
            'area' => $area,
            'residents_count' => optInt($r['residents_count'] ?? null, 0, 100),
            'parking_count' => optInt($r['parking_count'] ?? null, 0, 20),
            'people' => $people,
        ];
    }
    if ($errors) fail('INVALID_ROWS', 422, ['rows' => $errors]);

    $db = db();
    $db->beginTransaction();
    $find    = $db->prepare('SELECT id FROM units WHERE building_id = ? AND block = ? AND title = ?');
    $insUnit = $db->prepare('INSERT INTO units (building_id, title, block, floor, area, residents_count, parking_count, occupancy, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    $updUnit = $db->prepare('UPDATE units SET floor = COALESCE(?, floor), area = COALESCE(?, area), residents_count = COALESCE(?, residents_count), parking_count = COALESCE(?, parking_count), updated_at = ? WHERE id = ?');
    $findP   = $db->prepare('SELECT id FROM persons WHERE unit_id = ? AND role = ? ORDER BY id LIMIT 1');
    $insP    = $db->prepare('INSERT INTO persons (building_id, unit_id, role, full_name, mobile, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)');
    $updP    = $db->prepare('UPDATE persons SET full_name = ?, mobile = COALESCE(?, mobile), updated_at = ? WHERE id = ?');
    $setTenant = $db->prepare("UPDATE units SET occupancy = 'tenant', updated_at = ? WHERE id = ? AND occupancy = 'owner'");

    $created = $updated = 0;
    foreach ($clean as $c) {
        $find->execute([$bid, $c['block'], $c['title']]);
        $unitId = $find->fetchColumn();
        if ($unitId) {
            $updUnit->execute([$c['floor'], $c['area'], $c['residents_count'], $c['parking_count'], now(), $unitId]);
            $updated++;
        } else {
            $occupancy = isset($c['people']['tenant']) ? 'tenant' : 'owner';
            $insUnit->execute([$bid, $c['title'], $c['block'], $c['floor'], $c['area'], $c['residents_count'] ?? 0, $c['parking_count'] ?? 0, $occupancy, now(), now()]);
            $unitId = (int) $db->lastInsertId();
            $created++;
        }
        // مستأجر در فایل یعنی واحد استیجاری است (همان قاعده‌ی افزودن دستی مستأجر).
        if (isset($c['people']['tenant'])) $setTenant->execute([now(), $unitId]);
        foreach ($c['people'] as $role => $p) {
            $findP->execute([$unitId, $role]);
            if ($pid = $findP->fetchColumn()) {
                $updP->execute([$p['name'], $p['mobile'], now(), $pid]);
            } else {
                $insP->execute([$bid, $unitId, $role, $p['name'], $p['mobile'], now(), now()]);
            }
        }
    }
    audit($bid, 'unit.import', 'ورود از اکسل: ' . faDigits($created) . ' واحد جدید، ' . faDigits($updated) . ' به‌روزرسانی');
    $db->commit();
    respond(['created' => $created, 'updated' => $updated]);
}
